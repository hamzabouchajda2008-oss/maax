
import os from "os";
import { monitorEventLoopDelay } from "perf_hooks";

let mod = null, modErr = null;
try { mod = await import("baileys-caller-group"); } catch (e) { modErr = String((e && e.message) || e); }

let client = null, connecting = null, current = null, currentId = null;
const send = msg => { if (process.connected) { try { process.send(msg); } catch (e) {} } };

for (const p of [-20, -15, -10, -5]) { try { os.setPriority(0, p); break; } catch (e) {} }

const lag = monitorEventLoopDelay({ resolution: 20 });
lag.enable();
setInterval(() => {
    if (current) {
        const p99 = Math.max(0, lag.percentile(99) / 1e6 - 20);
        const max = Math.max(0, lag.max / 1e6 - 20);
        send({ type: "stats", id: currentId, lagP99: p99, lagMax: max });
        if (max > 60) console.error("[CALL-WORKER-GROUP] تأخر المؤقّت وصل " + Math.round(max) + "ms");
    }
    lag.reset();
}, 5000).unref();

async function ensure() {
    if (!mod) { const err = new Error("baileys-caller-group غير مثبت: " + modErr); err.code = "NO_ENGINE"; throw err; }
    if (client) return client;
    if (!connecting) {
        connecting = (async () => {
            const c = new mod.VoipClient({ authDir: "./call-auth" });
            await c.connect();
            client = c;
            return c;
        })().catch(e => { connecting = null; throw e; });
    }
    return connecting;
}

process.on("message", async msg => {
    try {
        if (msg.type === "warm") {
            await ensure();
            send({ type: "ready" });
        } else if (msg.type === "groupcall") {
            const c = await ensure();
            if (typeof c.callGroup !== "function") { const err = new Error("نسخة المكتبة ما فيها callGroup"); err.code = "NO_ENGINE"; throw err; }
            const call = await c.callGroup(msg.numbers, { groupJid: msg.groupJid, audioSource: msg.file, durationMs: msg.durationMs });
            current = call; currentId = msg.id;

            const known = new Set(["ringing", "connected", "ended", "error", "audio", "video", "newListener", "removeListener"]);
            const seen = new Set();
            const origEmit = typeof call.emit === "function" ? call.emit.bind(call) : null;
            if (origEmit) {
                call.emit = (name, ...a) => {
                    const key = String(name);
                    if (!known.has(key) && !seen.has(key)) {
                        seen.add(key);
                        console.log("[CALL-WORKER-GROUP] حدث من المكتبة:", key);
                        send({ type: "event", id: msg.id, name: "other:" + key });
                    }
                    return origEmit(name, ...a);
                };
            }

            call.on("ringing", () => send({ type: "event", id: msg.id, name: "ringing" }));
            call.on("connected", () => send({ type: "event", id: msg.id, name: "connected" }));
            call.on("ended", r => { current = null; currentId = null; send({ type: "ended", id: msg.id, reason: String(r) }); });
            call.on("error", e => { current = null; currentId = null; send({ type: "error", id: msg.id, message: String((e && e.message) || e) }); });
            send({ type: "started", id: msg.id });
        } else if (msg.type === "hangup") {
            try { current && current.end(); } catch (e) {}
        }
    } catch (e) {
        client = null; connecting = null; current = null; currentId = null;
        send({ type: "failed", id: msg.id, code: e && e.code, message: String((e && e.message) || e) });
    }
});

process.on("disconnect", () => process.exit(0));
process.on("uncaughtException", e => { console.error("[CALL-WORKER-GROUP]", e); });
process.on("unhandledRejection", e => { console.error("[CALL-WORKER-GROUP]", e); });
