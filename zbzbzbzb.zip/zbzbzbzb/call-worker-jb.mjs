
import fs from "fs";
import os from "os";
import { monitorEventLoopDelay } from "perf_hooks";

const AUTH = "./call-auth";
const RES = "/home/container/voip-resources";

let jb = null, jbErr = null;
try { jb = await import("@japofc/baileys"); } catch (e) { jbErr = String((e && e.message) || e); }

let sock = null, voip = null, connecting = null;
let current = null, currentId = null, hardTimer = null, forced = false, degraded = 0;
const send = msg => { if (process.connected) { try { process.send(msg); } catch (e) {} } };

for (const p of [-20, -15, -10, -5]) { try { os.setPriority(0, p); break; } catch (e) {} }

const lag = monitorEventLoopDelay({ resolution: 20 });
lag.enable();
setInterval(() => {
    if (current) {
        const p99 = Math.max(0, lag.percentile(99) / 1e6 - 20);
        const max = Math.max(0, lag.max / 1e6 - 20);
        let relay = null;
        try { const st = voip && voip.getStats && voip.getStats(); if (st) relay = JSON.stringify(st).slice(0, 300); } catch (e) {}
        send({ type: "stats", id: currentId, lagP99: p99, lagMax: max, relay: relay });
        if (relay) console.log("[CALL-WORKER-JB] relay:", relay);
        if (max > 60) console.error("[CALL-WORKER-JB] تأخر المؤقّت وصل " + Math.round(max) + "ms");
    }
    lag.reset();
}, 5000).unref();

function hangup() {
    const c = current;
    if (!c) return;
    for (const k of ["end", "hangup", "terminate"]) {
        if (typeof c[k] === "function") { try { c[k](); return; } catch (e) {} }
    }
    try { voip && voip.endCall && voip.endCall(c.callId); } catch (e) {}
}

function release() {
    clearTimeout(hardTimer); hardTimer = null;
    current = null; currentId = null;
}

function onSockClosed(code) {
    console.error("[CALL-WORKER-JB] انقطع اتصال واتساب، كود:", code);
    voip = null; connecting = null;
    try { sock && sock.end && sock.end(undefined); } catch (e) {}
    sock = null;
}

async function ensure() {
    if (!jb) { const err = new Error("@japofc/baileys غير مثبت: " + jbErr); err.code = "NO_ENGINE"; throw err; }
    if (voip) return voip;
    if (connecting) return connecting;
    connecting = (async () => {
        const { state, saveCreds } = await jb.useMultiFileAuthState(AUTH);
        const make = jb.makeWASocketAuto || jb.makeWASocket || (jb.default && (jb.default.makeWASocket || jb.default));
        const s = await make({ auth: state, printQRInTerminal: false, browser: ["Ubuntu", "Chrome", "20.0.04"], markOnlineOnConnect: false });
        s.ev.on("creds.update", saveCreds);

        await new Promise((resolve, reject) => {
            let done = false;
            const t = setTimeout(() => { if (!done) { done = true; reject(new Error("انتهت مهلة الاتصال بواتساب")); } }, 45000);
            s.ev.on("connection.update", u => {
                if (u.connection === "open" && !done) { done = true; clearTimeout(t); resolve(); }
                if (u.connection === "close") {
                    const code = u.lastDisconnect && u.lastDisconnect.error && u.lastDisconnect.error.output && u.lastDisconnect.error.output.statusCode;
                    if (!done) { done = true; clearTimeout(t); reject(new Error("أُغلق الاتصال، كود: " + code)); }
                    else onSockClosed(code);
                }
            });
        });
        sock = s;

        const opts = fs.existsSync(RES) ? { resourcesPath: RES } : {};
        let v;
        if (typeof jb.attachVoip === "function") v = await jb.attachVoip(s, opts);
        else { v = new jb.VoipClient(opts); await v.connectWithSocket(s); }

        // مراقب النفق: المكتبة نفسها تحاول تعيد الوصل، ونحن نحسب المرات ونقرر متى نستسلم
        if (typeof v.on === "function") {
            v.on("call-degraded", d => {
                degraded++;
                console.error("[CALL-WORKER-JB] النفق تدهور (" + degraded + ")");
                send({ type: "event", id: currentId, name: "degraded" });
                if (degraded >= 3 && current) { forced = true; hangup(); }
            });
            v.on("call-recovery", r => {
                console.log("[CALL-WORKER-JB] نتيجة الإصلاح:", JSON.stringify(r || {}).slice(0, 200));
                if (r && (r.ok || r.success)) degraded = 0;
            });
        }
        voip = v;
        return v;
    })().catch(e => { connecting = null; voip = null; throw e; });
    return connecting;
}

process.on("message", async msg => {
    try {
        if (msg.type === "warm") {
            await ensure();
            send({ type: "ready" });
        } else if (msg.type === "call") {
            const v = await ensure();
            forced = false; degraded = 0;
            const call = await v.call(msg.target, { audioSource: msg.file, durationMs: msg.durationMs });
            current = call; currentId = msg.id;
            hardTimer = setTimeout(() => hangup(), msg.durationMs + 3000);

            const known = new Set(["ringing", "connected", "ended", "error", "newListener", "removeListener"]);
            const seen = new Set();
            const origEmit = typeof call.emit === "function" ? call.emit.bind(call) : null;
            if (origEmit) {
                call.emit = (name, ...a) => {
                    const key = String(name);
                    if (!known.has(key) && !seen.has(key)) {
                        seen.add(key);
                        console.log("[CALL-WORKER-JB] حدث من المكتبة:", key);
                        send({ type: "event", id: msg.id, name: "other:" + key });
                    }
                    return origEmit(name, ...a);
                };
            }

            call.on("ringing", () => send({ type: "event", id: msg.id, name: "ringing" }));
            call.on("connected", () => send({ type: "event", id: msg.id, name: "connected" }));
            call.on("ended", r => { const why = forced ? "relay_dead" : String(r); release(); send({ type: "ended", id: msg.id, reason: why }); });
            call.on("error", e => { release(); send({ type: "error", id: msg.id, message: String((e && e.message) || e) }); });
            send({ type: "started", id: msg.id });
        } else if (msg.type === "hangup") {
            hangup();
        }
    } catch (e) {
        release();
        send({ type: "failed", id: msg.id, code: e && e.code, message: String((e && e.message) || e) });
    }
});

process.on("disconnect", () => process.exit(0));
process.on("uncaughtException", e => { console.error("[CALL-WORKER-JB]", e); });
process.on("unhandledRejection", e => { console.error("[CALL-WORKER-JB]", e); });
