
import fs from "fs";
import os from "os";
import { monitorEventLoopDelay } from "perf_hooks";
import { EventEmitter } from "events";
import { VoipClient } from "baileys-caller";

let client = null, connecting = null, current = null, currentId = null, feeder = null;
const send = msg => { if (process.connected) { try { process.send(msg); } catch (e) {} } };

// أعلى أولوية ممكنة للمعالج (تنجح فقط لو البوت شغّال بصلاحيات كافية)
for (const p of [-20, -15, -10, -5]) { try { os.setPriority(0, p); break; } catch (e) {} }

// مراقب تأخر حلقة الأحداث: هذا بالضبط اللي يسبب التقطيع لو كبير
const lag = monitorEventLoopDelay({ resolution: 20 });
lag.enable();
setInterval(() => {
    if (current) {
        const p99 = Math.max(0, lag.percentile(99) / 1e6 - 20);
        const max = Math.max(0, lag.max / 1e6 - 20);
        send({ type: "stats", id: currentId, lagP99: p99, lagMax: max });
        if (max > 60) console.error("[CALL-WORKER] تأخر المؤقّت وصل " + Math.round(max) + "ms (يسبب تقطيع)");
    }
    lag.reset();
}, 5000).unref();

async function ensure() {
    if (client) return client;
    if (!connecting) {
        connecting = (async () => {
            const c = new VoipClient({ authDir: "./call-auth" });
            await c.connect();
            client = c;
            return c;
        })().catch(e => { connecting = null; throw e; });
    }
    return connecting;
}

// مكالمة جماعية احتياطية: لو المكتبة ما فيها callGroup نتصل بكل عضو من أعضاء الغرفة (بفاصل صغير) ونلفّها ككائن مكالمة واحد
async function multiCall(c, msg) {
    const g = new EventEmitter();
    const calls = [];
    let left = 0;
    const finish = r => { if (g.__e !== undefined) return; g.__e = String(r); g.emit("ended", g.__e); };
    g.end = () => { for (const k of calls) { try { k.end(); } catch (e) {} } };
    for (let i = 0; i < msg.numbers.length; i++) {
        try {
            const k = await c.call(msg.numbers[i], { audioSource: msg.file, durationMs: msg.durationMs });
            calls.push(k); left++;
            k.on("ringing", () => { if (!g.__r) { g.__r = true; g.emit("ringing"); } });
            k.on("connected", () => { if (!g.__c) { g.__c = true; g.emit("connected"); } });
            k.on("ended", r => { left--; if (left <= 0) finish(r); });
            k.on("error", e => { left--; if (left <= 0) finish((e && e.message) || e); });
        } catch (e) { console.error("[CALL-WORKER] multiCall:", (e && e.message) || e); }
        if (i < msg.numbers.length - 1) await new Promise(r => setTimeout(r, 1200));
    }
    if (!calls.length) throw new Error("تعذّر الاتصال بأي عضو من الغرفة");
    return g;
}

// قراءة WAV أحادي 16-bit إلى Float32 (للوضع stream)
function parseWav(buf) {
    if (buf.toString("ascii", 0, 4) !== "RIFF") throw new Error("ملف WAV غير صالح");
    let off = 12, fmt = null, data = null;
    while (off + 8 <= buf.length) {
        const id = buf.toString("ascii", off, off + 4);
        const size = buf.readUInt32LE(off + 4);
        const body = off + 8;
        if (id === "fmt ") fmt = { ch: buf.readUInt16LE(body + 2), rate: buf.readUInt32LE(body + 4), bits: buf.readUInt16LE(body + 14) };
        else if (id === "data") { data = buf.subarray(body, Math.min(body + size, buf.length)); break; }
        off = body + size + (size & 1);
    }
    if (!fmt || !data) throw new Error("WAV ناقص");
    if (fmt.bits !== 16 || fmt.ch !== 1 || fmt.rate !== 16000) throw new Error("لازم WAV أحادي 16kHz 16bit");
    // نسخة Int16 سريعة (memcpy)؛ التحويل إلى Float32 يتم على دفعات صغيرة داخل المغذّي
    const n = data.length >> 1;
    const ab = new ArrayBuffer(n * 2);
    Buffer.from(ab).set(data.subarray(0, n * 2));
    return new Int16Array(ab);
}

// مغذّي الطابور (قائمة أغاني): يحافظ على ~800ms جاهزة دائماً، ويدعم append/skip أثناء المكالمة
function startFeeder(call, pcms, maxMs, onTrack, onTail) {
    const RATE = 16000, CHUNK = 8000, TARGET = 40;
    const LEAD_MS = 5000, TAIL_MS = 120000;
    const canCount = typeof call.queuedAudioChunks === "number";
    const queued = () => Number(call.queuedAudioChunks) || 0;
    const maxSamples = Math.floor(maxMs / 1000 * RATE);
    const tracks = pcms.slice();
    const t0 = Date.now();
    let ti = 0, pos = 0, pushed = 0, announced = -1, idleSince = 0, stopped = false, flushed = false, timer = null;
    let lead = Math.floor(LEAD_MS / 1000 * RATE), tailStart = 0;

    const tick = () => {
        if (stopped) return;
        try {
            // صمت البداية: ما تبدأ الأغنية مباشرة مع الرد
            while (lead > 0 && (!canCount || queued() < TARGET)) {
                const n = Math.min(CHUNK, lead);
                call.pushAudio(new Float32Array(n));
                lead -= n;
            }
            if (lead > 0) { timer = setTimeout(tick, 80); return; }
            while (ti < tracks.length && pushed < maxSamples && (!canCount || queued() < TARGET)) {
                if (announced !== ti) { announced = ti; onTrack(ti); }
                const src = tracks[ti];
                const end = Math.min(pos + CHUNK, src.length);
                const f = new Float32Array(end - pos);
                for (let i = 0; i < f.length; i++) f[i] = src[pos + i] / 32768;
                call.pushAudio(f);
                pushed += f.length; pos = end;
                if (pos >= src.length) { ti++; pos = 0; }
            }
            const finished = ti >= tracks.length || pushed >= maxSamples;
            if (finished) {
                if (!flushed) { flushed = true; try { call.flushAudio && call.flushAudio(); } catch (e) {} }
                if (!canCount) {
                    stopped = true;
                    setTimeout(() => { try { call.end(); } catch (e) {} }, Math.max(1000, t0 + LEAD_MS + pushed / RATE * 1000 + TAIL_MS + 3000 - Date.now()));
                    return;
                }
                // الأغاني خلصت: نبقي الاتصال مفتوح (صمت خفيف) لين تنتهي مهلة الدقيقتين، والإضافة تصفّر العدّاد
                if (queued() < 10) {
                    if (!tailStart) { tailStart = Date.now(); try { onTail && onTail(); } catch (e) {} }
                    if (Date.now() - tailStart > TAIL_MS) { stopped = true; try { call.end(); } catch (e) {} return; }
                    call.pushAudio(new Float32Array(2000));
                }
            } else tailStart = 0;
        } catch (e) { console.error("[CALL-WORKER] feeder:", e); }
        timer = setTimeout(tick, 80);
    };
    tick();
    return {
        append(pcm) { if (stopped) return 0; tracks.push(pcm); idleSince = 0; tailStart = 0; flushed = false; return tracks.length; },
        skip() { if (stopped || ti >= tracks.length) return false; ti++; pos = 0; idleSince = 0; return true; },
        stop() { stopped = true; clearTimeout(timer); }
    };
}

function release() {
    if (feeder) { try { feeder.stop(); } catch (e) {} feeder = null; }
    current = null; currentId = null;
}

process.on("message", async msg => {
    try {
        if (msg.type === "warm") {
            await ensure();
            send({ type: "ready" });
        } else if (msg.type === "call") {
            send({ type: "event", id: msg.id, name: "phase:ensure" });
            const c = await ensure();
            send({ type: "event", id: msg.id, name: "phase:client_ready" });
            let pcms = null;
            if (msg.stream) pcms = (msg.files || [msg.file]).map(f => parseWav(fs.readFileSync(f)));

            send({ type: "event", id: msg.id, name: "phase:calling" });
            const call = await c.call(msg.target, {
                audioSource: msg.stream ? "stream" : msg.file,
                durationMs: msg.durationMs
            });

            if (msg.stream && typeof call.pushAudio !== "function") {
                try { call.end(); } catch (e) {}
                send({ type: "failed", id: msg.id, code: "NO_STREAM", message: "نسخة المكتبة ما تدعم stream" });
                return;
            }

            current = call; currentId = msg.id;
            send({ type: "event", id: msg.id, name: "phase:offer_sent" });

            // كاشف الأحداث المجهولة (أول ظهور فقط عشان ما نغرق الإشارات)
            const known = new Set(["ringing", "connected", "ended", "error", "newListener", "removeListener"]);
            const seen = new Set();
            const origEmit = typeof call.emit === "function" ? call.emit.bind(call) : null;
            if (origEmit) {
                call.emit = (name, ...a) => {
                    const key = String(name);
                    if (!known.has(key) && !seen.has(key)) {
                        seen.add(key);
                        console.log("[CALL-WORKER] حدث من المكتبة:", key);
                        send({ type: "event", id: msg.id, name: "other:" + key });
                    }
                    return origEmit(name, ...a);
                };
            }

            call.on("ringing", () => send({ type: "event", id: msg.id, name: "ringing" }));
            call.on("connected", () => {
                send({ type: "event", id: msg.id, name: "connected" });
                if (msg.stream && pcms && !feeder) feeder = startFeeder(call, pcms, msg.durationMs, i => send({ type: "event", id: msg.id, name: "track:" + i }), () => send({ type: "event", id: msg.id, name: "tail" }));
            });
            call.on("ended", r => { release(); send({ type: "ended", id: msg.id, reason: String(r) }); });
            call.on("error", e => { release(); send({ type: "error", id: msg.id, message: String((e && e.message) || e) }); });
            send({ type: "started", id: msg.id });
        } else if (msg.type === "groupcall") {
            const c = await ensure();
            const call = typeof c.callGroup === "function"
                ? await c.callGroup(msg.numbers, { groupJid: msg.groupJid, audioSource: msg.file, durationMs: msg.durationMs })
                : await multiCall(c, msg);
            current = call; currentId = msg.id;
            call.on("ringing", () => send({ type: "event", id: msg.id, name: "ringing" }));
            call.on("connected", () => send({ type: "event", id: msg.id, name: "connected" }));
            call.on("ended", r => { release(); send({ type: "ended", id: msg.id, reason: String(r) }); });
            call.on("error", e => { release(); send({ type: "error", id: msg.id, message: String((e && e.message) || e) }); });
            send({ type: "started", id: msg.id });
            // أحداث سبقت ربط المستمعين (في الاتصال بعدة أعضاء)
            if (call.__r) send({ type: "event", id: msg.id, name: "ringing" });
            if (call.__c) send({ type: "event", id: msg.id, name: "connected" });
            if (call.__e !== undefined) { release(); send({ type: "ended", id: msg.id, reason: String(call.__e) }); }
        } else if (msg.type === "append") {
            let n = 0;
            try { if (feeder) n = feeder.append(parseWav(fs.readFileSync(msg.file))); } catch (e) { console.error("[CALL-WORKER] append:", e); }
            send({ type: "appended", id: msg.id, ok: n > 0, count: n });
        } else if (msg.type === "skip") {
            let ok = false;
            try { ok = !!(feeder && feeder.skip()); } catch (e) {}
            send({ type: "skipped", id: msg.id, ok: ok });
        } else if (msg.type === "hangup") {
            if (feeder) { try { feeder.stop(); } catch (e) {} feeder = null; }
            try { current && current.end(); } catch (e) {}
        }
    } catch (e) {
        client = null; connecting = null; release();
        send({ type: "failed", id: msg.id, message: String((e && e.message) || e) });
    }
});

process.on("disconnect", () => process.exit(0));
process.on("uncaughtException", e => { console.error("[CALL-WORKER]", e); });
process.on("unhandledRejection", e => { console.error("[CALL-WORKER]", e); });
