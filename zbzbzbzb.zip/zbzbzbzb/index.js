import { Client } from 'meowsab';
import { group, access } from "./system/control.js";
import UltraDB from "./system/UltraDB.js";
import { AIRich, Button, ButtonV2, Carousel } from "./system/nixcode.js";

/* =========== Client ========== */
const client = new Client({
  phoneNumber: '212625654754', // Bot number
  prefix: [".", "/", "!", "7away", "hamza", "bitch"],
  fromMe: null, 
  owners: [
  { name: "𝐉𝐎𝐘 𝐁𝐎𝐘", lid: "212625654754@lid", jid: "212625654754@s.whatsapp.net" },
  { name: "𝐎𝐖𝐍𝐄𝐑 𝟐", lid: "105485084680233@lid", jid: "212721125336@s.whatsapp.net" }
],
  settings: { noWelcome: false },
  commandsPath: './plugins'
});

client.onGroupEvent(group);
client.onCommandAccess(access);

/* =========== Database ========== */
if (!global.db) {
    global.db = new UltraDB();
}

/* =========== Rich Message Lib (Nixcode) ========== */
global.AIRich = AIRich;
global.Button = Button;
global.ButtonV2 = ButtonV2;
global.Carousel = Carousel;

/* =========== Config ========== */
const { config } = client;
config.info = { 
  nameBot: "♡ JOY BOY BOT 🎪 〈", 
  nameChannel: "", 
  idChannel: "",
  urls: {
    repo: "https://github.com/deveni0/Pomni-AI",
    api: "https://emam-api.web.id",
    channel: ""
  },
  copyright: { 
    pack: '𝐉𝐎𝐘 𝐁𝐎𝐘', 
    author: '𝐉𝐎𝐘 𝐁𝐎𝐘'
  },
  images: [
    "https://i.pinimg.com/originals/11/26/97/11269786cdb625c60213212aa66273a9.png",
    "https://i.pinimg.com/originals/e2/21/20/e221203f319df949ee65585a657501a2.jpg",
    "https://i.pinimg.com/originals/bb/77/0f/bb770fad66a634a6b3bf93e9c00bf4e5.jpg"
  ]
};

/* =========== Start ========== */
client.start();

/* =========== Catch Errors ========== */
process.on('uncaughtException', (e) => {
    if (e.message.includes('rate-overlimit')) {}
});

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err);
});
