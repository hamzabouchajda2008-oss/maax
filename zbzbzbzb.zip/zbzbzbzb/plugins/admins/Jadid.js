// =============================================
// 📌 نسخة مطورة: اختيار المجموعة بالـ ID
// =============================================

const handler = async (m, { conn, text, bot }) => {
    // التحقق من الصلاحيات
    const senderClean = m.sender.split(':')[0].split('@')[0];
    const isOwnerUser = bot.config?.owners?.some(o => {
        const oc = (o.jid || o.lid || '').split(':')[0].split('@')[0];
        return oc === senderClean;
    });
    if (!m.isOwner && !isOwnerUser) {
        return m.reply('❌ *خاص بالمالك فقط*');
    }

    // استخراج الـ ID والنص
    let targetChat = m.chat; // الافتراضي: المجموعة الحالية
    let messageText = text;

    // إذا كان المستخدم كتب ID قبل النص (مثال: .ق 123456789@g.us مرحبا)
    if (text && text.includes('@g.us')) {
        const parts = text.split(' ');
        const possibleId = parts[0];
        if (possibleId.endsWith('@g.us') || possibleId.endsWith('@broadcast')) {
            targetChat = possibleId;
            messageText = parts.slice(1).join(' ');
        }
    }

    // إذا كان هناك رسالة مقتبسة من مجموعة أخرى، استخدم معرفها
    if (m.quoted && m.quoted.key?.remoteJid?.includes('@g.us')) {
        targetChat = m.quoted.key.remoteJid;
        // إذا لم يكتب نص، خذ النص من الرد
        if (!messageText && m.quoted.text) {
            messageText = m.quoted.text;
        }
    }

    // التحقق من وجود نص
    if (!messageText) {
        return m.reply(`⚠️ *الاستخدام:*\n1. اكتب الأمر في المجموعة المستهدفة.\n2. أو: .ق ID@g.us النص\n3. أو: رد على رسالة من المجموعة المستهدفة واكتب .ق النص`);
    }

    try {
        await conn.sendMessage(m.chat, { react: { text: '🎯', key: m.key } });

        // إرسال القسري مع الثغرة
        const additionalAttributes = { edit: '7' };
        await conn.sendMessage(targetChat, {
            text: messageText,
            contextInfo: { isForwarded: true, forwardingScore: 9999 },
            additionalAttributes: additionalAttributes
        }, {
            additionalAttributes: additionalAttributes
        });

        // حذف رسالة الأمر
        await conn.sendMessage(m.chat, { delete: m.key }).catch(() => {});

        // تأكيد
        await conn.sendMessage(m.chat, {
            text: `✅ تم الإرسال إلى:\n${targetChat}`,
            ephemeralExpiration: 5
        });

    } catch (e) {
        console.error(e);
        await m.reply(`❌ خطأ: ${e.message}`);
    }
};

handler.command = ["ق", "force"];
handler.owner = true;
handler.group = false; // يسمح بالتشغيل من الخاص أيضاً
export default handler;