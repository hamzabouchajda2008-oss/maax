let handler = async (m, { conn }) => {
    try {
        if (!m.quoted) {
            return m.reply('⌔🔍︙ قـم بـرد عـلـي `الـرسـالـة`- ⌗');
        }

        // 🔧 تحميل الميديا: نجرب .download() أولا، وإيلا فشل نرجعو لـ conn.downloadMediaMessage
        let buffer;
        try {
            buffer = await m.quoted.download();
        } catch (e) {
            try {
                buffer = await conn.downloadMediaMessage(m.quoted);
            } catch (e2) {
                console.log('كشف download error:', e2?.message || e2);
            }
        }

        if (!buffer || !buffer.length) {
            return m.reply('*❌ ماقدرتش نحمل الميديا*');
        }

        // 🔧 كشف النوع: mimetype كيكون موجود دايما (حتى فـ view-once)، بلاصة
        // ما نخمنو اسم wrapper (viewOnceMessage/ephemeralMessage...) اللي كيبدل
        // بين البوتات ومايطابقش دايما نفس البنية
        let mimetype = m.quoted?.mimetype || m.quoted?.msg?.mimetype || '';

        // fallback: إيلا mimetype ماكاينش، نقلبو recursively على أي مفتاح ميديا
        // جوا m.quoted.message بغض النظر شحال ديال التغليف فوقو
        if (!mimetype) {
            const mediaKeys = ['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage'];
            const findMedia = (obj, depth = 0) => {
                if (!obj || typeof obj !== 'object' || depth > 6) return null;
                for (const key of mediaKeys) {
                    if (obj[key]) return { type: key, node: obj[key] };
                }
                for (const key of Object.keys(obj)) {
                    if (obj[key] && typeof obj[key] === 'object') {
                        const found = findMedia(obj[key], depth + 1);
                        if (found) return found;
                    }
                }
                return null;
            };
            const found = findMedia(m.quoted.message || m.quoted);
            if (found) mimetype = found.node?.mimetype || found.type;
        }

        const caption = m.quoted?.caption || m.quoted?.msg?.caption || '';

        if (mimetype.includes('image')) {
            await conn.sendMessage(m.chat, { image: buffer, caption }, { quoted: m });
        } else if (mimetype.includes('video')) {
            await conn.sendMessage(m.chat, { video: buffer, caption }, { quoted: m });
        } else if (mimetype.includes('audio') || mimetype.includes('ogg')) {
            await conn.sendMessage(m.chat, { audio: buffer, mimetype: 'audio/mpeg', ptt: false }, { quoted: m });
        } else {
            console.log('كشف: نوع غير معروف، mimetype/type =', mimetype);
            return m.reply('*❌ نوع الملف غير مدعوم*');
        }
    } catch (e) {
        console.log('كشف error:', e?.message || e);
        m.reply(`*❌ خطأ: ${e.message}*`);
    }
}

handler.help = ['كشف'];
handler.tags = ['جروب'];
handler.command = ['كشف', 'فضح'];
handler.admin = true;
handler.botAdmin = true;
handler.group = true;

export default handler;
