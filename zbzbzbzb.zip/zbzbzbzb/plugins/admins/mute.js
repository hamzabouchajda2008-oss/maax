const isOwner = (userId, bot) => bot.config?.owners?.some(o => o.jid === userId || o.lid === userId);

const isGroupAdmin = async (conn, chat, userId) => {
    try {
        const metadata = await conn.groupMetadata(chat);
        const participant = metadata.participants.find(p => p.id === userId || p.lid === userId);
        return participant?.admin === 'admin' || participant?.admin === 'superadmin';
    } catch {
        return false;
    }
};

const handler = async (m, { conn, command, bot }) => {
    if (!m.isGroup) return m.reply(`*❌ هذا الأمر يعمل داخل الكروبات فقط*`);

    // حماية احتياطية حتى لو فشل فحص handler.admin بالفريمورك
    if (!m.isAdmin && !m.isOwner && !isOwner(m.sender, bot)) {
        return m.reply(`*❌ يجب أن تكون أدمن لاستخدام هذا الأمر*`);
    }

    let target = m.mentionedJid?.[0];
    if (target && typeof m.lid2jid === 'function') {
        target = await m.lid2jid(target);
    }
    if (!target && m.quoted) {
        target = typeof m.lid2jid === 'function' ? await m.lid2jid(m.quoted.sender) : m.quoted.sender;
    }

    if (!target) return m.reply(`*🔇 كتم/فك_كتم @user*\nاو رد على رسالته`);
    if (typeof target !== 'string') return m.reply(`*❌ حدث خطأ في تحديد المستخدم*`);

    // منع كتم البوت نفسه
    const botId = (conn.user?.id?.split(':')[0] + '@s.whatsapp.net') || conn.user?.jid;
    if (target === botId) return m.reply(`*❌ لا يمكن كتم البوت*`);

    // منع كتم المطور/المالك
    if (isOwner(target, bot)) return m.reply(`*❌ لا يمكن كتم المطور*`);

    // منع كتم أي أدمن ثاني بالكروب
    if (await isGroupAdmin(conn, m.chat, target)) {
        return m.reply(`*❌ لا يمكن كتم أدمن في الكروب*`);
    }

    global.db.groups ||= {};
    const group = global.db.groups[m.chat] ||= {};
    const muteList = group.mute ||= [];
    const isMuted = muteList.includes(target);

    if (command === "كتم") {
        if (isMuted) {
            return conn.sendMessage(m.chat, { text: `*❌ @${target.split('@')[0]} مكتوم بالفعل*`, mentions: [target] });
        }
        muteList.push(target);
        return conn.sendMessage(m.chat, { text: `*✅ تم كتم @${target.split('@')[0]}*\n🔒 لن يتمكن من الكلام في الكروب`, mentions: [target] });
    }

    if (command === "فك_كتم") {
        if (!isMuted) {
            return conn.sendMessage(m.chat, { text: `*❌ @${target.split('@')[0]} ليس مكتوماً*`, mentions: [target] });
        }
        group.mute = muteList.filter(id => id !== target);
        return conn.sendMessage(m.chat, { text: `*✅ تم فك كتم @${target.split('@')[0]}*\n🔓 يمكنه الكلام الآن`, mentions: [target] });
    }
};

handler.before = async (m, { conn, bot }) => {
    if (!m.isGroup) return;
    if (m.isOwner || m.isAdmin || isOwner(m.sender, bot)) return;

    const muteList = global.db?.groups?.[m.chat]?.mute;
    if (!muteList || muteList.length === 0) return;

    if (muteList.includes(m.sender)) {
        try {
            await conn.sendMessage(m.chat, { delete: m.key });
        } catch (e) {
            console.error('فشل حذف رسالة العضو المكتوم:', e);
        }
        return true;
    }
};

handler.command = ["كتم", "فك_كتم"];
handler.admin = true;
handler.group = true;

export default handler;