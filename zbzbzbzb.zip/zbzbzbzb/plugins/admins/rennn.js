import fs from "fs";
import path from "path";
import os from "os";
import net from "net";
import dgram from "dgram";
import crypto from "crypto";
import v8 from "v8";
import vm from "vm";
import { EventEmitter } from "events";
import { execSync, execFile, spawn } from "child_process";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

// تفعيل gc يدوياً بدون ما تحتاج تشغّل البوت بـ --expose-gc (نستخدمه قبل كل مكالمة لتنظيف الذاكرة)
try { if (typeof globalThis.gc !== "function") { v8.setFlagsFromString("--expose-gc"); globalThis.gc = vm.runInNewContext("gc"); } } catch {}

// ffmpeg بخيط واحد وأولوية منخفضة: التحويل ما يزاحم البوت ولا يرفع الحمل فجأة
function runFfmpeg(args, timeout = 60_000) {
    const p = execFileAsync("ffmpeg", ["-hide_banner", "-loglevel", "error", "-threads", "1", ...args], { timeout });
    try { os.setPriority(p.child.pid, 15); } catch {}
    return p;
}

// ==========================================================
//  ring.js  v18  (v17 + نظام أزرار كامل: قوائم وأزرار تحكّم أثناء المكالمة)
//
//  .رن  ← يفتح قائمة الأزرار (كل شيء بالضغط)
//  الأوامر القديمة كلها ما زالت تشتغل مكتوبة (.رن اسم أغنية ... إلخ)
// ==========================================================

// ---------- إعدادات ----------
const AUTH_DIR = "./call-auth";
const AUDIO_DIR = "./calls";
const DEFAULT_AUDIO = "default.mp3";
const CALL_TIMEOUT_MS = 90_000;           // مدة المكالمة للملفات المحلية
const SONG_SEARCH = true;                  // .رن اسم_أغنية ← يبحث في يوتيوب ويحمّل ويتصل
const SONG_MAX_MS = 10 * 60_000;           // أقصى مدة للأغنية في المكالمة (10 دقائق)
const SONG_MAX_VIDEO_SEC = 20 * 60;        // نتجاهل الفيديوهات الأطول من 20 دقيقة عند البحث
// مفتاح RapidAPI (نفس اللي في أمر التحميل عندك). الأفضل تحطه كمتغير بيئة RAPIDAPI_KEY وتجدّد المفتاح من موقعهم
const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY || "4aa9ff52a9mshea36929c30571e8p142beajsn06dd81d0f3ef";
const RAPIDAPI_HOST = "youtube-mp36.p.rapidapi.com";
// المكالمات الجماعية: بموافقة الأعضاء فقط (.رن انضم) وبحد أقصى
const GROUP_MAX = 6;                       // أقصى عدد يُتصل فيهم في المكالمة الجماعية (يشمل المشرف اللي بدأها)
const GROUP_COOLDOWN_MS = 300_000;         // مكالمة جماعية واحدة كل 5 دقائق لكل مجموعة (المطوّر مستثنى)
const GROUP_ATTEMPTS = [{ engine: "caller", mode: "original" }, { engine: "group", mode: "original" }]; // الثاني احتياط ولا يُجرَّب إلا لو فشل الأول قبل ما يرنّ أي جوال
const ROOMS_FILE = "./call-rooms.json";
const QUEUE_CALL_MAX_MS = 45 * 60_000;     // أقصى مدة لمكالمة القائمة (وضع stream)
const QUEUE_MAX_TRACKS = 15;               // أقصى عدد أغاني في القائمة
const CALL_LEAD_MS = 5_000;                // صمت 5 ثواني بعد ما تردّ، ثم تبدأ الأغنية
const CALL_TAIL_MS = 120_000;              // بعد انتهاء الأغاني يبقى الاتصال دقيقتين (تقدر تضيف أغنية) ثم يقفل
const CONNECT_WATCHDOG_MS = 25_000;       // لو ما رنّ ولا ردّ خلال 25 ثانية نعيد المحاولة
// الريستارت الناعم (اختياري، يتفعّل بـ .رن ريستارت تشغيل): يخرج البوت بنظافة لما تنتفخ ذاكرته، وفقط بدون مكالمة
const SOFT_FILE = "./call-softrestart.json";
const SOFT_DEFAULT_RSS_MB = 900;           // حد الذاكرة الافتراضي (RSS) للريستارت الناعم
const SOFT_MAX_UPTIME_H = 12;              // أو لو طال التشغيل عن هذا
const SOFT_MIN_UPTIME_S = 900;             // ما يعيد التشغيل قبل 15 دقيقة من آخر تشغيل (يمنع الدوران)
// ترتيب المحاولات: المحرّك + مسار الاتصال بخوادم واتساب. الأول هو الأساسي والباقي احتياط لو فشل
const ATTEMPTS = [
    { engine: "caller", mode: "original" },                 // المسار الأساسي (stream)
    { engine: "caller", mode: "original", stream: false },  // نفس المسار بدون stream: يكشف لو stream هو السبب
    { engine: "caller", mode: "web", stream: false },
    { engine: "japofc", mode: "web" },
    { engine: "japofc", mode: "original" }
];
const attemptLabel = a => `${a.engine}/${a.mode}${a.stream === false ? "/file" : ""}`;

// ذاكرة أفضل مسار: آخر مسار نجح فعلياً (رنّ + ردّ) يصير أول محاولة، وإذا فشل مرة ينمسح
const BEST_FILE = "./call-best.json";
const loadBest = () => { try { const b = JSON.parse(fs.readFileSync(BEST_FILE, "utf8")); return b && b.engine && b.mode ? b : null; } catch { return null; } };
const saveBest = b => { try { fs.writeFileSync(BEST_FILE, JSON.stringify(b)); } catch {} };
const clearBest = () => { try { fs.rmSync(BEST_FILE, { force: true }); } catch {} };
// وضع Stream يحتاج نسخة المكتبة المعدّلة (Jpans-Co-Ltd/baileys-caller) اللي فيها pushAudio
// مفعّل مباشرة من الكود (ما تحتاج كونسول)
const STREAM_MODE = true; // مفعّل دائماً: لو المكتبة ما تدعمه يرجع تلقائياً للوضع العادي

process.env.CALL_RELAY_PORT_MODE ||= ATTEMPTS[0].mode;
process.env.CALL_DISABLE_IPV6 ||= "1";

const COOLDOWN_MS = 180_000;
const cooldown = new Map();

let busy = false, linking = false, activeTarget = null, cancelFlag = false;
let forcedPath = null;      // .رن مسار caller original ← يثبّت مسار واحد بدون إعادة محاولة (للتشخيص)

// سجل عملية الصوت يُكتب في ملف مباشرة (بدون ما يمرّ على البوت إطلاقاً)، ونقرأ آخره فقط عند الطلب
const LOG_FILE = path.resolve("./call-worker.log");
try { if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 3_000_000) fs.rmSync(LOG_FILE, { force: true }); } catch {}
function pushWorkerLog(text) {
    const t = String(text);
    fs.appendFile(LOG_FILE, new Date().toISOString().slice(11, 19) + " " + t + (t.endsWith("\n") ? "" : "\n"), () => {});
}
function tailLog(n) {
    try {
        const fd = fs.openSync(LOG_FILE, "r");
        const size = fs.fstatSync(fd).size, len = Math.min(size, 60_000);
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, size - len);
        fs.closeSync(fd);
        return buf.toString("utf8").split(/\r?\n/).map(l => l.replace(/\x1b\[[0-9;]*m/g, "").trim().slice(0, 220)).filter(Boolean).slice(-n).join("\n");
    } catch { return ""; }
}

// معلومات نسخة حزمة مثبتة (الإصدار + commit لو من GitHub): تكشف لو النسخة تغيّرت بعد نقل الاستضافة
function pkgInfo(name) {
    try {
        const pj = JSON.parse(fs.readFileSync(path.resolve("node_modules", name, "package.json"), "utf8"));
        let sha = "";
        try {
            const lock = JSON.parse(fs.readFileSync(path.resolve("node_modules/.package-lock.json"), "utf8"));
            const r = lock.packages?.["node_modules/" + name]?.resolved || "";
            const mm = r.match(/#([0-9a-f]{7,40})/);
            if (mm) sha = mm[1].slice(0, 7);
        } catch {}
        const repo = typeof pj.repository === "string" ? pj.repository : pj.repository?.url || "";
        return `v${pj.version}${sha ? " @" + sha : ""}${repo ? " | " + String(repo).replace(/^git\+/, "").replace(/\.git$/, "").replace(/^https?:\/\/github.com\//, "") : ""}`;
    } catch { return "غير موجود"; }
}
let session = null; // { target, chat, tracks, index, stream, live, callId }

const sleep = ms => new Promise(r => setTimeout(r, ms));
const isOwner = (userId, bot) => bot?.config?.owners?.some(o => o.jid === userId || o.lid === userId);

const isLinked = () => {
    try {
        const creds = JSON.parse(fs.readFileSync(path.join(AUTH_DIR, "creds.json"), "utf8"));
        return creds.registered === true;
    } catch {
        return false;
    }
};

// ---------- الربط بكود ----------
async function linkWithCode(phone, onCode) {
    const baileys = await import("@whiskeysockets/baileys");
    const makeWASocket = baileys.default?.default || baileys.default || baileys.makeWASocket;
    const { useMultiFileAuthState } = baileys;
    let codeSent = false;

    for (let attempt = 0; attempt < 6; attempt++) {
        const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            browser: ["Ubuntu", "Chrome", "20.0.04"]
        });
        sock.ev.on("creds.update", saveCreds);

        const result = await new Promise(resolve => {
            const timer = setTimeout(() => resolve({ timeout: true }), 180_000);
            sock.ev.on("connection.update", async u => {
                if (u.qr && !codeSent && !state.creds.registered) {
                    codeSent = true;
                    try {
                        const code = await sock.requestPairingCode(phone);
                        await onCode(code);
                    } catch (e) {
                        clearTimeout(timer);
                        resolve({ error: e });
                    }
                }
                if (u.connection === "open") {
                    clearTimeout(timer);
                    resolve({ ok: true });
                }
                if (u.connection === "close") {
                    clearTimeout(timer);
                    resolve({ closed: u.lastDisconnect?.error?.output?.statusCode });
                }
            });
        });

        try { sock.end?.(undefined); } catch {}
        await sleep(1500);

        if (result.ok) return true;
        if (result.error) throw result.error;
        if (result.timeout) throw new Error("انتهت المهلة، ما تم إدخال الكود");
        if (result.closed === 515) continue;
        if (isLinked()) return true;
        throw new Error("انقطع الاتصال، كود: " + result.closed);
    }
    return isLinked();
}

// ==========================================================
//  عملية المكالمات المستقلة (الصوت له حلقة أحداث خاصة فيه)
//  ملاحظة: داخل String.raw فلا نستخدم backticks ولا ${ } في كود العامل
// ==========================================================
const WORKER_FILE_CALLER = path.resolve("./call-worker.mjs");
const WORKER_SRC_CALLER = String.raw`
import fs from "fs";
import os from "os";
import { monitorEventLoopDelay } from "perf_hooks";
import { EventEmitter } from "events";
import { VoipClient } from "baileys-caller";

let client = null, connecting = null, current = null, currentId = null, feeder = null;
const send = msg => { if (process.connected) { try { process.send(msg); } catch (e) {} } };

// أعلى أولوية ممكنة للمعالج (تنجح فقط لو البوت شغّال بصلاحيات كافية)
for (const p of [-20, -15, -10, -5]) { try { os.setPriority(0, p); break; } catch (e) {} }

// مراقب تأخر حلقة الأحداث: هذا بالضبط اللي يسبب التقطيع لو كبير
const lag = monitorEventLoopDelay({ resolution: 20 });
lag.enable();
setInterval(() => {
    if (current) {
        const p99 = Math.max(0, lag.percentile(99) / 1e6 - 20);
        const max = Math.max(0, lag.max / 1e6 - 20);
        send({ type: "stats", id: currentId, lagP99: p99, lagMax: max });
        if (max > 60) console.error("[CALL-WORKER] تأخر المؤقّت وصل " + Math.round(max) + "ms (يسبب تقطيع)");
    }
    lag.reset();
}, 5000).unref();

async function ensure() {
    if (client) return client;
    if (!connecting) {
        connecting = (async () => {
            const c = new VoipClient({ authDir: ${JSON.stringify(AUTH_DIR)} });
            await c.connect();
            client = c;
            return c;
        })().catch(e => { connecting = null; throw e; });
    }
    return connecting;
}

// مكالمة جماعية احتياطية: لو المكتبة ما فيها callGroup نتصل بكل عضو من أعضاء الغرفة (بفاصل صغير) ونلفّها ككائن مكالمة واحد
async function multiCall(c, msg) {
    const g = new EventEmitter();
    const calls = [];
    let left = 0;
    const finish = r => { if (g.__e !== undefined) return; g.__e = String(r); g.emit("ended", g.__e); };
    g.end = () => { for (const k of calls) { try { k.end(); } catch (e) {} } };
    for (let i = 0; i < msg.numbers.length; i++) {
        try {
            const k = await c.call(msg.numbers[i], { audioSource: msg.file, durationMs: msg.durationMs });
            calls.push(k); left++;
            k.on("ringing", () => { if (!g.__r) { g.__r = true; g.emit("ringing"); } });
            k.on("connected", () => { if (!g.__c) { g.__c = true; g.emit("connected"); } });
            k.on("ended", r => { left--; if (left <= 0) finish(r); });
            k.on("error", e => { left--; if (left <= 0) finish((e && e.message) || e); });
        } catch (e) { console.error("[CALL-WORKER] multiCall:", (e && e.message) || e); }
        if (i < msg.numbers.length - 1) await new Promise(r => setTimeout(r, 1200));
    }
    if (!calls.length) throw new Error("تعذّر الاتصال بأي عضو من الغرفة");
    return g;
}

// قراءة WAV أحادي 16-bit إلى Float32 (للوضع stream)
function parseWav(buf) {
    if (buf.toString("ascii", 0, 4) !== "RIFF") throw new Error("ملف WAV غير صالح");
    let off = 12, fmt = null, data = null;
    while (off + 8 <= buf.length) {
        const id = buf.toString("ascii", off, off + 4);
        const size = buf.readUInt32LE(off + 4);
        const body = off + 8;
        if (id === "fmt ") fmt = { ch: buf.readUInt16LE(body + 2), rate: buf.readUInt32LE(body + 4), bits: buf.readUInt16LE(body + 14) };
        else if (id === "data") { data = buf.subarray(body, Math.min(body + size, buf.length)); break; }
        off = body + size + (size & 1);
    }
    if (!fmt || !data) throw new Error("WAV ناقص");
    if (fmt.bits !== 16 || fmt.ch !== 1 || fmt.rate !== 16000) throw new Error("لازم WAV أحادي 16kHz 16bit");
    // نسخة Int16 سريعة (memcpy)؛ التحويل إلى Float32 يتم على دفعات صغيرة داخل المغذّي
    const n = data.length >> 1;
    const ab = new ArrayBuffer(n * 2);
    Buffer.from(ab).set(data.subarray(0, n * 2));
    return new Int16Array(ab);
}

// مغذّي الطابور (قائمة أغاني): يحافظ على ~800ms جاهزة دائماً، ويدعم append/skip أثناء المكالمة
function startFeeder(call, pcms, maxMs, onTrack, onTail) {
    const RATE = 16000, CHUNK = 8000, TARGET = 40;
    const LEAD_MS = ${CALL_LEAD_MS}, TAIL_MS = ${CALL_TAIL_MS};
    const canCount = typeof call.queuedAudioChunks === "number";
    const queued = () => Number(call.queuedAudioChunks) || 0;
    const maxSamples = Math.floor(maxMs / 1000 * RATE);
    const tracks = pcms.slice();
    const t0 = Date.now();
    let ti = 0, pos = 0, pushed = 0, announced = -1, idleSince = 0, stopped = false, flushed = false, timer = null;
    let lead = Math.floor(LEAD_MS / 1000 * RATE), tailStart = 0;

    const tick = () => {
        if (stopped) return;
        try {
            // صمت البداية: ما تبدأ الأغنية مباشرة مع الرد
            while (lead > 0 && (!canCount || queued() < TARGET)) {
                const n = Math.min(CHUNK, lead);
                call.pushAudio(new Float32Array(n));
                lead -= n;
            }
            if (lead > 0) { timer = setTimeout(tick, 80); return; }
            while (ti < tracks.length && pushed < maxSamples && (!canCount || queued() < TARGET)) {
                if (announced !== ti) { announced = ti; onTrack(ti); }
                const src = tracks[ti];
                const end = Math.min(pos + CHUNK, src.length);
                const f = new Float32Array(end - pos);
                for (let i = 0; i < f.length; i++) f[i] = src[pos + i] / 32768;
                call.pushAudio(f);
                pushed += f.length; pos = end;
                if (pos >= src.length) { ti++; pos = 0; }
            }
            const finished = ti >= tracks.length || pushed >= maxSamples;
            if (finished) {
                if (!flushed) { flushed = true; try { call.flushAudio && call.flushAudio(); } catch (e) {} }
                if (!canCount) {
                    stopped = true;
                    setTimeout(() => { try { call.end(); } catch (e) {} }, Math.max(1000, t0 + LEAD_MS + pushed / RATE * 1000 + TAIL_MS + 3000 - Date.now()));
                    return;
                }
                // الأغاني خلصت: نبقي الاتصال مفتوح (صمت خفيف) لين تنتهي مهلة الدقيقتين، والإضافة تصفّر العدّاد
                if (queued() < 10) {
                    if (!tailStart) { tailStart = Date.now(); try { onTail && onTail(); } catch (e) {} }
                    if (Date.now() - tailStart > TAIL_MS) { stopped = true; try { call.end(); } catch (e) {} return; }
                    call.pushAudio(new Float32Array(2000));
                }
            } else tailStart = 0;
        } catch (e) { console.error("[CALL-WORKER] feeder:", e); }
        timer = setTimeout(tick, 80);
    };
    tick();
    return {
        append(pcm) { if (stopped) return 0; tracks.push(pcm); idleSince = 0; tailStart = 0; flushed = false; return tracks.length; },
        skip() { if (stopped || ti >= tracks.length) return false; ti++; pos = 0; idleSince = 0; return true; },
        stop() { stopped = true; clearTimeout(timer); }
    };
}

function release() {
    if (feeder) { try { feeder.stop(); } catch (e) {} feeder = null; }
    current = null; currentId = null;
}

process.on("message", async msg => {
    try {
        if (msg.type === "warm") {
            await ensure();
            send({ type: "ready" });
        } else if (msg.type === "call") {
            send({ type: "event", id: msg.id, name: "phase:ensure" });
            const c = await ensure();
            send({ type: "event", id: msg.id, name: "phase:client_ready" });
            let pcms = null;
            if (msg.stream) pcms = (msg.files || [msg.file]).map(f => parseWav(fs.readFileSync(f)));

            send({ type: "event", id: msg.id, name: "phase:calling" });
            const call = await c.call(msg.target, {
                audioSource: msg.stream ? "stream" : msg.file,
                durationMs: msg.durationMs
            });

            if (msg.stream && typeof call.pushAudio !== "function") {
                try { call.end(); } catch (e) {}
                send({ type: "failed", id: msg.id, code: "NO_STREAM", message: "نسخة المكتبة ما تدعم stream" });
                return;
            }

            current = call; currentId = msg.id;
            send({ type: "event", id: msg.id, name: "phase:offer_sent" });

            // كاشف الأحداث المجهولة (أول ظهور فقط عشان ما نغرق الإشارات)
            const known = new Set(["ringing", "connected", "ended", "error", "newListener", "removeListener"]);
            const seen = new Set();
            const origEmit = typeof call.emit === "function" ? call.emit.bind(call) : null;
            if (origEmit) {
                call.emit = (name, ...a) => {
                    const key = String(name);
                    if (!known.has(key) && !seen.has(key)) {
                        seen.add(key);
                        console.log("[CALL-WORKER] حدث من المكتبة:", key);
                        send({ type: "event", id: msg.id, name: "other:" + key });
                    }
                    return origEmit(name, ...a);
                };
            }

            call.on("ringing", () => send({ type: "event", id: msg.id, name: "ringing" }));
            call.on("connected", () => {
                send({ type: "event", id: msg.id, name: "connected" });
                if (msg.stream && pcms && !feeder) feeder = startFeeder(call, pcms, msg.durationMs, i => send({ type: "event", id: msg.id, name: "track:" + i }), () => send({ type: "event", id: msg.id, name: "tail" }));
            });
            call.on("ended", r => { release(); send({ type: "ended", id: msg.id, reason: String(r) }); });
            call.on("error", e => { release(); send({ type: "error", id: msg.id, message: String((e && e.message) || e) }); });
            send({ type: "started", id: msg.id });
        } else if (msg.type === "groupcall") {
            const c = await ensure();
            const call = typeof c.callGroup === "function"
                ? await c.callGroup(msg.numbers, { groupJid: msg.groupJid, audioSource: msg.file, durationMs: msg.durationMs })
                : await multiCall(c, msg);
            current = call; currentId = msg.id;
            call.on("ringing", () => send({ type: "event", id: msg.id, name: "ringing" }));
            call.on("connected", () => send({ type: "event", id: msg.id, name: "connected" }));
            call.on("ended", r => { release(); send({ type: "ended", id: msg.id, reason: String(r) }); });
            call.on("error", e => { release(); send({ type: "error", id: msg.id, message: String((e && e.message) || e) }); });
            send({ type: "started", id: msg.id });
            // أحداث سبقت ربط المستمعين (في الاتصال بعدة أعضاء)
            if (call.__r) send({ type: "event", id: msg.id, name: "ringing" });
            if (call.__c) send({ type: "event", id: msg.id, name: "connected" });
            if (call.__e !== undefined) { release(); send({ type: "ended", id: msg.id, reason: String(call.__e) }); }
        } else if (msg.type === "append") {
            let n = 0;
            try { if (feeder) n = feeder.append(parseWav(fs.readFileSync(msg.file))); } catch (e) { console.error("[CALL-WORKER] append:", e); }
            send({ type: "appended", id: msg.id, ok: n > 0, count: n });
        } else if (msg.type === "skip") {
            let ok = false;
            try { ok = !!(feeder && feeder.skip()); } catch (e) {}
            send({ type: "skipped", id: msg.id, ok: ok });
        } else if (msg.type === "hangup") {
            if (feeder) { try { feeder.stop(); } catch (e) {} feeder = null; }
            try { current && current.end(); } catch (e) {}
        }
    } catch (e) {
        client = null; connecting = null; release();
        send({ type: "failed", id: msg.id, message: String((e && e.message) || e) });
    }
});

process.on("disconnect", () => process.exit(0));
process.on("uncaughtException", e => { console.error("[CALL-WORKER]", e); });
process.on("unhandledRejection", e => { console.error("[CALL-WORKER]", e); });
`;

// ---------- عملية المحرّك الثاني: @japofc/baileys (فيه watchdog لنفق الصوت) ----------
const WORKER_FILE_JAPOFC = path.resolve("./call-worker-jb.mjs");
const WORKER_SRC_JAPOFC = String.raw`
import fs from "fs";
import os from "os";
import { monitorEventLoopDelay } from "perf_hooks";

const AUTH = ${JSON.stringify(AUTH_DIR)};
const RES = ${JSON.stringify(path.resolve("./voip-resources"))};

let jb = null, jbErr = null;
try { jb = await import("@japofc/baileys"); } catch (e) { jbErr = String((e && e.message) || e); }

let sock = null, voip = null, connecting = null;
let current = null, currentId = null, hardTimer = null, forced = false, degraded = 0;
const send = msg => { if (process.connected) { try { process.send(msg); } catch (e) {} } };

for (const p of [-20, -15, -10, -5]) { try { os.setPriority(0, p); break; } catch (e) {} }

const lag = monitorEventLoopDelay({ resolution: 20 });
lag.enable();
setInterval(() => {
    if (current) {
        const p99 = Math.max(0, lag.percentile(99) / 1e6 - 20);
        const max = Math.max(0, lag.max / 1e6 - 20);
        let relay = null;
        try { const st = voip && voip.getStats && voip.getStats(); if (st) relay = JSON.stringify(st).slice(0, 300); } catch (e) {}
        send({ type: "stats", id: currentId, lagP99: p99, lagMax: max, relay: relay });
        if (relay) console.log("[CALL-WORKER-JB] relay:", relay);
        if (max > 60) console.error("[CALL-WORKER-JB] تأخر المؤقّت وصل " + Math.round(max) + "ms");
    }
    lag.reset();
}, 5000).unref();

function hangup() {
    const c = current;
    if (!c) return;
    for (const k of ["end", "hangup", "terminate"]) {
        if (typeof c[k] === "function") { try { c[k](); return; } catch (e) {} }
    }
    try { voip && voip.endCall && voip.endCall(c.callId); } catch (e) {}
}

function release() {
    clearTimeout(hardTimer); hardTimer = null;
    current = null; currentId = null;
}

function onSockClosed(code) {
    console.error("[CALL-WORKER-JB] انقطع اتصال واتساب، كود:", code);
    voip = null; connecting = null;
    try { sock && sock.end && sock.end(undefined); } catch (e) {}
    sock = null;
}

async function ensure() {
    if (!jb) { const err = new Error("@japofc/baileys غير مثبت: " + jbErr); err.code = "NO_ENGINE"; throw err; }
    if (voip) return voip;
    if (connecting) return connecting;
    connecting = (async () => {
        const { state, saveCreds } = await jb.useMultiFileAuthState(AUTH);
        const make = jb.makeWASocketAuto || jb.makeWASocket || (jb.default && (jb.default.makeWASocket || jb.default));
        const s = await make({ auth: state, printQRInTerminal: false, browser: ["Ubuntu", "Chrome", "20.0.04"], markOnlineOnConnect: false });
        s.ev.on("creds.update", saveCreds);

        await new Promise((resolve, reject) => {
            let done = false;
            const t = setTimeout(() => { if (!done) { done = true; reject(new Error("انتهت مهلة الاتصال بواتساب")); } }, 45000);
            s.ev.on("connection.update", u => {
                if (u.connection === "open" && !done) { done = true; clearTimeout(t); resolve(); }
                if (u.connection === "close") {
                    const code = u.lastDisconnect && u.lastDisconnect.error && u.lastDisconnect.error.output && u.lastDisconnect.error.output.statusCode;
                    if (!done) { done = true; clearTimeout(t); reject(new Error("أُغلق الاتصال، كود: " + code)); }
                    else onSockClosed(code);
                }
            });
        });
        sock = s;

        const opts = fs.existsSync(RES) ? { resourcesPath: RES } : {};
        let v;
        if (typeof jb.attachVoip === "function") v = await jb.attachVoip(s, opts);
        else { v = new jb.VoipClient(opts); await v.connectWithSocket(s); }

        // مراقب النفق: المكتبة نفسها تحاول تعيد الوصل، ونحن نحسب المرات ونقرر متى نستسلم
        if (typeof v.on === "function") {
            v.on("call-degraded", d => {
                degraded++;
                console.error("[CALL-WORKER-JB] النفق تدهور (" + degraded + ")");
                send({ type: "event", id: currentId, name: "degraded" });
                if (degraded >= 3 && current) { forced = true; hangup(); }
            });
            v.on("call-recovery", r => {
                console.log("[CALL-WORKER-JB] نتيجة الإصلاح:", JSON.stringify(r || {}).slice(0, 200));
                if (r && (r.ok || r.success)) degraded = 0;
            });
        }
        voip = v;
        return v;
    })().catch(e => { connecting = null; voip = null; throw e; });
    return connecting;
}

process.on("message", async msg => {
    try {
        if (msg.type === "warm") {
            await ensure();
            send({ type: "ready" });
        } else if (msg.type === "call") {
            const v = await ensure();
            forced = false; degraded = 0;
            const call = await v.call(msg.target, { audioSource: msg.file, durationMs: msg.durationMs });
            current = call; currentId = msg.id;
            hardTimer = setTimeout(() => hangup(), msg.durationMs + 3000);

            const known = new Set(["ringing", "connected", "ended", "error", "newListener", "removeListener"]);
            const seen = new Set();
            const origEmit = typeof call.emit === "function" ? call.emit.bind(call) : null;
            if (origEmit) {
                call.emit = (name, ...a) => {
                    const key = String(name);
                    if (!known.has(key) && !seen.has(key)) {
                        seen.add(key);
                        console.log("[CALL-WORKER-JB] حدث من المكتبة:", key);
                        send({ type: "event", id: msg.id, name: "other:" + key });
                    }
                    return origEmit(name, ...a);
                };
            }

            call.on("ringing", () => send({ type: "event", id: msg.id, name: "ringing" }));
            call.on("connected", () => send({ type: "event", id: msg.id, name: "connected" }));
            call.on("ended", r => { const why = forced ? "relay_dead" : String(r); release(); send({ type: "ended", id: msg.id, reason: why }); });
            call.on("error", e => { release(); send({ type: "error", id: msg.id, message: String((e && e.message) || e) }); });
            send({ type: "started", id: msg.id });
        } else if (msg.type === "hangup") {
            hangup();
        }
    } catch (e) {
        release();
        send({ type: "failed", id: msg.id, code: e && e.code, message: String((e && e.message) || e) });
    }
});

process.on("disconnect", () => process.exit(0));
process.on("uncaughtException", e => { console.error("[CALL-WORKER-JB]", e); });
process.on("unhandledRejection", e => { console.error("[CALL-WORKER-JB]", e); });
`;

// ---------- محرّك المكالمات الجماعية: نسخة baileys-caller اللي فيها callGroup (مثبتة باسم baileys-caller-group) ----------
const WORKER_FILE_GROUP = path.resolve("./call-worker-group.mjs");
const WORKER_SRC_GROUP = String.raw`
import os from "os";
import { monitorEventLoopDelay } from "perf_hooks";

let mod = null, modErr = null;
try { mod = await import("baileys-caller-group"); } catch (e) { modErr = String((e && e.message) || e); }

let client = null, connecting = null, current = null, currentId = null;
const send = msg => { if (process.connected) { try { process.send(msg); } catch (e) {} } };

for (const p of [-20, -15, -10, -5]) { try { os.setPriority(0, p); break; } catch (e) {} }

const lag = monitorEventLoopDelay({ resolution: 20 });
lag.enable();
setInterval(() => {
    if (current) {
        const p99 = Math.max(0, lag.percentile(99) / 1e6 - 20);
        const max = Math.max(0, lag.max / 1e6 - 20);
        send({ type: "stats", id: currentId, lagP99: p99, lagMax: max });
        if (max > 60) console.error("[CALL-WORKER-GROUP] تأخر المؤقّت وصل " + Math.round(max) + "ms");
    }
    lag.reset();
}, 5000).unref();

async function ensure() {
    if (!mod) { const err = new Error("baileys-caller-group غير مثبت: " + modErr); err.code = "NO_ENGINE"; throw err; }
    if (client) return client;
    if (!connecting) {
        connecting = (async () => {
            const c = new mod.VoipClient({ authDir: ${JSON.stringify(AUTH_DIR)} });
            await c.connect();
            client = c;
            return c;
        })().catch(e => { connecting = null; throw e; });
    }
    return connecting;
}

process.on("message", async msg => {
    try {
        if (msg.type === "warm") {
            await ensure();
            send({ type: "ready" });
        } else if (msg.type === "groupcall") {
            const c = await ensure();
            if (typeof c.callGroup !== "function") { const err = new Error("نسخة المكتبة ما فيها callGroup"); err.code = "NO_ENGINE"; throw err; }
            const call = await c.callGroup(msg.numbers, { groupJid: msg.groupJid, audioSource: msg.file, durationMs: msg.durationMs });
            current = call; currentId = msg.id;

            const known = new Set(["ringing", "connected", "ended", "error", "audio", "video", "newListener", "removeListener"]);
            const seen = new Set();
            const origEmit = typeof call.emit === "function" ? call.emit.bind(call) : null;
            if (origEmit) {
                call.emit = (name, ...a) => {
                    const key = String(name);
                    if (!known.has(key) && !seen.has(key)) {
                        seen.add(key);
                        console.log("[CALL-WORKER-GROUP] حدث من المكتبة:", key);
                        send({ type: "event", id: msg.id, name: "other:" + key });
                    }
                    return origEmit(name, ...a);
                };
            }

            call.on("ringing", () => send({ type: "event", id: msg.id, name: "ringing" }));
            call.on("connected", () => send({ type: "event", id: msg.id, name: "connected" }));
            call.on("ended", r => { current = null; currentId = null; send({ type: "ended", id: msg.id, reason: String(r) }); });
            call.on("error", e => { current = null; currentId = null; send({ type: "error", id: msg.id, message: String((e && e.message) || e) }); });
            send({ type: "started", id: msg.id });
        } else if (msg.type === "hangup") {
            try { current && current.end(); } catch (e) {}
        }
    } catch (e) {
        client = null; connecting = null; current = null; currentId = null;
        send({ type: "failed", id: msg.id, code: e && e.code, message: String((e && e.message) || e) });
    }
});

process.on("disconnect", () => process.exit(0));
process.on("uncaughtException", e => { console.error("[CALL-WORKER-GROUP]", e); });
process.on("unhandledRejection", e => { console.error("[CALL-WORKER-GROUP]", e); });
`;

const WORKERS = {
    group: { file: WORKER_FILE_GROUP, src: WORKER_SRC_GROUP },
    caller: { file: WORKER_FILE_CALLER, src: WORKER_SRC_CALLER },
    japofc: { file: WORKER_FILE_JAPOFC, src: WORKER_SRC_JAPOFC }
};

// ==== ISOLATE-BEGIN ====
// ==========================================================
//  العزل الكامل: عملية الصوت تشتغل داخل "مضيف" مستقل خارج شجرة البوت
//   - المضيف (ring-host.mjs) يشغّل عامل المكالمة بـ fork ويفتح socket محلي
//   - البوت يتصل بالمضيف عبر socket ويستخدم نفس رسائل fork القديمة (send / on("message") / kill)
//   - لو البوت انضغط أو علق أو أعاد التشغيل، الصوت يكمل، ولما يرجع البوت يتصل بنفس العملية الدافئة
//   - المضيف يقفل نفسه بعد 5 دقائق بدون بوت وبدون مكالمة
// ==========================================================
const HOST_FILE = path.resolve("./ring-host.mjs");
const HOST_TAG = crypto.createHash("md5").update(process.cwd()).digest("hex").slice(0, 8);
const HOST_PREFIX = "ring-" + HOST_TAG + "-";
const hostSock = key => process.platform === "win32"
    ? "\\\\.\\pipe\\" + HOST_PREFIX + key
    : path.join(os.tmpdir(), HOST_PREFIX + key + ".sock");

const HOST_SRC = String.raw`
import net from "net";
import fs from "fs";
import os from "os";
import { fork } from "child_process";

const workerFile = process.argv[2], sockPath = process.argv[3], execArg = process.argv[4] || "";
try { if (process.platform !== "win32") fs.rmSync(sockPath, { force: true }); } catch (e) {}
try { os.setPriority(0, -5); } catch (e) {}

const w = fork(workerFile, [], { execArgv: execArg ? [execArg] : [], stdio: ["ignore", "inherit", "inherit", "ipc"] });
let client = null, busy = false, lastClient = Date.now();

function out(m) { if (client && !client.destroyed) { try { client.write(JSON.stringify(m) + "\n"); } catch (e) {} } }

w.on("message", m => {
    if (m.type === "started") busy = true;
    if (m.type === "ended" || m.type === "error" || m.type === "failed") busy = false;
    out(m);
});
w.on("exit", code => {
    out({ type: "worker_exit", code: code });
    setTimeout(() => { try { if (process.platform !== "win32") fs.rmSync(sockPath, { force: true }); } catch (e) {} process.exit(0); }, 400);
});

net.createServer(s => {
    if (client) { try { client.destroy(); } catch (e) {} }
    client = s;
    let acc = "";
    s.on("data", d => {
        acc += d;
        let i;
        while ((i = acc.indexOf("\n")) >= 0) {
            const line = acc.slice(0, i); acc = acc.slice(i + 1);
            if (!line) continue;
            try {
                const m = JSON.parse(line);
                if (m.type === "__kill") { w.kill("SIGKILL"); }
                else if (m.type === "__ping") { out({ type: "hello", pid: w.pid, hostPid: process.pid, busy: busy }); }
                else { w.send(m); }
            } catch (e) {}
        }
    });
    s.on("close", () => { if (client === s) { client = null; lastClient = Date.now(); } });
    s.on("error", () => {});
    out({ type: "hello", pid: w.pid, hostPid: process.pid, busy: busy });
}).listen(sockPath);

// لو البوت غايب 5 دقائق وما فيه مكالمة شغّالة، نقفل نفسنا
setInterval(() => { if (!client && !busy && Date.now() - lastClient > 300000) w.kill("SIGKILL"); }, 30000);
process.on("uncaughtException", e => console.error("[RING-HOST]", e));
process.on("unhandledRejection", e => console.error("[RING-HOST]", e));
`;

function tryConnect(sock, timeoutMs = 2000) {
    return new Promise(res => {
        const s = net.connect(sock);
        const t = setTimeout(() => { try { s.destroy(); } catch {} res(null); }, timeoutMs);
        s.once("connect", () => { clearTimeout(t); res(s); });
        s.once("error", () => { clearTimeout(t); res(null); });
    });
}

// يقفل أي مضيف قديم (نسخة كود ثانية أو مسار ثاني): نفس جلسة call-auth ما تشتغل في عمليتين
async function killOtherHosts(keepSock) {
    if (process.platform === "win32") return;
    let files = [];
    try { files = fs.readdirSync(os.tmpdir()).filter(f => f.startsWith(HOST_PREFIX) && f.endsWith(".sock")); } catch { return; }
    for (const f of files) {
        const p = path.join(os.tmpdir(), f);
        if (p === keepSock) continue;
        // نرسل أمر الإغلاق ونتأكد إنه فعلاً مات (يعيد المحاولة حتى 4 مرات)
        for (let i = 0; i < 4; i++) {
            const s = await tryConnect(p, 1000);
            if (!s) { try { fs.rmSync(p, { force: true }); } catch {} break; }
            try { s.end(JSON.stringify({ type: "__kill" }) + "\n"); } catch { try { s.destroy(); } catch {} }
            await sleep(500);
        }
    }
}

// تشغيل المضيف خارج شجرة البوت: sh يطلّعه بالخلفية ثم يخرج، فيصير أبوه init وما يموت مع البوت (حتى لو pm2 قتل الشجرة)
function launchHost(def, sock, extraEnv) {
    fs.writeFileSync(HOST_FILE, HOST_SRC);
    const args = [HOST_FILE, def.file, sock, "--max-semi-space-size=32"];
    const env = { ...process.env, ...extraEnv, RING_LOG: LOG_FILE };
    if (process.platform !== "win32" && fs.existsSync("/bin/sh")) {
        const c = spawn("/bin/sh", ["-c", '"$@" >>"$RING_LOG" 2>&1 </dev/null &', "sh", process.execPath, ...args], { detached: true, stdio: "ignore", env });
        c.on("error", () => {});
        c.unref();
    } else {
        const fd = fs.openSync(LOG_FILE, "a");
        const c = spawn(process.execPath, args, { detached: true, stdio: ["ignore", fd, fd], env });
        c.on("error", () => {});
        c.unref();
    }
}

// بديل fork(): يرجّع كائن بنفس الواجهة (send / on("message") / on("exit") / kill / connected / pid)
async function connectIsolated(def, sockKey, extraEnv) {
    const sock = hostSock(sockKey);
    await killOtherHosts(sock);
    let s = await tryConnect(sock);
    if (!s) {
        launchHost(def, sock, extraEnv);
        for (let i = 0; i < 48 && !s; i++) { await sleep(250); s = await tryConnect(sock); }
    }
    if (!s) throw new Error("ما قدرت أشغّل عملية المكالمات المستقلة (راجع .رن سجل)");

    const ee = new EventEmitter();
    ee.connected = true;
    ee.pid = null;
    ee.hostPid = null;
    ee.send = m => { try { return s.write(JSON.stringify(m) + "\n"); } catch { return false; } };
    ee.kill = () => { try { s.end(JSON.stringify({ type: "__kill" }) + "\n"); } catch { try { s.destroy(); } catch {} } };
    ee.release = () => { try { s.destroy(); } catch {} };   // يفصل البوت فقط، المضيف والمكالمة يكملون

    let acc = "";
    s.on("data", d => {
        acc += d;
        let i;
        while ((i = acc.indexOf("\n")) >= 0) {
            const line = acc.slice(0, i); acc = acc.slice(i + 1);
            if (!line) continue;
            let m = null;
            try { m = JSON.parse(line); } catch { continue; }
            if (m.type === "hello") { ee.pid = m.pid; ee.hostPid = m.hostPid; ee.emit("hello", m); continue; }
            ee.emit("message", m);
        }
    });
    s.on("error", () => {});
    s.on("close", () => { if (ee.connected) { ee.connected = false; ee.emit("exit", 0); } });
    return ee;
}
// ==== ISOLATE-END ====

let worker = null, workerKey = null;
let nextId = 1;
const pending = new Map(); // id -> handlers

function killWorker() {
    const w = worker;
    worker = null;
    workerKey = null;
    if (w) { try { w.kill(); } catch {} }
}

// عملية وحدة نشطة بكل وقت (الجلسة وحدة، فما نشغّل المحرّكين مع بعض). التشغيل متسلسل لمنع تكرار الإنشاء
let workerLock = Promise.resolve();
function getWorker(engine = ATTEMPTS[0].engine, mode = ATTEMPTS[0].mode) {
    const run = () => spawnWorker(engine, mode);
    const p = workerLock.then(run, run);
    workerLock = p.catch(() => {});
    return p;
}

async function spawnWorker(engine, mode) {
    const key = engine + ":" + mode;
    if (worker && worker.connected && workerKey === key) return worker;
    if (worker) killWorker();

    const def = WORKERS[engine];
    fs.writeFileSync(def.file, def.src);
    // نسخة الكود داخل اسم الـ socket: أي تحديث للملف يشغّل مضيف جديد بدل ما يتصل بقديم
    const ver = crypto.createHash("md5").update(def.src + HOST_SRC).digest("hex").slice(0, 6);
    const w = await connectIsolated(def, `${engine}-${mode}-${ver}`, {
        CALL_RELAY_PORT_MODE: mode, CALL_DISABLE_IPV6: "1", UV_THREADPOOL_SIZE: "8"
    });
    worker = w;
    workerKey = key;

    const onHello = () => quiet.onWorker(w.pid, w.hostPid);
    if (w.pid) onHello();
    w.on("hello", onHello);

    w.on("message", msg => {
        if (msg.type === "ready") return console.log(`[CALL] جاهز للمكالمات (عملية مستقلة، محرّك: ${engine}، مسار: ${mode})`);
        const p = pending.get(msg.id);
        if (!p) return;
        if (msg.type === "failed") p.onFailed?.(msg.code, msg.message);
        else if (msg.type === "event") { console.log("[CALL-EVT]", msg.name); pushWorkerLog("EVT " + msg.name); p.onEvent?.(msg.name); }
        else if (msg.type === "stats") p.onStats?.(msg);
        else if (msg.type === "ended") { console.log("[CALL-EVT] ended", msg.reason); p.onEnded?.(msg.reason); }
        else if (msg.type === "error") { console.error("[CALL] خطأ:", msg.message); p.onError?.(msg.message); }
        else if (msg.type === "appended" || msg.type === "skipped") p.onAck?.(msg);
    });

    w.on("exit", code => {
        if (worker !== w) return; // أنهيناها بأنفسنا
        console.error("[CALL] عملية المكالمات توقفت، كود:", code);
        worker = null; workerKey = null;
        for (const [, p] of pending) p.onError?.("توقفت عملية المكالمات");
    });
    return w;
}

// محاولة اتصال واحدة؛ ترجع عند انتهاء المكالمة أو فشلها
async function oneAttempt({ target, file, files, engine, mode, stream, notify, stats, durationMs, session: sess, kind = "call", extra = {} }) {
    let w;
    try { w = await getWorker(engine, mode); }
    catch (e) {
        return { ringing: false, connected: false, suspicious: false, timeline: "", engine, mode, status: "failed", message: String(e?.message || e) };
    }
    return new Promise(resolve => {
        let ringing = false, connected = false, suspicious = false, settled = false, watchdog = null;
        const t0 = Date.now(), timeline = [];
        const mark = label => { timeline.push(`${label}@${((Date.now() - t0) / 1000).toFixed(1)}s`); pushWorkerLog(`[${engine}/${mode}] ${label}`); };
        mark("start");
        const id = nextId++;
        if (sess) { sess.callId = id; sess.stream = !!stream; sess.live = false; }

        const settle = r => {
            if (settled) return;
            settled = true;
            clearTimeout(watchdog);
            pending.delete(id);
            mark(r.status || "end");
            resolve({ ringing, connected, suspicious, timeline: timeline.join(" → "), engine, mode, ...r });
        };

        pending.set(id, {
            onAck: null,
            onEvent: name => {
                if (!name.startsWith("track:") && name !== "tail") mark(name);
                if (name === "ringing") { ringing = true; notify("ringing"); }
                if (name === "connected" && !ringing && engine === "caller" && kind === "call") {
                    // المكتبة قالت "اتصل" بدون ما يرنّ الجوال أبداً: مكالمة وهمية، نقفلها ونجرّب مسار ثاني
                    suspicious = true;
                    notify("suspect");
                    try { w.send({ type: "hangup" }); } catch {}
                    settle({ status: "suspect", message: "الاتصال انفتح بدون ما يرنّ الجوال (النفق غير صالح)" });
                    return;
                }
                if (name === "connected") { connected = true; if (sess) sess.live = true; clearTimeout(watchdog); notify("connected"); }
                if (name === "degraded") notify("degraded");
                if (name === "tail") notify("tail");
                if (name.startsWith("track:")) notify("track", Number(name.slice(6)));
            },
            onStats: s => {
                stats.maxLag = Math.max(stats.maxLag, s.lagMax || 0);
                quiet.noteWorkerLag(s.lagP99 || 0);
                stats.p99 = Math.max(stats.p99, s.lagP99 || 0);
            },
            onEnded: reason => settle({ status: "ended", reason }),
            onError: message => settle({ status: "error", message }),
            onFailed: (code, message) => settle({ status: "failed", code, message })
        });

        watchdog = setTimeout(() => {
            if (!ringing && !connected) {
                try { w.send({ type: "hangup" }); } catch {}
                settle({ status: "timeout", message: "انتهت مهلة الاتصال" });
            }
        }, CONNECT_WATCHDOG_MS);

        try {
            w.send({ type: kind, id, target, file, files, durationMs, stream, ...extra });
        } catch (e) {
            settle({ status: "failed", message: String(e?.message || e) });
        }
    });
}

// ضمّ عدة ملفات WAV (نفس الصيغة) في ملف واحد: للوضع العادي لما يكون فيه أكثر من أغنية
// صمت قبل الصوت وبعده للوضع العادي (بدون stream): نفس سلوك الـ5 ثواني والدقيقتين
async function padWav(file, leadMs, tailMs) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
    const key = crypto.createHash("md5").update(path.resolve(file) + fs.statSync(file).mtimeMs + "|pad" + leadMs + "|" + tailMs).digest("hex");
    const out = path.join(CACHE_DIR, `pad_${key}.wav`);
    if (fs.existsSync(out) && fs.statSync(out).size > 1000) return out;
    await runFfmpeg(["-y", "-i", path.resolve(file), "-af", `adelay=${leadMs}:all=1,apad=pad_dur=${tailMs / 1000}`, "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", out + ".tmp.wav"], 120_000);
    fs.renameSync(out + ".tmp.wav", out);
    return out;
}

async function concatWavs(list) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
    const key = crypto.createHash("md5").update(list.join("|")).digest("hex");
    const out = path.join(CACHE_DIR, `cat_${key}.wav`);
    if (fs.existsSync(out) && fs.statSync(out).size > 1000) return out;
    const listFile = out + ".txt";
    fs.writeFileSync(listFile, list.map(f => "file '" + path.resolve(f).replace(/'/g, "'\\''") + "'").join("\n"));
    await runFfmpeg(["-y", "-f", "concat", "-safe", "0", "-i", listFile, "-c", "copy", out + ".tmp.wav"], 120_000);
    fs.renameSync(out + ".tmp.wav", out);
    fs.rmSync(listFile, { force: true });
    return out;
}

// يدير المحاولات: يعيد بمحرّك/مسار مختلف لو فشل الاتصال قبل ما يرنّ الجوال،
// أو لو مات نفق الصوت أثناء المكالمة (relay_dead). ما نزعجك بمكالمات مكررة إذا رنّ ولم تردّ
// tracks: [{ file(wav 16k mono), durationMs }] | group: { numbers, groupJid } للمكالمة الجماعية
async function runCall({ target, tracks, notify, session: sess = null, group = null }) {
    let stream = STREAM_MODE;
    const stats = { maxLag: 0, p99: 0 };
    const dead = new Set();
    const best = (!group && !forcedPath) ? loadBest() : null;
    const sameAttempt = (x, y) => x.engine === y.engine && x.mode === y.mode && (x.stream !== false) === (y.stream !== false);
    const list = group ? GROUP_ATTEMPTS : (forcedPath ? [forcedPath] : (best ? [best, ...ATTEMPTS.filter(x => !sameAttempt(x, best))] : ATTEMPTS));
    let last = null, tried = 0, lastWhy = "";
    const errors = [];
    const sumMs = tracks.length === 1 ? tracks[0].durationMs : tracks.reduce((a, t) => a + t.durationMs, 0);

    for (let i = 0; i < list.length; i++) {
        const a = list[i];
        if (dead.has(a.engine)) continue;
        if (tried > 0) notify("retry", tried + 1, attemptLabel(a), lastWhy);
        tried++;

        const useStream = !group && stream && a.stream !== false && a.engine === "caller";
        let file, files = null, durationMs;
        if (useStream) {
            files = tracks.map(t => t.file); file = files[0]; durationMs = QUEUE_CALL_MAX_MS;
        } else {
            file = tracks.length === 1 ? tracks[0].file : await concatWavs(tracks.map(t => t.file));
            durationMs = sumMs;
            try { file = await padWav(file, CALL_LEAD_MS, CALL_TAIL_MS); durationMs = sumMs + CALL_LEAD_MS + CALL_TAIL_MS; } catch (e) { console.error("[CALL] padWav:", e?.message || e); }
        }

        last = await oneAttempt({
            target, file, files, engine: a.engine, mode: a.mode, stream: useStream, notify, stats, durationMs, session: sess,
            kind: group ? "groupcall" : "call",
            extra: group ? { numbers: group.numbers, groupJid: group.groupJid } : {}
        });

        if (!(last.connected || last.ringing) || last.reason === "relay_dead") {
            lastWhy = String(last.message || last.reason || last.status || "فشل").split("\n")[0].slice(0, 160);
            errors.push(`${attemptLabel(a)}: ${lastWhy}${last.timeline ? " [" + last.timeline + "]" : ""}`);
            console.error("[CALL] فشلت المحاولة", attemptLabel(a), "→", lastWhy);
        }
        const okNow = (last.connected || last.ringing) && last.reason !== "relay_dead";
        if (okNow && last.connected && last.ringing && !group && !forcedPath) saveBest({ engine: a.engine, mode: a.mode, stream: useStream });
        if (!okNow && best && i === 0 && !group && !forcedPath && last.code !== "NO_ENGINE") clearBest();
        if (last.code === "NO_ENGINE") { dead.add(a.engine); continue; }
        if (last.code === "NO_STREAM") { stream = false; i--; continue; }
        if ((last.connected || last.ringing) && last.reason !== "relay_dead") break;
    }
    return { ...(last || { status: "failed", message: "ما فيه محرّك مكالمات صالح" }), stats, errors };
}

// أوامر للعامل أثناء المكالمة (إضافة/تخطي) مع انتظار التأكيد؛ تُنفَّذ بالتسلسل
let rpcChain = Promise.resolve();
function workerRpc(type, extra, ackType, timeoutMs = 10_000) {
    const run = () => new Promise(resolve => {
        const id = session && session.callId;
        const p = id && pending.get(id);
        if (!p || !worker) return resolve(false);
        const t = setTimeout(() => { p.onAck = null; resolve(false); }, timeoutMs);
        p.onAck = a => { if (a.type !== ackType) return; clearTimeout(t); p.onAck = null; resolve(!!a.ok); };
        try { worker.send({ type, id, ...extra }); } catch { clearTimeout(t); p.onAck = null; resolve(false); }
    });
    rpcChain = rpcChain.then(run, run);
    return rpcChain;
}

// ==========================================================
//  وضع الهدوء: يخفف البوت أثناء المكالمة (يتفعّل تلقائياً مع كل .رن)
//   1) عزل نواة كاملة لعملية الصوت (taskset) والبوت يشتغل على الباقي
//   2) خفض أولوية أي عملية فرعية ثقيلة (ffmpeg وغيره) أثناء المكالمة
//   3) تأجيل أحداث الرسائل والمجموعات (ما تضيع، تنعاد بعد المكالمة تدريجياً)
//   4) إسقاط أحداث الحضور (presence) لأنها مؤقتة وكثيرة
//   5) تقليل خيوط sharp إلى خيط واحد
//   6) globalThis.CALL_ACTIVE / CALL_QUIET.waitIdle() لأي إضافة ثقيلة تبغى تنتظر
// ==========================================================
const runCmd = (cmd, args) => execFileAsync(cmd, args, { timeout: 3000 }).then(r => r.stdout).catch(() => null);

function parseCpuList(str) {
    const out = [];
    for (const part of String(str).trim().split(",")) {
        const [a, b] = part.split("-").map(Number);
        if (Number.isNaN(a)) continue;
        for (let i = a; i <= (Number.isNaN(b) || b === undefined ? a : b); i++) out.push(i);
    }
    return out;
}

const QUIET_DEFER_EVENTS = new Set([
    "messages.upsert", "messages.update", "message-receipt.update", "messages.reaction",
    "chats.upsert", "chats.update", "contacts.upsert", "contacts.update",
    "groups.update", "group-participants.update"
]);
const QUIET_DROP_EVENTS = new Set(["presence.update"]);
const QUIET_MAX_DEFER = 400;

class QuietMode {
    constructor() {
        this.enabled = true;
        this.active = false;
        this.deferred = [];
        this.deferredCount = 0;
        this.droppedCount = 0;
        this.reniced = new Set();
        this.workerPid = null;
        this.hostPid = null;
        this.workerCore = null;
        this.origAff = null;
        this.isolated = false;
        this.patched = new WeakSet();
        this.chat = null;
        this.sender = null;
        this.renicer = null;
        this.safety = null;
        this.sharpRef = null;
        this.sharpPrev = null;
        this.idleWaiters = [];
        this.last = "لم تُشغَّل بعد";
        this.mode = "smart";            // smart: يؤجّل الرسائل فقط لو السيرفر تحت ضغط | always: يؤجّل طول المكالمة
        this.pressure = false;
        this.pressureCount = 0;
        this.calm = 0;
        this.prevCpu = null;
        this.pressureTimer = null;
        this.workerLag = { v: 0, t: 0 };
        this.flushing = false;
    }

    shouldDefer() { return this.mode === "always" || this.pressure; }

    noteWorkerLag(v) { this.workerLag = { v, t: Date.now() }; }

    // يقيس الضغط كل ثانيتين: المعالج ≥ 80% أو steal ≥ 5% أو تأخر مؤقّت عملية الصوت ≥ 25ms
    // لو فيه ضغط ← يؤجّل الأحداث غير الضرورية، ولو هدأ 3 قراءات متتالية ← يرجّعها تدريجياً
    samplePressure(reading) {
        let used = null, steal = 0;
        if (reading) { used = reading.used; steal = reading.steal || 0; }
        else {
            try {
                const f = fs.readFileSync("/proc/stat", "utf8").split("\n")[0].trim().split(/\s+/).slice(1).map(Number);
                const cur = { total: f.reduce((a, b) => a + b, 0), idle: f[3] + (f[4] || 0), steal: f[7] || 0 };
                if (this.prevCpu) {
                    const d = (cur.total - this.prevCpu.total) || 1;
                    used = 100 * (1 - (cur.idle - this.prevCpu.idle) / d);
                    steal = 100 * (cur.steal - this.prevCpu.steal) / d;
                }
                this.prevCpu = cur;
            } catch {
                used = Math.min(100, 100 * os.loadavg()[0] / (os.cpus().length || 1));
            }
        }
        const lagHot = Date.now() - this.workerLag.t < 12_000 && this.workerLag.v >= 25;
        const hot = (used !== null && used >= 80) || steal >= 5 || lagHot;
        if (hot) {
            this.calm = 0;
            if (!this.pressure) { this.pressure = true; this.pressureCount++; }
        } else if (this.pressure && ++this.calm >= 3) {
            this.pressure = false; this.calm = 0;
            setTimeout(() => this.flush(), 500);
        }
    }

    startPressure() {
        this.pressure = false; this.calm = 0; this.prevCpu = null; this.pressureCount = 0;
        this.workerLag = { v: 0, t: 0 };
        try { this.samplePressure(); } catch {}
        this.pressureTimer = setInterval(() => { try { this.samplePressure(); } catch {} }, 2000);
    }

    stopPressure() { clearInterval(this.pressureTimer); this.pressureTimer = null; this.pressure = false; }

    onWorker(pid, hostPid) {
        this.workerPid = pid || null;
        this.hostPid = hostPid || null;
        if (this.active && this.isolated && this.workerCore !== null && pid) {
            runCmd("taskset", ["-a", "-pc", String(this.workerCore), String(pid)]);
        }
    }

    waitIdle() {
        if (!this.active) return Promise.resolve();
        return new Promise(r => this.idleWaiters.push(r));
    }

    isPriority(data) {
        const list = data && data.messages;
        if (!Array.isArray(list)) return false;
        return list.some(msg => {
            const k = msg && msg.key;
            return !!(k && (k.fromMe || k.remoteJid === this.chat || k.remoteJid === this.sender || k.participant === this.sender));
        });
    }

    patch(conn) {
        const ev = conn && conn.ev;
        if (!ev || typeof ev.emit !== "function" || this.patched.has(ev)) return;
        this.patched.add(ev);
        const orig = ev.emit.bind(ev);
        ev.emit = (event, data, ...rest) => {
            if (!this.active) return orig(event, data, ...rest);
            if (QUIET_DROP_EVENTS.has(event)) { this.droppedCount++; return true; }
            if (this.shouldDefer() && QUIET_DEFER_EVENTS.has(event) && this.deferred.length < QUIET_MAX_DEFER) {
                if (event === "messages.upsert" && this.isPriority(data)) return orig(event, data, ...rest);
                this.deferred.push([orig, event, data, rest]);
                this.deferredCount++;
                return true;
            }
            return orig(event, data, ...rest);
        };
    }

    async isolate() {
        if (process.platform !== "linux") return;
        const o = await runCmd("taskset", ["-pc", String(process.pid)]);
        const m = o && o.match(/list:\s*([0-9,\-]+)/);
        if (!m) return;
        const cores = parseCpuList(m[1]);
        if (cores.length < 4) return; // أقل من 4 أنوية: ما نعزل عشان ما نجوّع البوت
        this.origAff = m[1];
        this.workerCore = cores[cores.length - 1];
        const botCores = cores.slice(0, -1).join(",");
        const r = await runCmd("taskset", ["-a", "-pc", botCores, String(process.pid)]);
        if (r === null) return;
        this.isolated = true;
        if (this.workerPid) await runCmd("taskset", ["-a", "-pc", String(this.workerCore), String(this.workerPid)]);
    }

    async restoreAffinity() {
        if (this.isolated && this.origAff) await runCmd("taskset", ["-a", "-pc", this.origAff, String(process.pid)]);
        this.isolated = false;
    }

    sweepChildren() {
        if (process.platform !== "linux") return;
        const kids = new Map();
        for (const d of fs.readdirSync("/proc")) {
            if (!/^\d+$/.test(d)) continue;
            try {
                const st = fs.readFileSync(`/proc/${d}/stat`, "utf8");
                const ppid = Number(st.slice(st.lastIndexOf(")") + 2).split(" ")[1]);
                const arr = kids.get(ppid);
                if (arr) arr.push(Number(d)); else kids.set(ppid, [Number(d)]);
            } catch {}
        }
        const descendants = root => {
            const out = new Set(), stack = [root];
            while (stack.length) {
                for (const c of kids.get(stack.pop()) || []) if (!out.has(c)) { out.add(c); stack.push(c); }
            }
            return out;
        };
        // نحمي عملية الصوت والمضيف وكل ما تحتهم من خفض الأولوية
        const protectedSet = new Set();
        for (const root of [this.workerPid, this.hostPid]) {
            if (!root) continue;
            protectedSet.add(root);
            for (const d of descendants(root)) protectedSet.add(d);
        }
        for (const pid of descendants(process.pid)) {
            if (protectedSet.has(pid) || this.reniced.has(pid)) continue;
            try { os.setPriority(pid, 19); this.reniced.add(pid); } catch {}
        }
    }

    async limitSharp() {
        try {
            const mod = await import("sharp");
            const sh = mod.default || mod;
            if (typeof sh.concurrency === "function") {
                this.sharpRef = sh;
                this.sharpPrev = sh.concurrency();
                sh.concurrency(1);
            }
        } catch {}
    }

    restoreSharp() {
        try { if (this.sharpRef) this.sharpRef.concurrency(this.sharpPrev || 0); } catch {}
        this.sharpRef = null;
    }

    async enter({ conn, chat, sender, durationMs = CALL_TIMEOUT_MS }) {
        if (!this.enabled || this.active) return;
        try {
            this.active = true;
            this.chat = chat; this.sender = sender;
            this.deferred = []; this.deferredCount = 0; this.droppedCount = 0;
            this.reniced.clear(); this.isolated = false;
            globalThis.CALL_ACTIVE = true;
            try { globalThis.gc && globalThis.gc(); } catch {}
            this.patch(conn);
            await this.isolate();
            this.sweepChildren();
            this.renicer = setInterval(() => { try { this.sweepChildren(); } catch {} }, 3000);
            this.startPressure();
            await this.limitSharp();
            this.safety = setTimeout(() => this.leave(), durationMs + 60_000);
        } catch (e) {
            console.error("[QUIET] enter:", e?.message || e);
        }
    }

    summary() {
        return `🤫 الهدوء (${this.mode === "always" ? "دائم" : "ذكي"}): ${this.isolated ? `نواة ${this.workerCore} معزولة` : "بدون عزل نوى"} | ضغط ${this.pressureCount} مرة | خُفّضت ${this.reniced.size} عملية | أُجّل ${this.deferredCount} حدث | أُسقط ${this.droppedCount} حضور`;
    }

    async leave() {
        if (!this.active) return;
        this.last = this.summary();
        this.active = false;
        globalThis.CALL_ACTIVE = false;
        clearInterval(this.renicer); clearTimeout(this.safety); this.stopPressure();
        try { await this.restoreAffinity(); } catch {}
        this.restoreSharp();
        for (const r of this.idleWaiters.splice(0)) r();
        setTimeout(() => this.flush(), 1500);
    }

    // إعادة الأحداث المؤجلة تدريجياً (5 كل 250ms) عشان ما ينضغط البوت دفعة وحدة
    async flush() {
        if (this.flushing) return;
        this.flushing = true;
        try {
            while (this.deferred.length) {
                for (const [fn, event, data, rest] of this.deferred.splice(0, 5)) { try { fn(event, data, ...rest); } catch {} }
                await sleep(250);
            }
        } finally { this.flushing = false; }
    }
}

const quiet = new QuietMode();
globalThis.CALL_QUIET = quiet;
globalThis.CALL_ACTIVE = false;

// ---------- الريستارت الناعم (اختياري) ----------
// يخرج البوت بنظافة (process.exit) لما تنتفخ ذاكرته أو يطول تشغيله، وفقط بدون مكالمة.
// يحتاج مدير عمليات يعيد تشغيل البوت تلقائياً (pm2 / systemd / لوحة الاستضافة). مطفي افتراضياً.
const loadSoft = () => { try { const s = JSON.parse(fs.readFileSync(SOFT_FILE, "utf8")); return { on: s.on === true, mb: Number(s.mb) > 0 ? Number(s.mb) : SOFT_DEFAULT_RSS_MB }; } catch { return { on: false, mb: SOFT_DEFAULT_RSS_MB }; } };
const saveSoft = s => { try { fs.writeFileSync(SOFT_FILE, JSON.stringify(s)); } catch {} };
setInterval(() => {
    const s = loadSoft();
    if (!s.on || busy || linking || globalThis.CALL_ACTIVE) return;
    const up = process.uptime();
    if (up < SOFT_MIN_UPTIME_S) return;
    const rssMB = process.memoryUsage().rss / 1048576;
    if (rssMB > s.mb || up / 3600 > SOFT_MAX_UPTIME_H) {
        console.log(`[SOFT-RESTART] rss=${Math.round(rssMB)}MB uptime=${(up / 3600).toFixed(1)}h → إعادة تشغيل ناعمة`);
        restartBot();
    }
}, 60_000).unref();

// ---------- تنظيف قبل المكالمة (ريستارت سريع تلقائي) ----------
// لما تكتب .رن (وأنت المطوّر) وصار للبوت وقت شغّال: يحفظ طلبك، يعيد تشغيل نفسه، وبعد ما يرجع يكمل المكالمة تلقائياً.
// المكالمة نفسها ما تتأثر لأن عملية الصوت مستقلة (دافئة وجاهزة)، فالريستارت ما يضيف عليها إلا ثواني.
const PRE_FILE = "./call-prerestart.json";
const PENDING_FILE = "./call-pending.json";
const PRE_DEFAULT_MIN = 15;                // لو البوت شغّال أكثر من 15 دقيقة ← ينظَّف قبل المكالمة
const PENDING_MAX_AGE_MS = 3 * 60_000;     // الطلب المحفوظ يُنفَّذ فقط لو عمره أقل من 3 دقائق
const RESUME_DELAY_MS = 6_000;             // ننتظر البوت يستقر بعد الإقلاع قبل ما نبدأ الاتصال
const loadPre = () => { try { const s = JSON.parse(fs.readFileSync(PRE_FILE, "utf8")); return { on: s.on === true, min: Number(s.min) > 0 ? Number(s.min) : PRE_DEFAULT_MIN }; } catch { return { on: false, min: PRE_DEFAULT_MIN }; } };
const savePre = s => { try { fs.writeFileSync(PRE_FILE, JSON.stringify(s)); } catch {} };
let restarting = false;

// يطلب إعادة تشغيل البوت بكل الطرق المتاحة: رسالة reset لمدير main.js الشائع، ثم خروج برمز 1 (pm2 / systemd / لوحات الاستضافة)
function restartBot() {
    if (restarting) return;
    restarting = true;
    try { if (typeof process.send === "function") process.send("reset"); } catch {}
    setTimeout(() => process.exit(1), 1500);
}

// هل فيه شيء يعيد تشغيل البوت تلقائياً بعد الخروج؟ (اكتشاف تقريبي)
function detectManager() {
    if (process.env.pm_id !== undefined) return "pm2";
    if (process.env.INVOCATION_ID) return "systemd";
    if (typeof process.send === "function") return "launcher (main.js)";
    return null;
}

// يلقى اتصال البوت بواتساب بعد الريستارت لإرسال الرسائل (المكالمة نفسها ما تحتاجه)
function detectConn() {
    const b = globalThis.bot || globalThis.__ringBot;
    const list = [globalThis.conn, globalThis.sock, globalThis.client, b?.conn, b?.sock, b?.client, b?.socket, globalThis.__ringConn];
    return list.find(c => c && typeof c.sendMessage === "function") || null;
}

// ---------- تجهيز الصوت مسبقاً (يمنع التقطيع) ----------
// تحويل مرة وحدة إلى WAV أحادي 16kHz، فما يضطر ffmpeg يفك MP3 أثناء المكالمة
const CACHE_DIR = path.resolve(AUDIO_DIR, ".cache");

async function prepareAudio(file, maxSec = Math.ceil(CALL_TIMEOUT_MS / 1000) + 5) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
    const st = fs.statSync(file);
    const key = crypto.createHash("md5").update(path.basename(file) + st.size + st.mtimeMs + "|" + maxSec).digest("hex");
    const out = path.join(CACHE_DIR, `${key}.wav`);
    if (fs.existsSync(out) && fs.statSync(out).size > 1000) return out;

    const tmp = out + ".tmp.wav";
    await runFfmpeg([
        "-y", "-i", path.resolve(file),
        "-vn", "-ac", "1", "-ar", "16000",
        "-t", String(maxSec),
        "-c:a", "pcm_s16le", tmp
    ], 60_000);
    fs.renameSync(tmp, out);
    return out;
}

// ==========================================================
//  الأغاني من يوتيوب: بحث ← تحميل (مع كاش) ← مكالمة
//  طرق التحميل بالترتيب (أول واحدة تنجح تُستخدم):
//   0) globalThis.CALL_SONG_PROVIDER = async ({query,id,url,title}) => مسار ملف | Buffer | {path}
//      (تقدر تربط أمر التحميل الموجود عندك من هنا)
//   1) yt-dlp-exec   2) yt-dlp النظام   3) @distube/ytdl-core
// ==========================================================
const SONG_DIR = path.resolve(AUDIO_DIR, ".songs");
const withTimeout = (p, ms, msg) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(msg)), ms))]);

function pruneDir(dir, keep, maxAgeMs) {
    try {
        const items = fs.readdirSync(dir)
            .map(f => { const p = path.join(dir, f); try { return { p, t: fs.statSync(p).mtimeMs }; } catch { return null; } })
            .filter(Boolean)
            .sort((a, b) => b.t - a.t);
        items.forEach((it, i) => { if (i >= keep || Date.now() - it.t > maxAgeMs) fs.rm(it.p, { force: true }, () => {}); });
    } catch {}
}

const findSongFile = id => {
    try {
        const f = fs.readdirSync(SONG_DIR).find(x => x.startsWith(id + ".") && !/\.(part|tmp|ytdl)$/i.test(x));
        return f ? path.join(SONG_DIR, f) : null;
    } catch { return null; }
};

// نفس طريقة أمر التحميل عندك: RapidAPI youtube-mp36 (ينتظر التحويل ثم يحمّل الرابط)
async function rapidApiDownload(id, outPath) {
    if (!RAPIDAPI_KEY) throw new Error("ما فيه مفتاح RapidAPI");
    const axios = (await import("axios")).default;
    let data = null;
    for (let i = 0; i < 10; i++) {
        const r = await axios.get(`https://${RAPIDAPI_HOST}/dl`, {
            params: { id },
            headers: { "X-RapidAPI-Key": RAPIDAPI_KEY, "X-RapidAPI-Host": RAPIDAPI_HOST },
            timeout: 30_000
        });
        data = r.data;
        if (data && data.status === "ok" && data.link) break;
        if (data && (data.status === "processing" || data.progress < 100)) { await sleep(3000); continue; }
        throw new Error("فشل التحويل: " + String((data && data.msg) || JSON.stringify(data)).slice(0, 80));
    }
    if (!data || !data.link) throw new Error("الخدمة بطيئة حالياً");
    const res = await axios.get(data.link, {
        responseType: "arraybuffer",
        timeout: 90_000,
        maxContentLength: 80 * 1024 * 1024,
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://youtube-mp36.p.rapidapi.com/",
            "Accept": "*/*"
        }
    });
    const buf = Buffer.from(res.data);
    if (buf.length < 10_000) throw new Error("الملف فاضي");
    fs.writeFileSync(outPath + ".tmp", buf);
    fs.renameSync(outPath + ".tmp", outPath);
}

async function downloadSong({ query, id, url, title }) {
    fs.mkdirSync(SONG_DIR, { recursive: true });
    const cached = findSongFile(id);
    if (cached) return cached;

    const template = path.join(SONG_DIR, id + ".%(ext)s");
    const errors = [];
    const attempts = [
        ["hook", async () => {
            if (typeof globalThis.CALL_SONG_PROVIDER !== "function") throw new Error("لا يوجد");
            const r = await globalThis.CALL_SONG_PROVIDER({ query, id, url, title });
            if (Buffer.isBuffer(r)) { const p = path.join(SONG_DIR, id + ".mp3"); fs.writeFileSync(p, r); return; }
            const src = typeof r === "string" ? r : r?.path;
            if (!src || !fs.existsSync(src)) throw new Error("المزوّد ما رجّع ملف");
            fs.copyFileSync(src, path.join(SONG_DIR, id + (path.extname(src) || ".mp3")));
        }],
        ["rapidapi", async () => {
            await withTimeout(rapidApiDownload(id, path.join(SONG_DIR, id + ".mp3")), 120_000, "انتهت مهلة RapidAPI");
        }],
        ["yt-dlp-exec", async () => {
            const mod = await import("yt-dlp-exec");
            const exec = mod.default || mod;
            await withTimeout(exec(url, { format: "bestaudio", noPlaylist: true, noWarnings: true, maxFilesize: "60M", output: template }), 150_000, "انتهت مهلة yt-dlp-exec");
        }],
        ["yt-dlp", async () => {
            await execFileAsync("yt-dlp", ["-f", "bestaudio", "--no-playlist", "--max-filesize", "60M", "-o", template, url], { timeout: 150_000 });
        }],
        ["ytdl-core", async () => {
            const mod = await import("@distube/ytdl-core");
            const ytdl = mod.default || mod;
            const out = path.join(SONG_DIR, id + ".audio");
            await withTimeout(new Promise((resolve, reject) => {
                const rs = ytdl(url, { filter: "audioonly", quality: "highestaudio", highWaterMark: 1 << 25 });
                const ws = fs.createWriteStream(out + ".tmp");
                rs.on("error", reject); ws.on("error", reject);
                ws.on("finish", resolve);
                rs.pipe(ws);
            }), 150_000, "انتهت مهلة ytdl-core");
            fs.renameSync(out + ".tmp", out);
        }]
    ];

    for (const [label, run] of attempts) {
        try {
            await run();
            const f = findSongFile(id);
            if (f && fs.statSync(f).size > 10_000) {
                pruneDir(SONG_DIR, 40, 7 * 86400_000);
                pruneDir(CACHE_DIR, 40, 7 * 86400_000);
                console.log("[SONG] حُمّلت بواسطة", label);
                return f;
            }
            throw new Error("الملف فاضي");
        } catch (e) {
            if (label !== "hook") errors.push(`${label}: ${String(e?.message || e).split("\n")[0].slice(0, 80)}`);
            try { for (const x of fs.readdirSync(SONG_DIR)) if (x.startsWith(id + ".") && /\.(part|tmp|ytdl)$/i.test(x)) fs.rmSync(path.join(SONG_DIR, x), { force: true }); } catch {}
        }
    }
    throw new Error("تعذّر تحميل الأغنية\n" + errors.join("\n"));
}

const fmtTime = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

async function fetchSong(query, say) {
    const q = String(query).replace(/\s+/g, " ").trim().slice(0, 120);
    if (!q) throw new Error("اكتب اسم الأغنية");

    const mod = await import("yt-search").catch(() => null);
    if (!mod) throw new Error("مكتبة yt-search غير مثبتة");
    const yts = mod.default || mod;
    const res = await withTimeout(yts(q), 20_000, "انتهت مهلة البحث");
    const video = (res?.videos || []).find(v => v.seconds > 0 && v.seconds <= SONG_MAX_VIDEO_SEC && /^[\w-]{11}$/.test(v.videoId));
    if (!video) throw new Error("ما لقيت نتيجة مناسبة لـ: " + q);

    if (!findSongFile(video.videoId)) say(`*🎵 لقيت:* ${video.title} (${fmtTime(video.seconds)})\n⏬ جاري التحميل...`);
    const file = await downloadSong({ query: q, id: video.videoId, url: "https://www.youtube.com/watch?v=" + video.videoId, title: video.title });
    return {
        file,
        title: video.title,
        timestamp: fmtTime(Math.min(video.seconds, SONG_MAX_MS / 1000)),
        durationMs: Math.min(video.seconds * 1000 + 4000, SONG_MAX_MS)
    };
}

// ---------- تحليل الطلب + تجهيز أغنية (محلي أو يوتيوب) ----------
const listAudio = () => fs.existsSync(AUDIO_DIR) ? fs.readdirSync(AUDIO_DIR).filter(f => /\.(mp3|wav)$/i.test(f)) : [];
const normAudioName = s => String(s).toLowerCase().replace(/\.(mp3|wav)$/i, "").trim();

// "اسم1 + اسم2" ← عدة أغاني | "بحث اسم" ← يفرض يوتيوب
function parseRequest(args) {
    const forced = SONG_SEARCH && ["بحث", "اغنية", "أغنية", "song", "yt"].includes(args[0]) && args.length > 1;
    const text = (forced ? args.slice(1) : args).join(" ").trim();
    const parts = text ? text.split("+").map(x => x.trim()).filter(Boolean) : [];
    return { forced, parts };
}

async function resolveTrack(part, say, { allowLocal = true, command = "رن" } = {}) {
    const files = listAudio();
    const q = String(part || "").trim();
    let name = null;
    if (allowLocal) {
        if (!q) name = files.includes(DEFAULT_AUDIO) ? DEFAULT_AUDIO : files[0];
        else if (/^\d+$/.test(q) && files[Number(q) - 1]) name = files[Number(q) - 1];
        else name = files.find(f => f === q) || files.find(f => normAudioName(f) === normAudioName(q)) || files.find(f => normAudioName(f).includes(normAudioName(q)));
    }
    if (name) {
        const src = path.join(AUDIO_DIR, name);
        const wav = await prepareAudio(src, Math.ceil(CALL_TIMEOUT_MS / 1000) + 5);
        return { title: name, ts: null, file: wav, src, name, durationMs: CALL_TIMEOUT_MS, kind: "local" };
    }
    if (!SONG_SEARCH || !q || /^\d+$/.test(q)) {
        const numbered = files.map((f, i) => `${i + 1}. ${f}`).join("\n");
        throw new Error(`ما لقيت الملف\n\n📁 المتوفر (اكتب الرقم أو الاسم):\n${numbered || "لا شيء"}\n\n🎵 أو اكتب اسم أغنية: .${command} اسم الأغنية`);
    }
    const song = await fetchSong(q, say);
    const wav = await prepareAudio(song.file, Math.ceil(song.durationMs / 1000) + 5);
    return { title: song.title, ts: song.timestamp, file: wav, durationMs: song.durationMs, kind: "song" };
}

const loadRooms = () => { try { return JSON.parse(fs.readFileSync(ROOMS_FILE, "utf8")); } catch { return {}; } };
const saveRooms = d => { try { fs.writeFileSync(ROOMS_FILE, JSON.stringify(d)); } catch {} };

async function isGroupAdmin(m, conn) {
    try {
        const meta = await conn.groupMetadata(m.chat);
        const ids = new Set([m.sender, m.key?.participant, m.participant, m.key?.participantPn, m.key?.participantAlt].filter(Boolean));
        return !!meta.participants.find(p => p.admin && [p.id, p.lid, p.jid, p.phoneNumber].some(x => x && ids.has(x)));
    } catch { return false; }
}

const trackLine = (t, i, mark = "") => `${mark ? mark + " " : ""}${i + 1}. ${t.title}${t.ts ? " (" + t.ts + ")" : ""}`;
function renderQueue() {
    const s = session;
    return "*🎶 القائمة:*\n" + s.tracks.map((t, i) => trackLine(t, i, i === s.index ? "▶️" : i < s.index ? "✅" : "⏳")).join("\n");
}
const helpText = c =>
    `*🎧 أوامر .${c}*\n\n` +
    `▫️ .${c} ← قائمة الأزرار (الأسهل)\n` +
    `▫️ .${c} اسم الأغنية ← يتصل بك ويشغّلها\n` +
    `▫️ .${c} أغنية1 + أغنية2 ← قائمة تشغيل\n` +
    `▫️ .${c} اسم (أثناء المكالمة) ← يضيف للقائمة\n` +
    `▫️ .${c} قائمة ← عرض القائمة\n` +
    `▫️ .${c} تخطي ← الأغنية التالية\n` +
    `▫️ .${c} وقف ← إنهاء المكالمة\n` +
    `▫️ .${c} بحث اسم ← بحث يوتيوب مباشر\n` +
    `▫️ (مجموعات) .${c} انضم / غادر / غرفة ← غرفة الصوت\n` +
    `▫️ (مجموعات) .${c} جماعي اسم ← مكالمة جماعية للغرفة (مشرف)\n` +
    `▫️ .${c} رقمي 9665XXXXXXXX ← تسجيل رقمك`;

// ==========================================================
//  أدوات التشخيص (.رن شبكة)
// ==========================================================
async function cpuSample(ms = 2000) {
    const read = () => {
        const f = fs.readFileSync("/proc/stat", "utf8").split("\n")[0].trim().split(/\s+/).slice(1).map(Number);
        return { total: f.reduce((a, b) => a + b, 0), idle: f[3] + (f[4] || 0), steal: f[7] || 0 };
    };
    try {
        const a = read(); await sleep(ms); const b = read();
        const d = (b.total - a.total) || 1;
        return { used: 100 * (1 - (b.idle - a.idle) / d), steal: 100 * (b.steal - a.steal) / d };
    } catch { return null; } // غير لينكس
}

async function timerLagTest(ms = 3000) {
    const lags = [];
    let last = performance.now();
    const end = last + ms;
    await new Promise(res => {
        const t = setInterval(() => {
            const now = performance.now();
            lags.push(Math.max(0, now - last - 20));
            last = now;
            if (now >= end) { clearInterval(t); res(); }
        }, 20);
    });
    lags.sort((a, b) => a - b);
    return { p50: lags[Math.floor(lags.length * 0.5)], p99: lags[Math.floor(lags.length * 0.99)], max: lags[lags.length - 1] };
}

function tcpPing(host, port, timeout = 3000) {
    return new Promise(res => {
        const t0 = performance.now();
        const s = net.connect({ host, port });
        const done = v => { s.destroy(); res(v); };
        s.setTimeout(timeout, () => done(null));
        s.once("connect", () => done(performance.now() - t0));
        s.once("error", () => done(null));
    });
}

async function networkQuality(host = "g.whatsapp.net", port = 443, n = 12) {
    const rtts = []; let lost = 0;
    for (let i = 0; i < n; i++) {
        const r = await tcpPing(host, port);
        if (r === null) lost++; else rtts.push(r);
        await sleep(150);
    }
    if (!rtts.length) return { lost, n, avg: null, jitter: null };
    const avg = rtts.reduce((a, b) => a + b, 0) / rtts.length;
    let jit = 0;
    for (let i = 1; i < rtts.length; i++) jit += Math.abs(rtts[i] - rtts[i - 1]);
    return { lost, n, avg, jitter: rtts.length > 1 ? jit / (rtts.length - 1) : 0 };
}

// اختبار UDP الصادر عبر STUN: نفق المكالمات يعتمد على UDP، فلو الاستضافة تحجبه ما تصل المكالمة
function stunProbe(host, port, timeout = 2500) {
    return new Promise(resolve => {
        const sock = dgram.createSocket("udp4");
        const req = Buffer.alloc(20);
        req.writeUInt16BE(0x0001, 0); req.writeUInt16BE(0, 2); req.writeUInt32BE(0x2112A442, 4);
        crypto.randomBytes(12).copy(req, 8);
        const t0 = performance.now();
        let done = false;
        const finish = v => { if (done) return; done = true; clearTimeout(timer); try { sock.close(); } catch {} resolve(v); };
        const timer = setTimeout(() => finish({ ok: false }), timeout);
        sock.once("error", () => finish({ ok: false }));
        sock.once("message", msg => {
            let ip = null;
            try {
                let off = 20;
                while (off + 4 <= msg.length) {
                    const type = msg.readUInt16BE(off), len = msg.readUInt16BE(off + 2);
                    if ((type === 0x0020 || type === 0x0001) && msg[off + 5] === 0x01) {
                        const b = msg.subarray(off + 8, off + 12);
                        ip = type === 0x0020 ? [b[0] ^ 0x21, b[1] ^ 0x12, b[2] ^ 0xA4, b[3] ^ 0x42].join(".") : [...b].join(".");
                        break;
                    }
                    off += 4 + len + ((4 - (len % 4)) % 4);
                }
            } catch {}
            finish({ ok: true, ms: performance.now() - t0, ip });
        });
        sock.send(req, port, host, err => { if (err) finish({ ok: false }); });
    });
}

async function udpProbe() {
    const targets = [["stun.l.google.com", 19302], ["stun.cloudflare.com", 3478], ["global.stun.twilio.com", 3478]];
    const res = await Promise.all(targets.map(([h, p]) => stunProbe(h, p)));
    return targets.map(([h, p], i) => ({ host: h, port: p, ...res[i] }));
}

async function runDiagnostics() {
    const [cpu, lag, net_, udp] = await Promise.all([cpuSample(3000), timerLagTest(3000), networkQuality(), udpProbe()]);
    const out = [];
    const verdict = [];

    out.push(`⏱️ تأخر المؤقّت: p50 ${lag.p50.toFixed(1)}ms | p99 ${lag.p99.toFixed(1)}ms | أقصى ${lag.max.toFixed(1)}ms`);
    if (lag.p99 > 30 || lag.max > 80) verdict.push("🔴 البوت/السيرفر مشغول: المؤقّت يتأخر (هذا سبب تقطيع مباشر)");

    if (cpu) {
        out.push(`🧠 المعالج: استخدام ${cpu.used.toFixed(0)}% | سرقة (steal) ${cpu.steal.toFixed(1)}%`);
        if (cpu.steal > 3) verdict.push("🔴 المضيف مشترك ومزدحم (steal عالي): غيّر الاستضافة");
        if (cpu.used > 85) verdict.push("🟠 المعالج شبه ممتلئ");
    }

    if (net_.avg === null) {
        out.push("🌐 الشبكة: تعذّر الوصول لخوادم واتساب");
        verdict.push("🔴 الاتصال بخوادم واتساب فاشل (جدار ناري أو DNS)");
    } else {
        out.push(`🌐 واتساب: ${net_.avg.toFixed(0)}ms | jitter ${net_.jitter.toFixed(1)}ms | فقد ${net_.lost}/${net_.n}`);
        if (net_.jitter > 25) verdict.push("🟠 jitter الشبكة عالي (يسبب تقطيع)");
        if (net_.lost > 0) verdict.push("🔴 فقد حزم في الاتصال");
        if (net_.avg > 250) verdict.push("🟠 السيرفر بعيد عن خوادم واتساب");
    }
    const udpOk = udp.filter(x => x.ok);
    out.push("📡 UDP: " + udp.map(x => `${x.port} ${x.ok ? "✅ " + Math.round(x.ms) + "ms" : "❌"}`).join(" | ") + (udpOk[0]?.ip ? ` | IP عام: ${udpOk[0].ip}` : ""));
    if (!udpOk.length) verdict.push("🔴 المضيف يمنع UDP الصادر: النفق يعتمد على UDP، فالمكالمة تنفتح بدون ما تصل. اطلب من الاستضافة تفتح UDP أو غيّرها");
    else if (udp.filter(x => x.port === 3478).every(x => !x.ok)) verdict.push("🟠 منفذ UDP 3478 محجوب (يؤثر على مسار original)");
    out.push(`🧩 المسارات: ${ATTEMPTS.map(a => a.engine + "/" + a.mode).join(" ← ")} | stream: ${STREAM_MODE ? "مفعّل" : "مطفي"}`);

    return out.join("\n") + "\n\n*📌 الحكم:*\n" + (verdict.length ? verdict.join("\n") : "🟢 السيرفر سليم، المشكلة غالباً من مسار واتساب (جرّب المسارات أو VPS)") + "\n\n⚠️ نفس جلسة call-auth لا تشتغل في مكانين: أوقف الاستضافة القديمة تماماً";
}

// ---------- معرفة رقم المرسل (يدعم LID وكل صيغ الفريمورك) ----------
const NUMBERS_FILE = "./call-numbers.json";
const loadNumbers = () => {
    try { return JSON.parse(fs.readFileSync(NUMBERS_FILE, "utf8")); } catch { return {}; }
};
const saveNumber = (lid, num) => {
    const d = loadNumbers();
    d[lid] = num;
    fs.writeFileSync(NUMBERS_FILE, JSON.stringify(d));
};

async function lidToPn(m, conn, jid) {
    const user = jid.split("@")[0].split(":")[0];
    const attempts = [
        async () => (typeof m.lid2jid === "function" ? m.lid2jid(jid) : null),
        async () => conn.signalRepository?.lidMapping?.getPNForLID?.(jid),
        async () => conn.signalRepository?.lidMapping?.getPNForLID?.(`${user}@lid`),
        async () => conn.signalRepository?.lidMapping?.getPNForLID?.(user),
        async () => {
            const key = `${user}_reverse`;
            const r = await conn.authState?.keys?.get?.("lid-mapping", [key]);
            const v = r?.[key];
            return v ? `${v}@s.whatsapp.net` : null;
        },
        async () => {
            const all = Object.values(conn.contacts || conn.store?.contacts || {});
            const c = all.find(x => x?.lid && String(x.lid).split("@")[0].split(":")[0] === user);
            return c?.phoneNumber || (c?.id?.endsWith?.("@s.whatsapp.net") ? c.id : null);
        }
    ];
    for (const run of attempts) {
        try {
            let r = await run();
            if (typeof r !== "string") continue;
            if (/^\d{8,}$/.test(r)) r += "@s.whatsapp.net";
            if (r.endsWith("@s.whatsapp.net")) return r;
        } catch {}
    }
    return null;
}

async function resolveNumber(m, conn) {
    const cands = [
        m.sender,
        m.key?.participant,
        m.participant,
        m.key?.participantPn,
        m.key?.remoteJidAlt,
        m.key?.participantAlt,
        !m.isGroup ? m.chat : null,
        m.key?.remoteJid
    ].filter(x => typeof x === "string" && x);

    const saved = loadNumbers();
    for (const c of cands) if (saved[c]) return saved[c];

    for (let jid of cands) {
        if (jid.endsWith("@lid")) jid = (await lidToPn(m, conn, jid)) || jid;
        if (jid.endsWith("@s.whatsapp.net")) {
            const digits = jid.split("@")[0].split(":")[0].replace(/\D/g, "");
            if (digits.length >= 8) return digits;
        }
    }
    console.error("[CALL] تعذّر تحديد الرقم:", cands);
    return null;
}

// تسخين مسبق: تجهيز الملفات وتشغيل عملية المكالمات (أو الاتصال بالمضيف الدافئ لو البوت أعاد التشغيل)
if (isLinked()) {
    setTimeout(async () => {
        try {
            const list = fs.existsSync(AUDIO_DIR) ? fs.readdirSync(AUDIO_DIR).filter(f => /\.(mp3|wav)$/i.test(f)) : [];
            for (const f of list) await prepareAudio(path.join(AUDIO_DIR, f)).catch(() => {});
            const best = loadBest();
            const w = await getWorker(best?.engine || ATTEMPTS[0].engine, best?.mode || ATTEMPTS[0].mode);
            w.send({ type: "warm" });
        } catch (e) {
            console.error("[CALL] تعذّر التسخين:", e?.message || e);
        }
    }, 5000);
}

// ---------- الأمر ----------
// تشغيل المكالمة في الخلفية: ما نحجز معالج الأوامر طول المكالمة
function launchFlow({ m, conn, target, parts, forced, groupInfo, owner, command, cdKey }) {
    busy = true;
    activeTarget = target;
    cancelFlag = false;
    (async () => {
        const tracks = [];
        let callStarted = false;
        try {
            const reqParts = (parts.length ? parts : [""]).slice(0, QUEUE_MAX_TRACKS);
            for (const part of reqParts) {
                if (cancelFlag) throw new Error("أُلغيت العملية");
                tracks.push(await resolveTrack(part, txt => m.reply(txt).catch(() => {}), { allowLocal: !forced, command }));
            }
            if (cancelFlag) throw new Error("أُلغيت العملية");

            session = { target, chat: m.chat, tracks, index: 0, stream: false, live: false, callId: null };
            const list = tracks.length > 1
                ? "*🎶 القائمة:*\n" + tracks.map((t, i) => trackLine(t, i)).join("\n")
                : `*🎵 ${tracks[0].title}*${tracks[0].ts ? " (" + tracks[0].ts + ")" : ""}`;
            await m.reply(`${list}\n\n*📞 ${groupInfo ? `جاري الاتصال بالغرفة (${groupInfo.numbers.length} أعضاء)...` : "جاري الاتصال بك..."}*`);

            callStarted = true;
            const sumMs = tracks.length === 1 ? tracks[0].durationMs : tracks.reduce((a, t) => a + t.durationMs, 0);
            await quiet.enter({ conn, chat: m.chat, sender: m.sender, durationMs: STREAM_MODE ? QUEUE_CALL_MAX_MS : sumMs });

            const result = await runCall({
                target,
                tracks,
                session,
                group: groupInfo,
                notify: (ev, n, mode, why) => {
                    if (ev === "ringing") m.reply(groupInfo ? "*🔔 يرن عند الأعضاء*" : "*🔔 يرن عندك*").catch(() => {});
                    if (ev === "connected") m.reply(groupInfo ? "*✅ ردّ أحد الأعضاء، يشغّل الصوت*" : "*✅ ردّيت، يشغّل الصوت*").catch(() => {});
                    if (ev === "retry") m.reply(`*🔁 المحاولة ${n}: أجرّب مسار ثاني (${mode})*${owner && why ? "\nالسبب السابق: " + why : ""}`).catch(() => {});
                    if (ev === "tail") ui(conn, m.chat, { title: "🎶 خلصت الأغاني", body: "*🎶 خلصت الأغاني*\nالاتصال يبقى مفتوح دقيقتين، أضف أغنية أو يقفل تلقائياً.", btns: [["r", "➕ أضف أغنية", "ring:song"], ["r", "🛑 إنهاء الآن", "ring:stop"]] }).catch(() => {});
                    if (ev === "degraded" && owner) m.reply("*⚠️ النفق تدهور، المحرّك يحاول يصلحه*").catch(() => {});
                    if (ev === "suspect" && owner) m.reply("*⚠️ المكتبة قالت «اتصل» بدون ما يرنّ الجوال: أعتبرها وهمية وأجرّب مسار ثاني*").catch(() => {});
                    if (ev === "track" && session) {
                        session.index = n;
                        const t = session.tracks[n];
                        if (t && n > 0) m.reply(`*🎶 الآن:* ${t.title}${t.ts ? " (" + t.ts + ")" : ""}`).catch(() => {});
                    }
                }
            });

            const lagLine = owner && result.stats.maxLag
                ? `\n⏱️ تأخر المؤقّت: p99 ${Math.round(result.stats.p99)}ms | أقصى ${Math.round(result.stats.maxLag)}ms (فوق 40ms = تقطيع)\n🧩 المحرّك: ${result.engine}/${result.mode}\n${quiet.summary()}`
                : "";

            if (result.connected) {
                await m.reply(`*📴 انتهت المكالمة* (${result.reason || "تم"})${lagLine}${owner && result.timeline ? "\n📜 " + result.timeline : ""}`);
            } else if (result.ringing) {
                await m.reply(`*📴 انتهت بدون رد* (${result.reason || result.message || "-"})${owner && result.timeline ? "\n📜 " + result.timeline : ""}`);
            } else {
                throw new Error(owner && result.errors && result.errors.length
                    ? "فشلت كل المسارات:\n" + result.errors.join("\n") + "\n\n📋 آخر السجل:\n" + tailLog(12)
                    : (result.message || result.reason || "تعذّر إنشاء المكالمة بكل المسارات"));
            }
        } catch (e) {
            console.error("[CALL]", e);
            if (!callStarted && !owner) cooldown.delete(cdKey); // فشل التجهيز: ما نحسبها مكالمة
            if (!callStarted) {
                await m.reply(`*⚠️ ما قدرت أجهّز الطلب:*\n${String(e.message || e).slice(0, 900)}`).catch(() => {});
            } else {
                await m.reply(`*⚠️ فشلت المكالمة:*\n${String(e.message || e).slice(0, 2200)}`).catch(() => {});
                const t0 = tracks[0];
                if (t0 && t0.kind === "local") {
                    await m.reply("*أرسل لك الصوت بدلها.*").catch(() => {});
                    await conn?.sendMessage?.(
                        m.chat,
                        { audio: fs.readFileSync(t0.src), mimetype: "audio/mpeg", fileName: t0.name },
                        { quoted: m.key ? m : undefined }
                    )?.catch?.(() => {});
                }
            }
        } finally {
            quiet.leave().catch(() => {});
            busy = false;
            activeTarget = null;
            session = null;
        }
    })();
}

const handler = async (m, { conn, args, command, bot }) => {
    const owner = m.isOwner || isOwner(m.sender, bot);
    globalThis.__ringBot = bot; globalThis.__ringConn = conn;
    if (restarting) return m.reply("*🧹 البوت يتنظّف الحين، لحظات وأتصل بك...*").catch?.(() => {});

    // ===== تسجيل رقمك يدوياً =====
    if (["رقمي", "mynumber"].includes(args[0])) {
        const num = (args[1] || "").replace(/\D/g, "");
        if (num.length < 8 || num.length > 15) {
            return m.reply(`*اكتب رقمك بصيغة دولية بدون +:*\n.${command} رقمي 9665XXXXXXXX`);
        }
        const keys = [m.sender, m.chat, m.key?.participant, m.key?.remoteJid].filter(x => typeof x === "string" && x);
        for (const k of new Set(keys)) saveNumber(k, num);
        return m.reply(`*✅ تم حفظ رقمك:* ${num}\nالحين اكتب .${command} للاتصال.`);
    }

    if (args[0] === "نسخة") return m.reply("*✅ ring.js الإصدار v20 (أزرار + صمت 5 ثواني + دقيقتين بعد الأغنية + دعم المجموعات) شغّال*");

    // ===== ذاكرة البوت + تنظيف (للمطور) =====
    if (["ذاكرة", "mem", "memory"].includes(args[0])) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        const mb = x => Math.round(x / 1048576);
        const a = process.memoryUsage();
        let cleaned = "gc غير متاح";
        if (typeof globalThis.gc === "function") {
            try { globalThis.gc(); const b = process.memoryUsage(); cleaned = `نُظّف ${Math.max(0, mb(a.heapUsed - b.heapUsed))}MB (heap ${mb(a.heapUsed)} ← ${mb(b.heapUsed)}MB)`; } catch { cleaned = "فشل gc"; }
        }
        const b2 = process.memoryUsage();
        const lag = await timerLagTest(1000);
        const soft = loadSoft();
        const up = process.uptime();
        return m.reply(
            `*🧠 ذاكرة البوت:*\n` +
            `RSS: ${mb(b2.rss)}MB | Heap: ${mb(b2.heapUsed)}/${mb(b2.heapTotal)}MB\n` +
            `Buffers خارجية: ${mb(b2.external)}MB | ArrayBuffers: ${mb(b2.arrayBuffers || 0)}MB\n` +
            `⏳ شغّال من: ${Math.floor(up / 3600)}س ${Math.floor((up % 3600) / 60)}د\n` +
            `⏱️ تأخر المؤقّت (ثانية): p99 ${lag.p99.toFixed(1)}ms | أقصى ${lag.max.toFixed(1)}ms\n` +
            `🧹 ${cleaned}\n` +
            `🔄 الريستارت الناعم: ${soft.on ? `مفعّل (عند RSS > ${soft.mb}MB أو ${SOFT_MAX_UPTIME_H} ساعة)` : "مطفي"}\n\n` +
            `لو RSS يكبر مع الوقت وما ينزل: فعّل الريستارت الناعم: .${command} ريستارت تشغيل`
        );
    }

    // ===== الريستارت الناعم (للمطور) =====
    // ===== تنظيف قبل المكالمة (ريستارت سريع تلقائي) =====
    if (["ريستارت", "restart", "تنظيف", "clean"].includes(args[0]) && (["قبل", "before"].includes(args[1]) || args[0] === "تنظيف" || args[0] === "clean")) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        const sub = ["قبل", "before"].includes(args[1]) ? args[2] : args[1];
        const rest = ["قبل", "before"].includes(args[1]) ? args.slice(3) : args.slice(2);
        const p = loadPre();
        const mgr = detectManager();
        if (["تشغيل", "on", "1"].includes(sub)) {
            const confirmed = rest.includes("تأكيد") || args.includes("تأكيد");
            if (!mgr && !confirmed) {
                return m.reply(`*⚠️ ما اكتشفت مدير يعيد تشغيل البوت تلقائياً (pm2 / systemd / main.js).*\nلو البوت ما رجع بعد الخروج، ينطفي وما يشتغل حتى تشغّله يدوياً.\n\nإذا متأكد إن استضافتك تعيد تشغيله تلقائياً عند الخروج، اكتب:\n.${command} تنظيف تشغيل تأكيد`);
            }
            const n = Number(rest.find(x => /^\d+$/.test(x)));
            savePre({ on: true, min: n > 0 ? n : p.min });
            return m.reply(`*🧹 التنظيف قبل المكالمة: مفعّل*\nأي مكالمة منك والبوت شغّال أكثر من ${n > 0 ? n : p.min} دقيقة ← يحفظ طلبك، يعيد تشغيل نفسه، وبعدها يتصل بك تلقائياً.\n🔧 مدير التشغيل: ${mgr || "غير مكتشف (أكّدت يدوياً)"}\n\nللإيقاف: .${command} تنظيف ايقاف`);
        }
        if (["ايقاف", "إيقاف", "off", "0"].includes(sub)) {
            savePre({ on: false, min: p.min });
            return m.reply("*🧹 التنظيف قبل المكالمة: مطفي*");
        }
        return m.reply(`*🧹 التنظيف قبل المكالمة:* ${p.on ? `مفعّل (لو البوت شغّال أكثر من ${p.min} دقيقة)` : "مطفي"}\n🔧 مدير التشغيل: ${mgr || "غير مكتشف"}\n\n.${command} تنظيف تشغيل [دقائق]\n.${command} تنظيف ايقاف`);
    }

    if (["ريستارت", "restart"].includes(args[0])) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        const s = loadSoft();
        if (["تشغيل", "on", "1"].includes(args[1])) {
            const n = Number(args[2]);
            saveSoft({ on: true, mb: n > 0 ? n : s.mb });
            return m.reply(`*🔄 الريستارت الناعم: مفعّل*\nيخرج البوت بنظافة لما RSS يتعدّى ${n > 0 ? n : s.mb}MB أو يطول التشغيل ${SOFT_MAX_UPTIME_H} ساعة، وبدون مكالمة نشطة.\n\n⚠️ لازم البوت يكون تحت pm2 أو لوحة تعيد تشغيله تلقائياً، وإلا ينطفي. إذا ما أنت متأكد، اطفيه: .${command} ريستارت ايقاف`);
        }
        if (["ايقاف", "إيقاف", "off", "0"].includes(args[1])) {
            saveSoft({ on: false, mb: s.mb });
            return m.reply("*🔄 الريستارت الناعم: مطفي*");
        }
        return m.reply(`*🔄 الريستارت الناعم:* ${s.on ? `مفعّل (RSS > ${s.mb}MB)` : "مطفي"}\n\n.${command} ريستارت تشغيل [MB]\n.${command} ريستارت ايقاف`);
    }

    // ===== تشخيص الشبكة والسيرفر (للمطور) =====
    if (["شبكة", "net", "diag"].includes(args[0])) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        await m.reply("*🔬 جاري التشخيص (حوالي 5 ثواني)...*");
        try {
            return m.reply("*📊 نتيجة التشخيص:*\n\n" + await runDiagnostics());
        } catch (e) {
            return m.reply("*⚠️ فشل التشخيص:* " + String(e?.message || e).slice(0, 200));
        }
    }

    // ===== وضع الهدوء (للمطور) =====
    if (["هدوء", "quiet"].includes(args[0])) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        if (["ايقاف", "إيقاف", "off", "0"].includes(args[1])) quiet.enabled = false;
        else if (["تشغيل", "on", "1", "ذكي", "smart"].includes(args[1])) { quiet.enabled = true; quiet.mode = "smart"; }
        else if (["دائم", "always"].includes(args[1])) { quiet.enabled = true; quiet.mode = "always"; }
        const state = quiet.enabled ? (quiet.mode === "always" ? "دائم (يؤجّل الرسائل طول المكالمة)" : "ذكي ✅ (يؤجّل فقط لو السيرفر تحت ضغط)") : "مطفي ⛔";
        return m.reply(`*🤫 وضع الهدوء:* ${state}\n\nآخر مكالمة:\n${quiet.last}\n\nللتحكم: .${command} هدوء ذكي / دائم / ايقاف`);
    }

    // ===== فحص (للمطور فقط) =====
    if (["فحص", "check"].includes(args[0])) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        const out = [];
        try { await import("@whiskeysockets/baileys"); out.push("✅ @whiskeysockets/baileys"); }
        catch (e) { out.push("❌ @whiskeysockets/baileys: " + e.message.slice(0, 120)); }
        try { await import("@roamhq/wrtc"); out.push("✅ @roamhq/wrtc (نفق الصوت)"); }
        catch (e) { out.push("❌ @roamhq/wrtc: " + e.message.slice(0, 140)); }
        out.push(`🌐 المسارات: ${ATTEMPTS.map(a => a.engine + "/" + a.mode).join(" ← ")}`);
        try { await import("@japofc/baileys"); out.push("✅ @japofc/baileys (المحرّك الأساسي + watchdog)"); }
        catch (e) { out.push("⚠️ @japofc/baileys غير مثبت (يشتغل الاحتياط): " + e.message.slice(0, 100)); }
        try { await import("baileys-caller-group"); out.push("✅ baileys-caller-group (المكالمات الجماعية)"); }
        catch (e) { out.push("⚠️ baileys-caller-group غير مثبت (الجماعي معطّل): " + e.message.slice(0, 100)); }
        out.push(`🎛️ stream: ${STREAM_MODE ? "مفعّل (CALL_STREAM=1)" : "مطفي"}`);
        try { await import("baileys-caller"); out.push("✅ baileys-caller"); }
        catch (e) { out.push("❌ baileys-caller: " + e.message.slice(0, 160)); }
        try { execSync("ffmpeg -version", { stdio: "ignore" }); out.push("✅ ffmpeg"); }
        catch { out.push("❌ ffmpeg غير مثبت"); }
        out.push(`Node: ${process.version} ${parseInt(process.version.slice(1)) >= 20 ? "✅" : "❌ لازم 20+"}`);
        const la = os.loadavg()[0].toFixed(2);
        out.push(`⚙️ المعالج: ${os.cpus().length} نواة | الحمل: ${la} | الذاكرة الحرة: ${Math.round(os.freemem() / 1048576)}MB`);
        out.push(`📦 baileys-caller: ${pkgInfo("baileys-caller")}`);
        out.push(`📦 wrtc: ${pkgInfo("@roamhq/wrtc")}`);
        out.push(`📦 baileys: ${pkgInfo("@whiskeysockets/baileys")}`);
        out.push(`🧭 المسار: ${forcedPath ? "مثبّت " + forcedPath.engine + "/" + forcedPath.mode : "تلقائي"}`);
        out.push(isLinked() ? "✅ الجلسة مربوطة" : "⚠️ الجلسة غير مربوطة (.رن ربط رقمك)");
        const audios = fs.existsSync(AUDIO_DIR) ? fs.readdirSync(AUDIO_DIR).filter(f => /\.(mp3|wav)$/i.test(f)) : [];
        out.push(`📁 الملفات: ${audios.join(", ") || "لا شيء"}`);
        out.push(`🤫 وضع الهدوء: ${quiet.enabled ? "مفعّل" : "مطفي"}`);
        out.push(`🛰️ عزل المكالمة: ${worker && worker.connected ? `مضيف مستقل شغّال (pid ${worker.hostPid || "?"})` : "المضيف غير متصل حالياً (يشتغل عند أول مكالمة)"}`);
        out.push(`🧹 gc يدوي: ${typeof globalThis.gc === "function" ? "متاح" : "غير متاح"}`);
        out.push(`\nللتشخيص العميق: .${command} شبكة | للذاكرة: .${command} ذاكرة`);
        return m.reply("*🔍 نتيجة الفحص:*\n\n" + out.join("\n"));
    }

    // ===== ربط =====
    if (["ربط", "link"].includes(args[0])) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        if (isLinked()) return m.reply("*✅ الجلسة مربوطة من قبل*");
        if (linking) return m.reply("*⏳ الربط شغّال، انتظر*");

        const phone = (args[1] || "").replace(/\D/g, "");
        if (!phone) return m.reply(`*اكتب الرقم بصيغة دولية بدون +:*\n.${command} ربط 9665XXXXXXXX`);

        linking = true;
        try {
            await linkWithCode(phone, async code => {
                const pretty = code.match(/.{1,4}/g).join("-");
                await m.reply(
                    `*🔑 كود الربط:*\n\n*${pretty}*\n\n` +
                    `واتساب ← الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف بدلاً من ذلك ← أدخل الكود`
                );
            });
            return m.reply("*✅ تم الربط!* الحين اكتب .رن للاتصال");
        } catch (e) {
            console.error("[LINK]", e);
            return m.reply(`*⚠️ فشل الربط:*\n${String(e.message || e).slice(0, 300)}`);
        } finally {
            linking = false;
        }
    }

    // ===== مساعدة =====
    if (["مساعدة", "help", "اوامر", "أوامر"].includes(args[0])) return m.reply(helpText(command));

    // ===== سجل عمليات المكالمات (للمطور): يعرض آخر ما قالته المكتبة =====
    if (["سجل", "log", "logs"].includes(args[0])) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        const n = Math.min(Math.max(parseInt(args[1]) || 40, 5), 80);
        return m.reply("*📋 آخر السجل:*\n\n" + (tailLog(n) || "فارغ (جرّب مكالمة أولاً)").slice(-3500));
    }

    // ===== تثبيت مسار واحد للتشخيص (للمطور) =====
    if (["مسار", "path"].includes(args[0])) {
        if (!owner) return m.reply("*❌ هذا الخيار للمطور فقط*");
        if (!args[1] || ["تلقائي", "auto"].includes(args[1])) {
            forcedPath = null;
            return m.reply(`*🧭 المسار: تلقائي*\n${ATTEMPTS.map(a => a.engine + "/" + a.mode).join(" ← ")}`);
        }
        if (!["caller", "japofc"].includes(args[1]) || !["original", "web"].includes(args[2])) {
            return m.reply(`*اكتب:*\n.${command} مسار caller original\n.${command} مسار caller original ملف  (بدون stream)\n.${command} مسار caller web\n.${command} مسار تلقائي`);
        }
        forcedPath = { engine: args[1], mode: args[2], stream: ["ملف", "file"].includes(args[3]) ? false : undefined };
        return m.reply(`*🧭 المسار مثبّت على ${attemptLabel(forcedPath)}* بدون إعادة محاولة.\nجرّب .${command} ثم .${command} سجل\nللرجوع: .${command} مسار تلقائي`);
    }

    const canControl = async () => owner || (await resolveNumber(m, conn)) === activeTarget;

    // ===== إيقاف المكالمة الحالية =====
    if (["وقف", "stop", "انهاء", "إنهاء"].includes(args[0])) {
        if (!busy) return m.reply("*ما فيه مكالمة شغّالة*");
        if (!(await canControl())) return m.reply("*❌ المكالمة مو لك*");
        cancelFlag = true;
        try { worker?.send({ type: "hangup" }); } catch {}
        return m.reply("*🛑 تم إيقاف المكالمة*");
    }

    // ===== عرض القائمة =====
    if (["قائمة", "قايمة", "queue", "q", "حالي", "np", "now"].includes(args[0])) {
        if (!busy || !session) return m.reply("*ما فيه مكالمة شغّالة*");
        return m.reply(renderQueue());
    }

    // ===== تخطي =====
    if (["تخطي", "skip", "next"].includes(args[0])) {
        if (!busy || !session) return m.reply("*ما فيه مكالمة شغّالة*");
        if (!(await canControl())) return m.reply("*❌ المكالمة مو لك*");
        if (!session.live || !session.stream) return m.reply("*⚠️ التخطي يحتاج مكالمة شغّالة بوضع stream*");
        const ok = await workerRpc("skip", {}, "skipped");
        return m.reply(ok ? "*⏭️ تم التخطي*" : "*⚠️ ما قدرت أتخطى (آخر أغنية أو القائمة خلصت)*");
    }

    // ===== غرفة صوت المجموعة (كل عضو يدخلها بنفسه) =====
    if (["انضم", "join", "غادر", "leave", "غرفة", "room"].includes(args[0])) {
        if (!m.isGroup) return m.reply("*هذا الأمر داخل المجموعات فقط*");
        const rooms = loadRooms();
        const list = rooms[m.chat] || [];
        if (["غرفة", "room"].includes(args[0])) return m.reply(`*👥 غرفة الصوت:* ${list.length} عضو\nللانضمام: .${command} انضم`);
        const num = await resolveNumber(m, conn);
        if (!num) return m.reply(`*❌ ما قدرت أعرف رقمك*\nسجّله: .${command} رقمي 9665XXXXXXXX`);
        if (["انضم", "join"].includes(args[0])) {
            if (!list.includes(num)) {
                if (list.length >= 30) return m.reply("*⚠️ الغرفة ممتلئة*");
                list.push(num);
            }
            rooms[m.chat] = list; saveRooms(rooms);
            return m.reply(`*✅ انضممت لغرفة الصوت* (${list.length} عضو)\nالمكالمات الجماعية تتصل فيك. للخروج: .${command} غادر`);
        }
        rooms[m.chat] = list.filter(x => x !== num); saveRooms(rooms);
        return m.reply("*👋 خرجت من غرفة الصوت*");
    }

    // ===== مكالمة =====
    if (!isLinked()) return m.reply(`*🔗 لازم تربط أول:*\n.${command} ربط 9665XXXXXXXX\n\nأو اكتب .${command} فحص`);

    const gMode = ["جماعي", "جروب", "group"].includes(args[0]);
    const { forced, parts } = parseRequest(gMode ? args.slice(1) : args);

    // ===== إضافة للقائمة أثناء مكالمة شغّالة =====
    if (busy) {
        if (!session || !parts.length) return m.reply(`*⏳ فيه مكالمة شغّالة*\n(.${command} قائمة | تخطي | وقف)`);
        if (!(await canControl())) return m.reply("*⏳ فيه مكالمة شغّالة لشخص ثاني*");
        if (!session.live) return m.reply("*⏳ انتظر لين تردّ على المكالمة، وبعدها أضف أغاني*");
        if (!session.stream) return m.reply(`*⚠️ الإضافة أثناء المكالمة تحتاج وضع stream.*\nاكتب الأغاني دفعة وحدة: .${command} أغنية1 + أغنية2`);
        const added = [];
        try {
            for (const part of parts) {
                if (session.tracks.length >= QUEUE_MAX_TRACKS) throw new Error("القائمة ممتلئة");
                const t = await resolveTrack(part, txt => m.reply(txt).catch(() => {}), { allowLocal: !forced, command });
                if (!session) throw new Error("انتهت المكالمة");
                const ok = await workerRpc("append", { file: t.file }, "appended");
                if (!ok) throw new Error("المكالمة ما قبلت الأغنية (انتهت أو ما تدعم الإضافة)");
                session.tracks.push(t);
                added.push(trackLine(t, session.tracks.length - 1));
            }
        } catch (e) {
            if (!added.length) return m.reply(`*⚠️ ما قدرت أضيف:*\n${String(e.message || e).slice(0, 600)}`);
            added.push("⚠️ توقفت: " + String(e.message || e).slice(0, 120));
        }
        return m.reply("*➕ أُضيفت للقائمة:*\n" + added.join("\n"));
    }

    const target = await resolveNumber(m, conn);
    if (!target) {
        return m.reply(
            `*❌ ما قدرت أعرف رقمك تلقائياً*\n\nسجّل رقمك مرة وحدة فقط:\n.${command} رقمي 9665XXXXXXXX\n\n(بصيغة دولية بدون +) وبعدها اكتب .${command} عادي.`
        );
    }

    // مكالمة جماعية: داخل المجموعات فقط، للمشرفين/المطوّر، ولأعضاء الغرفة اللي وافقوا فقط
    let groupInfo = null;
    if (gMode) {
        if (!m.isGroup) return m.reply("*المكالمة الجماعية داخل المجموعات فقط*");
        if (!owner && !(await isGroupAdmin(m, conn))) return m.reply("*❌ المكالمة الجماعية للمشرفين فقط*");
        const room = loadRooms()[m.chat] || [];
        const numbers = [...new Set([target, ...room])].slice(0, GROUP_MAX);
        if (numbers.length < 2) return m.reply(`*👥 الغرفة فاضية*\nيحتاج عضو واحد على الأقل غيرك: .${command} انضم`);
        groupInfo = { numbers, groupJid: m.chat };
    }

    const cdKey = gMode ? "g:" + m.chat : target;
    if (!owner) {
        const last = cooldown.get(cdKey) || 0;
        const wait = (gMode ? GROUP_COOLDOWN_MS : COOLDOWN_MS) - (Date.now() - last);
        if (wait > 0) return m.reply(`*⏳ انتظر ${Math.ceil(wait / 1000)} ثانية قبل المكالمة التالية*`);
        cooldown.set(cdKey, Date.now());
    }

    // تنظيف قبل المكالمة: للمطوّر فقط، ولو البوت شغّال أكثر من المدة المحددة (بعد الريستارت ما يتكرر)
    const pre = loadPre();
    if (owner && pre.on && !busy && !linking && process.uptime() > pre.min * 60) {
        try {
            fs.writeFileSync(PENDING_FILE, JSON.stringify({
                t: Date.now(), chat: m.chat, sender: m.sender, isGroup: !!m.isGroup, owner: true, command,
                target, parts, forced, gMode, groupInfo, cdKey
            }));
            await m.reply("*🧹 أنظّف البوت (ريستارت سريع) وبعدها أتصل بك تلقائياً...*");
            restartBot();
            return;
        } catch (e) {
            console.error("[CALL] تعذّر حفظ الطلب للتنظيف:", e?.message || e);
            try { fs.rmSync(PENDING_FILE, { force: true }); } catch {}
        }
    }

    await m.reply("*🔎 أجهّز طلبك...*");
    launchFlow({ m, conn, target, parts, forced, groupInfo, owner, command, cdKey });
};

handler.command = ["رن", "رن_عليا", "call"];

// ---------- استكمال المكالمة بعد ريستارت التنظيف ----------
// نقرأ الطلب المحفوظ ونمسحه فوراً (يمنع أي دوران)، وننتظر البوت يستقر ثم نكمل الاتصال.
// المكالمة تُنفَّذ عبر عملية الصوت المستقلة، فما تحتاج اتصال البوت؛ الاتصال يُستخدم فقط لإرسال رسائل الحالة.
function readPending() {
    try {
        const p = JSON.parse(fs.readFileSync(PENDING_FILE, "utf8"));
        fs.rmSync(PENDING_FILE, { force: true });
        return p && Date.now() - p.t < PENDING_MAX_AGE_MS && p.target && Array.isArray(p.parts) ? p : null;
    } catch { return null; }
}

async function resumePending(p) {
    if (busy || !isLinked()) return;
    // رسائل الحالة بدون حجز: تنتظر اتصال البوت (حتى 30 ثانية) ولا توقف المكالمة لو ما لقت اتصال
    let q = Promise.resolve();
    const sendTxt = async txt => {
        for (let i = 0; i < 10; i++) {
            const c = detectConn();
            if (c) { try { await c.sendMessage(p.chat, { text: String(txt) }); return; } catch {} }
            await sleep(3000);
        }
    };
    const m = { chat: p.chat, sender: p.sender, isGroup: !!p.isGroup, key: null, reply: txt => { q = q.then(() => sendTxt(txt)); return Promise.resolve(); } };
    if (!p.owner && p.cdKey) cooldown.set(p.cdKey, Date.now());
    console.log("[CALL] استكمال المكالمة بعد التنظيف");
    m.reply("*✅ البوت نظيف، أتصل بك الحين...*");
    launchFlow({ m, conn: detectConn(), target: p.target, parts: p.parts, forced: !!p.forced, groupInfo: p.groupInfo || null, owner: !!p.owner, command: p.command || "رن", cdKey: p.cdKey });
}

{
    const pend = readPending();
    if (pend) setTimeout(() => resumePending(pend).catch(e => console.error("[CALL] resume:", e?.message || e)), RESUME_DELAY_MS);
}

// ==========================================================
//  v18: نظام الأزرار (طبقة فوق الأوامر الأصلية، ما تغيّر شيء في الأساس)
//  .رن ← قائمة | كل زر يرسل نفس الأمر القديم للـ handler
// ==========================================================
const UI_PAGE = 7;
const UI_PENDING_MS = 120000;
const UI_ADMINS_FILE = "./call-admins.json";
global.ringPending ||= {};

const uiCut = (s, n) => { s = String(s ?? ""); return s.length > n ? s.slice(0, n - 1) + "…" : s; };

const uiLoadAdmins = () => { try { return JSON.parse(fs.readFileSync(UI_ADMINS_FILE, "utf8")); } catch { return []; } };
const uiSaveAdmins = a => { try { fs.writeFileSync(UI_ADMINS_FILE, JSON.stringify(a.slice(-20))); } catch {} };
const uiIdsOf = m => [...new Set([m.sender, m.key?.participant, m.participant, m.lid, !m.isGroup ? m.chat : null].filter(x => typeof x === "string" && x))];
// المالك: الأمر المكتوب يتحقق منه الفريمورك فنسجّل معرّفاته، وضغطات الأزرار نتعرف عليه من المسجّل
function uiOwnerOf(m, bot) {
    const mine = uiIdsOf(m);
    if (m.isOwner) {
        const a = uiLoadAdmins();
        const add = mine.filter(i => !a.includes(i));
        if (add.length) uiSaveAdmins([...a, ...add]);
        return true;
    }
    if (bot?.config?.owners?.some(o => mine.some(i => i === o.jid || i === o.lid))) return true;
    const a = uiLoadAdmins();
    return mine.some(i => a.includes(i));
}

async function ui(conn, jid, spec) {
    if (typeof Button === "undefined") {
        return conn.sendMessage(jid, { text: [spec.title, spec.body, spec.footer].filter(Boolean).join("\n") });
    }
    const b = new Button(conn).setBody(spec.body || " ");
    if (spec.title) b.setTitle(spec.title);
    if (spec.footer) b.setFooter(spec.footer);
    if (spec.list) {
        b.addSelection(spec.list.title || "القائمة");
        for (const s of spec.list.sections) {
            b.makeSection(uiCut(s.title, 24));
            for (const r of s.rows) b.makeRow("", uiCut(r[0], 24), uiCut(r[1] || "", 72), r[2]);
        }
    }
    for (const [t, text, v] of spec.btns || []) {
        if (t === "r") b.addReply(uiCut(text, 24), v);
        else if (t === "c") b.addCopy(uiCut(text, 24), v);
        else if (t === "u") b.addUrl(uiCut(text, 24), v);
    }
    return b.send(jid);
}

function uiGetId(m) {
    for (let x of [m.message, m.msg].filter(Boolean)) {
        x = x?.ephemeralMessage?.message || x?.viewOnceMessage?.message || x?.viewOnceMessageV2?.message || x;
        const pj = x?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || x?.nativeFlowResponseMessage?.paramsJson;
        if (pj) { try { const id = JSON.parse(pj).id; if (id) return String(id); } catch {} }
        const id = x?.buttonsResponseMessage?.selectedButtonId || x?.listResponseMessage?.singleSelectReply?.selectedRowId || x?.templateButtonReplyMessage?.selectedId;
        if (id) return String(id);
    }
    if (typeof m.text === "string" && /^ring:/.test(m.text.trim())) return m.text.trim();
    return null;
}

const UI_MENU = ["r", "🏠 القائمة", "ring:menu"];
const UI_ADMIN = ["r", "🔙 الإدارة", "ring:adm"];
const uiWatchers = new Set();

async function uiScreenMenu(c) {
    const cur = session?.tracks?.[session.index];
    const status = busy ? `📞 مكالمة شغّالة${cur ? "\n🎵 الآن: " + uiCut(cur.title, 40) : ""}` : "✅ جاهز للاتصال";
    const rows1 = [
        ["🎵 أغنية من يوتيوب", "اكتب الاسم وأتصل بك", "ring:song"],
        ["📁 ملفاتي الصوتية", `${listAudio().length} ملف`, "ring:files:0"],
        ["📞 الصوت الافتراضي", "يتصل ويشغّل default", "ring:def"],
    ];
    const rows2 = [
        ["🎶 القائمة", "عرض قائمة التشغيل", "ring:q"],
        ["⏭ تخطي", "الأغنية التالية", "ring:skip"],
        ["➕ إضافة أغنية", "أثناء المكالمة", "ring:song"],
        ["🛑 إيقاف المكالمة", "إنهاء فوري", "ring:stop"],
    ];
    const rows3 = [
        ["👥 غرفة المجموعة", "انضم / غادر / جماعي", "ring:room"],
        ["🔢 تسجيل رقمي", "إذا ما عرفك البوت", "ring:num"],
        ["📖 المساعدة", "شرح الاستخدام", "ring:help"],
    ];
    if (c.owner) rows3.push(["🛠 لوحة المطور", "فحص وتشخيص وإعدادات", "ring:adm"]);
    return ui(c.conn, c.m.chat, {
        title: "✦ RING ✦",
        body: `*مركز المكالمات والأغاني*\n⊱⋅ ──────────── ⋅⊰\n${status}\n🔗 الجلسة: ${isLinked() ? "مربوطة" : "غير مربوطة ⚠️"}`,
        footer: "كل شيء بالضغط، ما تحتاج تكتب أوامر",
        list: { title: "☰ القائمة", sections: [{ title: "التشغيل", rows: rows1 }, { title: "أثناء المكالمة", rows: rows2 }, { title: "المزيد", rows: rows3 }] },
        btns: [["r", "🎵 أغنية", "ring:song"], ["r", "📁 الملفات", "ring:files:0"], ["r", "🛑 إيقاف", "ring:stop"]]
    });
}

async function uiScreenFiles(c, page = 0) {
    const files = listAudio();
    if (!files.length) return ui(c.conn, c.m.chat, { title: "📁 الملفات", body: `*ما فيه ملفات صوتية*\nضع ملفات mp3 أو wav في مجلد ${AUDIO_DIR}`, btns: [["r", "🎵 أغنية", "ring:song"], UI_MENU] });
    const pages = Math.ceil(files.length / UI_PAGE);
    page = Math.min(Math.max(0, page), pages - 1);
    const rows = files.slice(page * UI_PAGE, page * UI_PAGE + UI_PAGE).map((f, i) => [`${page * UI_PAGE + i + 1}. ${f.replace(/\.(mp3|wav)$/i, "")}`, "اضغط للتشغيل", `ring:f:${page * UI_PAGE + i + 1}`]);
    const nav = [];
    if (page > 0) nav.push(["⬅️ السابق", `صفحة ${page}`, `ring:files:${page - 1}`]);
    if (page < pages - 1) nav.push(["➡️ التالي", `صفحة ${page + 2}`, `ring:files:${page + 1}`]);
    return ui(c.conn, c.m.chat, {
        title: "📁 الملفات الصوتية",
        body: `*اختر ملف يتصل بك ويشغّله*\nالصفحة ${page + 1} من ${pages} • المجموع ${files.length}`,
        list: { title: "📁 الملفات", sections: [{ title: "الملفات", rows }, ...(nav.length ? [{ title: "تنقّل", rows: nav }] : [])] },
        btns: [UI_MENU]
    });
}

async function uiScreenRoom(c) {
    return ui(c.conn, c.m.chat, {
        title: "👥 غرفة الصوت",
        body: "*غرفة صوت المجموعة*\n⊱⋅ ──────────── ⋅⊰\nالأعضاء يدخلون الغرفة بأنفسهم بموافقتهم.\nالمكالمة الجماعية (للمشرفين) تتصل بأعضاء الغرفة فقط.\n\n_هذي الأزرار تعمل داخل المجموعات._",
        list: { title: "👥 الإجراءات", sections: [{ title: "الغرفة", rows: [
            ["✅ انضم للغرفة", "توافق تستقبل المكالمات", "ring:j"],
            ["👋 غادر الغرفة", "ما تستقبل بعد اليوم", "ring:l"],
            ["👥 عدد الأعضاء", "كم عضو في الغرفة", "ring:r"],
            ["📞 مكالمة جماعية", "للمشرفين: اكتب اسم الأغنية", "ring:g"],
            ["📞 جماعي بالصوت الافتراضي", "للمشرفين: بدون كتابة", "ring:gdef"],
        ] }] },
        btns: [UI_MENU]
    });
}

async function uiScreenHelp(c) {
    return ui(c.conn, c.m.chat, {
        title: "📖 المساعدة",
        body: "*طريقة الاستخدام*\n⊱⋅ ──────────── ⋅⊰\n1️⃣ اضغط *أغنية من يوتيوب* واكتب الاسم (أو أكثر من أغنية بينها +)\n2️⃣ البوت يتصل بك ويشغّلها\n3️⃣ أثناء المكالمة تظهر لك أزرار: القائمة، تخطي، إضافة، إيقاف\n4️⃣ *ملفاتي الصوتية* تشغّل الملفات المحفوظة\n5️⃣ لو ما عرفك البوت اضغط *تسجيل رقمي*",
        btns: [["r", "🎵 أغنية", "ring:song"], UI_MENU]
    });
}

async function uiScreenAdmin(c) {
    return ui(c.conn, c.m.chat, {
        title: "🛠 لوحة المطور",
        body: "*لوحة التحكم*\n⊱⋅ ──────────── ⋅⊰\nاختر أداة من القائمة",
        list: { title: "📂 الأدوات", sections: [
            { title: "تشخيص", rows: [
                ["🔍 فحص المتطلبات", "المكتبات والجلسة", "ring:ad:chk"],
                ["📊 تشخيص الشبكة", "المعالج والشبكة وUDP", "ring:ad:net"],
                ["🧠 الذاكرة", "استهلاك البوت وتنظيف", "ring:ad:mem"],
                ["📋 السجل", "آخر ما قالته المكتبة", "ring:ad:log"],
            ] },
            { title: "إعدادات", rows: [
                ["🤫 وضع الهدوء", "ذكي / دائم / إيقاف", "ring:ad:quiet"],
                ["🔄 الريستارت الناعم", "تشغيل / إيقاف", "ring:ad:soft"],
                ["🧹 تنظيف قبل المكالمة", "ريستارت سريع تلقائي", "ring:ad:pre"],
                ["🧭 مسار الاتصال", "تلقائي أو تثبيت مسار", "ring:ad:path"],
                ["🔗 ربط الجلسة", "كود ربط برقمك", "ring:ad:link"],
            ] },
        ] },
        btns: [UI_MENU]
    });
}

const uiOptScreen = (c, title, body, rows) => ui(c.conn, c.m.chat, { title, body, list: { title: "اختر", sections: [{ title, rows }] }, btns: [UI_ADMIN] });

// تشغيل أمر ring.js الأصلي كأن المستخدم كتبه
async function uiRun(m, ctx, args, owner, nav = null) {
    const busyBefore = busy;
    try { Object.defineProperty(m, "isOwner", { value: owner, configurable: true, writable: true }); } catch {}
    m.__ringDirect = true;
    await handler(m, { ...ctx, args, command: "رن" });
    if (!busyBefore && busy) return uiWatch(ctx.conn, m.chat);
    if (nav) await ui(ctx.conn, m.chat, { body: "اختر إجراء آخر 👇", btns: nav });
}

// مراقب المكالمة: يرسل لوحات الأزرار تلقائياً (اتصال ← شغّالة ← انتهت)
function uiWatch(conn, chat) {
    if (uiWatchers.has(chat)) return;
    uiWatchers.add(chat);
    const t0 = Date.now();
    let live = false, saw = false;
    const stop = () => { clearInterval(iv); uiWatchers.delete(chat); };
    ui(conn, chat, { title: "📞 جاري الاتصال", body: "*📞 جاري الاتصال...*\nلو تبغى تلغي اضغط إيقاف.", btns: [["r", "🛑 إيقاف", "ring:stop"], UI_MENU] }).catch(() => {});
    const iv = setInterval(async () => {
        try {
            if (busy) {
                saw = true;
                if (session?.live && !live) {
                    live = true;
                    const cur = session.tracks?.[session.index];
                    await ui(conn, chat, {
                        title: "🎧 المكالمة شغّالة",
                        body: `*🎧 تحكّم بالمكالمة*\n${cur ? "🎵 الآن: " + uiCut(cur.title, 50) : ""}`,
                        btns: session.stream ? [["r", "🎶 القائمة", "ring:q"], ["r", "⏭ تخطي", "ring:skip"], ["r", "➕ أغنية", "ring:song"], ["r", "🛑 إيقاف", "ring:stop"]] : [["r", "🛑 إيقاف", "ring:stop"], UI_MENU]
                    });
                }
            } else if (saw || Date.now() - t0 > 20000) {
                stop();
                if (saw) await ui(conn, chat, { title: "📴 انتهت", body: "*📴 انتهت المكالمة*", btns: [["r", "🎵 أغنية أخرى", "ring:song"], UI_MENU] });
            }
            if (Date.now() - t0 > 3600e3) stop();
        } catch {}
    }, 2000);
}

// الإدخال المعلّق: المستخدم يكتب نص بعد ضغط زر
const UI_PROMPTS = {
    song: "🎵 *اكتب اسم الأغنية الآن*\nولقائمة تشغيل افصل بين الأغاني بـ +\nمثال: اغنية1 + اغنية2",
    gsong: "📞 *اكتب اسم الأغنية للمكالمة الجماعية*",
    num: "🔢 *اكتب رقمك* بصيغة دولية بدون +\nمثال: 9665XXXXXXXX",
    link: "🔗 *اكتب الرقم الذي تبغى تربطه* بصيغة دولية بدون +"
};
async function uiAsk(c, act) {
    global.ringPending[c.m.sender] = { act, chat: c.m.chat, exp: Date.now() + UI_PENDING_MS };
    return c.conn.sendMessage(c.m.chat, { text: `${UI_PROMPTS[act]}\n\n_للإلغاء اكتب: الغاء_` });
}

async function uiDispatch(m, ctx, id) {
    const owner = uiOwnerOf(m, ctx.bot);
    const c = { conn: ctx.conn, m, owner, bot: ctx.bot };
    const [, a, b1, b2] = id.split(":");
    const run = (args, nav = [UI_MENU]) => uiRun(m, ctx, args, owner, nav);

    if (a === "menu") return uiScreenMenu(c);
    if (a === "help") return uiScreenHelp(c);
    if (a === "room") return uiScreenRoom(c);
    if (a === "files") return uiScreenFiles(c, Number(b1) || 0);
    if (a === "song") return uiAsk(c, "song");
    if (a === "g") return uiAsk(c, "gsong");
    if (a === "num") return uiAsk(c, "num");
    if (a === "def") return uiRun(m, ctx, [], owner, [UI_MENU]);
    if (a === "gdef") return uiRun(m, ctx, ["جماعي"], owner, [UI_MENU]);
    if (a === "f") return run([String(Number(b1) || 1)]);
    if (a === "q") return run(["قائمة"], [["r", "⏭ تخطي", "ring:skip"], ["r", "🛑 إيقاف", "ring:stop"], UI_MENU]);
    if (a === "skip") return run(["تخطي"], [["r", "🎶 القائمة", "ring:q"], ["r", "🛑 إيقاف", "ring:stop"], UI_MENU]);
    if (a === "stop") return run(["وقف"], [["r", "🎵 أغنية", "ring:song"], UI_MENU]);
    if (a === "j") return run(["انضم"], [["r", "👥 الغرفة", "ring:room"], UI_MENU]);
    if (a === "l") return run(["غادر"], [["r", "👥 الغرفة", "ring:room"], UI_MENU]);
    if (a === "r") return run(["غرفة"], [["r", "👥 الغرفة", "ring:room"], UI_MENU]);

    // ===== المطور فقط =====
    if (a === "adm" || a === "ad") {
        if (!owner) return ctx.conn.sendMessage(m.chat, { text: "*❌ هذا القسم للمطور فقط*\n_إذا أنت المطور: اكتب .رن مرة واحدة ليتعرف عليك البوت، ثم جرّب الزر._" });
        if (a === "adm") return uiScreenAdmin(c);
        const adm = [UI_ADMIN];
        if (b1 === "chk") return run(["فحص"], adm);
        if (b1 === "net") return run(["شبكة"], adm);
        if (b1 === "mem") return run(["ذاكرة"], adm);
        if (b1 === "log") return run(["سجل"], adm);
        if (b1 === "link") return uiAsk(c, "link");
        if (b1 === "quiet") return uiOptScreen(c, "🤫 وضع الهدوء", "*وضع الهدوء*\nيخفف البوت أثناء المكالمة.", [
            ["🧠 ذكي", "يؤجّل فقط لو السيرفر تحت ضغط", "ring:ad:q:smart"],
            ["🔒 دائم", "يؤجّل طول المكالمة", "ring:ad:q:always"],
            ["⛔ إيقاف", "بدون تخفيف", "ring:ad:q:off"],
            ["ℹ️ الحالة", "عرض الوضع الحالي", "ring:ad:q:st"]]);
        if (b1 === "q") return run(["هدوء", ...({ smart: ["ذكي"], always: ["دائم"], off: ["ايقاف"], st: [] }[b2] || [])], adm);
        if (b1 === "soft") return uiOptScreen(c, "🔄 الريستارت الناعم", "*الريستارت الناعم*\nيخرج البوت بنظافة لما تنتفخ الذاكرة.\n⚠️ يحتاج pm2 أو لوحة تعيد التشغيل تلقائياً.", [
            ["✅ تشغيل", "عند تجاوز حد الذاكرة", "ring:ad:s:on"],
            ["⛔ إيقاف", "تعطيله", "ring:ad:s:off"],
            ["ℹ️ الحالة", "عرض الإعداد", "ring:ad:s:st"]]);
        if (b1 === "s") return run(["ريستارت", ...({ on: ["تشغيل"], off: ["ايقاف"], st: [] }[b2] || [])], adm);
        if (b1 === "pre") return uiOptScreen(c, "🧹 تنظيف قبل المكالمة", "*التنظيف قبل المكالمة*\nيعيد تشغيل البوت سريعاً ثم يكمل الاتصال تلقائياً.", [
            ["✅ تشغيل", "لو اكتشف مدير تشغيل", "ring:ad:p:on"],
            ["✅ تشغيل (تأكيد)", "إذا متأكد إن الاستضافة تعيد التشغيل", "ring:ad:p:force"],
            ["⛔ إيقاف", "تعطيله", "ring:ad:p:off"],
            ["ℹ️ الحالة", "عرض الإعداد", "ring:ad:p:st"]]);
        if (b1 === "p") return run(["تنظيف", ...({ on: ["تشغيل"], force: ["تشغيل", "تأكيد"], off: ["ايقاف"], st: [] }[b2] || [])], adm);
        if (b1 === "path") return uiOptScreen(c, "🧭 مسار الاتصال", "*مسار الاتصال*\nللتشخيص فقط، الأفضل تبقيه تلقائي.", [
            ["🔁 تلقائي", "الوضع الطبيعي", "ring:ad:m:auto"],
            ["caller / original", "تثبيت مسار", "ring:ad:m:co"],
            ["caller / original (ملف)", "بدون stream", "ring:ad:m:cof"],
            ["caller / web", "تثبيت مسار", "ring:ad:m:cw"]]);
        if (b1 === "m") return run(["مسار", ...({ auto: ["تلقائي"], co: ["caller", "original"], cof: ["caller", "original", "ملف"], cw: ["caller", "web"] }[b2] || ["تلقائي"])], adm);
    }
}

// الغلاف: .رن لحاله ← القائمة | الباقي يمر للـ handler الأصلي كما هو
const ringHandler = async function (m, ctx) {
    const owner = uiOwnerOf(m, ctx.bot);
    const args = ctx.args || [];
    const c = { conn: ctx.conn, m, owner, bot: ctx.bot };
    globalThis.__ringBot = ctx.bot; globalThis.__ringConn = ctx.conn;
    if (!m.__ringDirect) {
        if (!args.length) return uiScreenMenu(c);
        if (["مساعدة", "help", "اوامر", "أوامر"].includes(args[0])) return uiScreenHelp(c);
    }
    const busyBefore = busy;
    await handler(m, ctx);
    if (!busyBefore && busy) uiWatch(ctx.conn, m.chat);
};

// ضغطات الأزرار + الإدخال المعلّق
ringHandler.before = async (m, ctx) => {
    try {
        if (m.fromMe || m.isBaileys) return;
        const id = uiGetId(m);
        if (id && id.startsWith("ring:")) {
            try { await uiDispatch(m, ctx, id); }
            catch (e) { console.error("[RING-UI]", e); try { await m.reply("*⚠️ صار خطأ مؤقت، جرّب مرة ثانية*"); } catch {} }
            return true;
        }
        const p = global.ringPending[m.sender];
        if (!p) return;
        const text = typeof m.text === "string" ? m.text.trim() : "";
        if (p.exp < Date.now()) { delete global.ringPending[m.sender]; return; }
        if (!text || p.chat !== m.chat) return;
        if (/^[./!#]/.test(text)) { delete global.ringPending[m.sender]; return; }
        delete global.ringPending[m.sender];
        if (/^(الغاء|إلغاء|cancel)$/i.test(text)) { await ctx.conn.sendMessage(m.chat, { text: "*تم الإلغاء*" }); return true; }
        const owner = uiOwnerOf(m, ctx.bot);
        const words = text.split(/\s+/).filter(Boolean);
        const digits = text.replace(/\D/g, "");
        let args = null;
        if (p.act === "song") args = words;
        else if (p.act === "gsong") args = ["جماعي", ...words];
        else if (p.act === "num") args = ["رقمي", digits];
        else if (p.act === "link") args = ["ربط", digits];
        if (args) { try { await uiRun(m, ctx, args, owner, [UI_MENU]); } catch (e) { console.error("[RING-UI]", e); } }
        return true;
    } catch (e) { console.error("[RING-UI]", e); }
};

ringHandler.command = handler.command;
ringHandler.help = handler.command;
ringHandler.tags = ['main'];

export default ringHandler;
