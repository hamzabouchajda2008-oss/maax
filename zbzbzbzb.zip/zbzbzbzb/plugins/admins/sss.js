const isOwner = (userId, bot) => bot.config?.owners?.some(o => o.jid === userId || o.lid === userId);

const handler = async (m, { conn, text, bot }) => {
    if (!m.isGroup) {
        return m.reply('❌ *هذا الأمر يعمل في المجموعات فقط*');
    }

    if (!m.isOwner && !isOwner(m.sender, bot)) {
        return m.reply('❌ *هذا الأمر مخصص للمطورين فقط*');
    }

    if (!m.quoted) {
        return m.reply(`⚠️ *خطأ*\n━━━━━━━━━━━━━━━━━\n📌 *رد على الشخص* الذي تريد انتحال شخصيته\n\n*مثال:*\n.س مرحبا أنا فلان`);
    }

    if (!text) {
        return m.reply(`⚠️ *خطأ*\n━━━━━━━━━━━━━━━━━\n📌 *اكتب النص* الذي تريد إرساله\n\n*مثال:*\n.س مرحبا أنا فلان`);
    }

    const stanzaId = m.quoted.id;

    try {
        // 1. إنشاء رسالة مؤقتة فارغة
        const tempId = await conn.relayMessage(
            m.chat,
            {
                extendedTextMessage: {
                    text: '',
                    contextInfo: {
                        isGroupStatus: true
                    }
                }
            },
            {
                quoted: m
            }
        );

        // 2. إرسال الرسالة المنتحلة
        const tempId2 = await conn.relayMessage(
            m.chat,
            {
                protocolMessage: {
                    key: {
                        jid: m.chat,
                        fromMe: true,
                        id: tempId
                    },
                    type: 14,
                    editedMessage: {
                        extendedTextMessage: {
                            text,
                            contextInfo: {
                                isGroupStatus: false
                            }
                        }
                    }
                }
            },
            {
                messageId: stanzaId
            }
        );

        await new Promise(resolve => setTimeout(resolve, 100));

        // 3. حذف الرسائل المؤقتة
        await Promise.allSettled([
            conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    id: tempId,
                    fromMe: true
                }
            }),
            conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    id: tempId2,
                    fromMe: true
                }
            })
        ]);

    } catch (e) {
        console.error('[fakemsg error]', e);
        await m.reply(`❌ *خطأ:* ${e?.message || e}`);
    }
};

handler.help = ['fakemsg', 'س', 'انتحل'];
handler.tags = ['owner'];
handler.command = ["fakemsg", "س", "انتحل", "ح"];
handler.owner = true;
handler.group = true;

export default handler;