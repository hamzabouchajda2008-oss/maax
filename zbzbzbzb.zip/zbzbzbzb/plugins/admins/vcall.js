import os from 'os'
import path from 'path'
import fs from 'fs'
import v8 from 'v8'
import vm from 'vm'
import crypto from 'crypto'
import { execFile } from 'child_process'
import { promisify } from 'util'
import { pathToFileURL } from 'url'
import yts from 'yt-search'

const execFileAsync = promisify(execFile)
const sleep = ms => new Promise(r => setTimeout(r, ms))

try {
    if (typeof globalThis.gc !== 'function') {
        v8.setFlagsFromString('--expose-gc')
        globalThis.gc = vm.runInNewContext('gc')
    }
} catch {}

// ==========================================================
// vcall v5 — TITAN STABILITY EDITION (مخصص للفيديوهات الطويلة)
// ==========================================================
const VOIP_PATH = path.resolve(process.cwd(), 'lib/package/voip/index.js')
const CACHE_DIR = path.resolve(process.cwd(), 'tmp/vcall-cache')
const MAX_VIDEO_SEC = 120 * 60 // السماح بفيديوهات تصل حتى ساعتين كاملتين بثبات تام
const DEFAULT_PROFILE = 'auto'
const VIDEO_EXT_RE = /\.(mp4|mov|webm|mkv|avi|m4v|3gp)(\?|#|$)/i
const RESOLUTION_RE = /^(240p|360p|480p|720p|1080p|auto)$/i
const FLAG_RE = /^(auto|240p|360p|480p|720p|1080p|end|loop|sw|fps=\d{2}|-live)$/i

const PROFILES = {
    '240p': { box: [426, 240], fps: 15, kbps: 450, level: '3.0' },
    '360p': { box: [640, 360], fps: 20, kbps: 800, level: '3.1' },
    '480p': { box: [854, 480], fps: 25, kbps: 1200, level: '3.1' },
    '720p': { box: [1280, 720], fps: 25, kbps: 2000, level: '3.2' },
    '1080p': { box: [1920, 1080], fps: 25, kbps: 3200, level: '4.0' }
}

const voipInstances = new WeakMap()
let voipModP = null
async function loadVoipMod() {
    if (voipModP) {
        const m = await voipModP.catch(() => null)
        if (m) return m
        voipModP = null
    }
    voipModP = import(pathToFileURL(VOIP_PATH).href)
    return voipModP
}

async function getVoip(conn) {
    let mod
    try {
        mod = await loadVoipMod()
    } catch (e) {
        voipModP = null
        throw new Error('تعذر تحميل مكتبة المكالمات: ' + String(e?.message || e).slice(0, 120))
    }
    let voip = voipInstances.get(conn)
    if (!voip) {
        voip = new mod.default(conn, { voipLogLevel: 'error' })
        voipInstances.set(conn, voip)
    }
    return voip
}

const activeCalls = new Map()

async function resolveMediaSource(query) {
    if (!query) return null
    if (/^https?:\/\//i.test(query) || fs.existsSync(query)) {
        return { url: query, isLive: /m3u8|live|rtsp|rtmp/i.test(query) }
    }
    try {
        const res = await yts(query)
        const vid = res?.videos?.[0]
        if (vid && vid.url) return { url: vid.url, title: vid.title, isLive: false }
    } catch {}
    return { url: query, isLive: false }
}

const runFfmpeg = (args, timeout = 600_000) => {
    const p = execFileAsync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-nostdin', ...args], { timeout, maxBuffer: 16 * 1024 * 1024 })
    try { if (p.child && p.child.pid) os.setPriority(p.child.pid, 10) } catch {}
    return p
}

const parseFps = s => { if (!s) return 0; const [a, b] = String(s).split('/').map(Number); return b ? a / b : (a || 0) }

async function probeVideo(src) {
    try {
        const { stdout } = await execFileAsync('ffprobe', ['-v', 'error', '-show_entries', 'stream=codec_type,codec_name,profile,pix_fmt,width,height,r_frame_rate,avg_frame_rate:format=duration', '-of', 'json', src], { timeout: 20_000 })
        const j = JSON.parse(stdout)
        const streams = Array.isArray(j.streams) ? j.streams : []
        const s = streams.find(x => x.codec_type === 'video' && !(x.disposition && x.disposition.attached_pic)) || streams.find(x => x.codec_type === 'video')
        const a = streams.find(x => x.codec_type === 'audio')
        if (!s || !s.width) return null
        return { codec: s.codec_name, profile: s.profile || '', pix: s.pix_fmt, w: Number(s.width), h: Number(s.height), fps: parseFps(s.avg_frame_rate) || parseFps(s.r_frame_rate), duration: Number(j.format?.duration) || 0, hasAudio: !!a }
    } catch { return null }
}

function fitDims(info, prof) {
    let [bw, bh] = prof.box
    if (info.h > info.w) [bw, bh] = [bh, bw]
    const sc = Math.min(1, bw / info.w, bh / info.h)
    const even = n => Math.max(2, Math.round(n / 2) * 2)
    return { w: even(info.w * sc), h: even(info.h * sc) }
}

// إعدادات مخصصة لتثبيت الإطارات ومنع التقطيع في المقاطع الطويلة
function encFor({ kbps, fps, level }) {
    return {
        args: [
            '-c:v', 'libx264',
            '-preset', 'fast', // توازن مثالى بين سرعة التجهيز وثبات الجودة
            '-tune', 'film',
            '-profile:v', 'baseline',
            '-level', level,
            '-b:v', kbps + 'k',
            '-maxrate', kbps + 'k',
            '-bufsize', (kbps * 2) + 'k',
            '-g', String(fps * 2), // تثبيت حزم التزامن (Keyframes كل ثانيتين لضمان استقرار البث الطويل)
            '-keyint_min', String(fps),
            '-sc_threshold', '0',
            '-bf', '0'
        ]
    }
}

async function prepareVideo(src, profName, prof, isLive = false, say = () => {}) {
    if (isLive) return { path: src, mode: 'live' }

    const key = crypto.createHash('md5').update(src + '|' + profName + '|v5-stable').digest('hex')
    const out = path.join(CACHE_DIR, key + '.mp4')
    if (fs.existsSync(out) && fs.statSync(out).size > 5000) return { path: out, mode: 'cache' }

    say(`✦ جاري تحضير وتثبيت الفيديو الطويل لضمان الاستقرار المطلق (${profName})...`)
    const info = await probeVideo(src)
    const dims = info ? fitDims(info, prof) : null
    const enc = encFor({ kbps: prof.kbps, fps: prof.fps, level: prof.level })

    const vf = (dims ? `scale=${dims.w}:${dims.h}:flags=bilinear,fps=${prof.fps}` : `scale=w=min(${prof.box[0]}\\,iw):h=-2:flags=bilinear,fps=${prof.fps}`) + ',format=yuv420p'
    const tmp = out + '.tmp.mp4'

    const args = [
        '-y', '-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5',
        '-i', src, '-t', String(MAX_VIDEO_SEC), '-map', '0:v:0', '-map', '0:a:0?',
        '-vf', vf, ...enc.args, '-c:a', 'aac', '-b:a', '96k', '-ar', '48000', '-ac', '1',
        '-movflags', '+faststart', tmp
    ]

    try {
        await runFfmpeg(args)
        fs.renameSync(tmp, out)
    } catch (e) {
        try { fs.rmSync(tmp, { force: true }) } catch {}
        throw new Error('فشل معالجة الفيديو: ' + String(e?.message || e).slice(0, 100))
    }
    return { path: out, mode: 'transcoded' }
}

async function downloadQuotedMedia(quoted) {
    const mime = quoted?.mimetype || ''
    const kind = /^video/.test(mime) ? 'video' : /^audio/.test(mime) ? 'audio' : null
    if (!kind) return null
    const buffer = await quoted.download()
    if (!buffer) return null
    const filePath = path.join(os.tmpdir(), `vcall_${kind}_${Date.now()}.${kind === 'video' ? 'mp4' : 'audio'}`)
    fs.writeFileSync(filePath, buffer)
    return { filePath, kind }
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const voip = await getVoip(conn)

    if (command === 'vcallend') {
        const force = args[0] === 'force'
        await voip.end(force)
        const entry = activeCalls.get(m.chat)
        if (entry) activeCalls.delete(m.chat)
        return void (await m.reply('✦ تم إنهاء المكالمة بنجاح.'))
    }

    if (command === 'vcallreact') {
        const entry = activeCalls.get(m.chat)
        if (!entry) throw '✦ لا توجد مكالمة نشطة هنا.'
        const emoji = args[0] || '❤️'
        const sent = entry.call.react(emoji)
        return void (await m.reply(sent ? `✦ تم إرسال التفاعل ${emoji}` : '✦ فشل إرسال التفاعل.'))
    }

    if (command === 'vcallsilent') {
        const entry = activeCalls.get(m.chat)
        if (!entry) throw '✦ لا توجد مكالمة نشطة.'
        const nowSilenced = await entry.call.silent()
        return void (await m.reply(nowSilenced ? '✦ تم كتم الصوت وإيقاف الفيديو مؤقتاً.' : '✦ تم استئناف البث.'))
    }

    if (command === 'vcall' || command === 'فيديو_رن') {
        if (!args[0]) throw `✦ الاستخدام:\n${usedPrefix + command} <رقم الهاتف> [بحث/رابط] [360p/480p/720p] [loop]`
        if (activeCalls.has(m.chat)) throw '✦ توجد مكالمة نشطة بالفعل في هذه المحادثة.'

        const phoneNumber = args[0].replace(/\D/g, '')
        if (phoneNumber.length < 6) throw '✦ رقم الهاتف غير صالح.'

        const rest = args.slice(1)
        const resArg = (rest.find(a => RESOLUTION_RE.test(a)) || '480p').toLowerCase() // 480p خيار مثالي ومستقر جداً للمقاطع الطويلة
        const isLive = rest.includes('-live')
        const loop = rest.includes('loop')
        const autoEndCall = rest.includes('end')
        const queryArgs = rest.filter(a => !FLAG_RE.test(a)).join(' ')

        let finalMedia = 'silence'
        const quoted = m.quoted ? await downloadQuotedMedia(m.quoted) : null

        const { key } = await m.reply(`✦ جاري تحضير الاتصال المستقر بـ ${phoneNumber}...`)
        const say = text => conn.sendMessage(m.chat, { text, edit: key }).catch(() => {})

        try {
            const prof = PROFILES[resArg] || PROFILES['480p']

            if (quoted) {
                finalMedia = quoted.filePath
            } else if (queryArgs) {
                const resolved = await resolveMediaSource(queryArgs)
                if (resolved) {
                    if (resolved.title) await say(`✦ تم العثور على: *${resolved.title}* \nجاري التجهيز لضمان الاستقرار...`)
                    const prep = await prepareVideo(resolved.url, resArg, prof, resolved.isLive || isLive, say)
                    finalMedia = prep.path
                }
            }

            await say(`✦ جاري بدء المكالمة الطويلة مع ${phoneNumber} (وضع الاستقرار الثابت)...`)

            const call = await voip.call(phoneNumber, finalMedia, resArg, { autoEndCall, loop, fps: prof.fps })
            activeCalls.set(m.chat, { call, key, phoneNumber })

            call.on('ringing', () => say(`✦ جاري رنين الهاتف ${phoneNumber}...`))
            call.on('connected', () => say(`✦ متصل الآن — البث الطويل يعمل بثبات تام واستقرار مطلق! (${resArg})`))
            call.on('ended', async reason => {
                activeCalls.delete(m.chat)
                say(`✦ انتهت المكالمة: ${reason}`)
            })
            call.on('error', async err => {
                activeCalls.delete(m.chat)
                conn.reply(m.chat, `✦ خطأ في المكالمة: ${err?.message || err}`, m)
            })
        } catch (e) {
            throw `✦ فشل إتمام الاتصال: ${e?.message || e}`
        }
    }
}

handler.help = ['vcall <number> [search/url] [360p/480p/720p] [loop]']
handler.tags = ['owner']
handler.command = /^(vcall|vcallend|vcallsilent|vcallreact|فيديو_رن)$/i
handler.rowner = true

export default handler
