import axios from "axios";

// ترجمة النص للإنجليزية (مجانية، بلا مفتاح)
async function translateToEnglish(text) {
  try {
    const { data } = await axios.get("https://api.mymemory.translated.net/get", {
      params: { q: text, langpair: "ar|en" },
      timeout: 15000,
    });
    const translated = data?.responseData?.translatedText;
    return translated && translated.length > 0 ? translated : text;
  } catch (e) {
    console.error("[Translate Error]:", e.message);
    return text; // إيلا فشلت الترجمة، كمل بالنص الأصلي
  }
}

async function generateImage(prompt, attempt = 1, maxAttempts = 3) {
  const seed = Math.floor(Math.random() * 1000000);
  const encodedPrompt = encodeURIComponent(prompt);
  const imageUrl =
    `https://image.pollinations.ai/prompt/${encodedPrompt}` +
    `?width=1024&height=1024&seed=${seed}&nologo=true` +
    `&model=flux&enhance=true`;

  try {
    console.log(`[AI Image] محاولة ${attempt}/${maxAttempts}, رابط:`, imageUrl.slice(0, 100));
    const res = await axios.get(imageUrl, {
      responseType: "arraybuffer",
      timeout: 90000,
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    const buffer = Buffer.from(res.data);
    if (!buffer.length || buffer.length < 5000) {
      throw new Error("الصورة صغيرة جدًا أو فارغة");
    }
    return buffer;
  } catch (err) {
    console.error(`[AI Image] فشلت المحاولة ${attempt}:`, err.message);
    if (attempt < maxAttempts) {
      await new Promise((r) => setTimeout(r, 3000));
      return generateImage(prompt, attempt + 1, maxAttempts);
    }
    throw err;
  }
}

const ff = async (m, { text, conn, command }) => {
  if (!text) {
    return m.reply(
      `❌ حط وصف الصورة لي بغيتي البوت يصنعها\n\n` +
      `مثال: *.${command} قطة تلبس نظارة شمسية فـ الفضاء*`
    );
  }

  await conn.sendMessage(m.chat, { react: { text: "🎨", key: m.key } });

  try {
    console.log("[AI Image] الوصف الأصلي:", text);

    // 1. ترجمة الوصف للإنجليزية (يحسن الدقة بشكل كبير)
    const englishPrompt = await translateToEnglish(text);
    console.log("[AI Image] الوصف المترجم:", englishPrompt);

    // 2. توليد الصورة (مع إعادة محاولة تلقائية لحد 3 مرات)
    const imageBuffer = await generateImage(englishPrompt);
    console.log("[AI Image] حجم الصورة النهائي:", imageBuffer.length, "bytes");

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    await conn.sendMessage(
      m.chat,
      {
        image: imageBuffer,
        caption: `🎨 *تم توليد الصورة*\n\n📝 الوصف: ${text}`,
      },
      { quoted: m }
    );
  } catch (error) {
    console.error("[AI Image Error]:", error.message);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply("❌ صار خطأ أثناء توليد الصورة بعد عدة محاولات، جرب وصف مختلف أو حاول من بعد.");
  }
};

ff.usage = ["صورة"];
ff.category = "ai";
ff.command = ["صورة", "image", "imagine", "ai-image"];
export default ff;