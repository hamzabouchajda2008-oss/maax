// ضع هاد الملف فـ ./plugins/anticontact.js

// ⚠️ عدّل هذا الرقم لرقم المالك الحقيقي (نفس اللي بملف index.js بالضبط)
const PROTECTED_OWNERS = ["212625654754@s.whatsapp.net"];

const antiContact = async () => {
    // ما كاينش أمر مباشر، الشغل كامل جوا .before
    return false;
};

antiContact.before = async (m, { conn, bot }) => {
    try {
        // 🐛 سطر تجريبي مؤقت: باش نتأكد وا هاد الـ hook كيتفذ أصلاً مع كل رسالة.
        // شوف الـ logs ديال السيرفر بعدما تبعث أي رسالة عادية فالجروب.
        // إلا ظهرلك هاد السطر فالـ console → الافتراض صحيح، احذفو من بعد.
        console.log('[antiContact.before] triggered:', m.chat, m.sender);

        if (!m.isGroup) return false;

        const message = m.message || m.msg || {};
        const isContact =
            message.contactMessage ||
            message.contactsArrayMessage ||
            message.viewOnceMessage?.message?.contactMessage ||
            message.viewOnceMessageV2?.message?.contactMessage ||
            message.viewOnceMessageV2Extension?.message?.contactMessage;

        if (!isContact) return false;

        const sender = m.sender;
        const chat = m.chat;

        const botJid = conn?.user?.id?.split(':')[0] + '@s.whatsapp.net';
        const isBot = sender === botJid;
        const isProtected = PROTECTED_OWNERS.includes(sender);

        // نتأكد وا المرسل أدمن فالجروب (الأدمنات معفيين)
        let isAdmin = false;
        try {
            const metadata = await conn.groupMetadata(chat);
            const participant = metadata?.participants?.find(p => p.id === sender);
            isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch (e) {
            console.error('فشل جلب بيانات الجروب للتحقق من الأدمنية:', e);
        }

        // الأونر والبوت نفسه والأدمنات معفيين
        if (isBot || isProtected || isAdmin) return false;

        // 1) حذف رسالة جهة الاتصال
        try {
            const key = m.key || { remoteJid: chat, id: m.id, participant: sender, fromMe: false };
            await conn.sendMessage(chat, { delete: key });
        } catch (e) {
            console.error('فشل حذف رسالة جهة الاتصال:', e);
        }

        // 2) طرد المرسل
        let kicked = false;
        try {
            await conn.groupParticipantsUpdate(chat, [sender], 'remove');
            kicked = true;
        } catch (e) {
            console.error('فشل طرد مرسل جهة الاتصال:', e);
        }

        // 3) رسالة تنبيه فالجروب
        const senderTag = '@' + sender.split('@')[0];
        const warningText =
            `🚫 *تم رصد مشاركة جهة اتصال (فيكارد)*\n` +
            `⊱⋅ ──────────── ⋅⊰\n\n` +
            `👤 *المخالف:* ${senderTag}\n` +
            `🗑️ *تم حذف الرسالة مباشرة*\n` +
            `${kicked ? '👢 تم طرد المخالف من الجروب' : '⚠️ لم يتم طرد المخالف (تأكد أن البوت أدمن بالجروب)'}`;

        try {
            await conn.sendMessage(chat, {
                text: warningText,
                mentions: [sender]
            });
        } catch (e) {
            console.error('فشل إرسال رسالة تحذير جهة الاتصال:', e);
        }

        return true; // اتعامل مع الرسالة، وقف أي معالجة تانية ليها
    } catch (e) {
        console.error(e);
    }
    return false;
};

antiContact.command = [];
export default antiContact;
