// ============================================
// 🔗 Anti-Link: كايمسح غير روابط جروبات/قنوات واتساب
// (chat.whatsapp.com, whatsapp.com/channel, wa.me)
// + Patch: يكتشف الروابط ديال polls (استطلاعات) اللي كانت كتخبى الرابط
// ============================================

const getWarnDB = (chat) => {
    if (!global.db.antiLinkWarns) global.db.antiLinkWarns = {};
    if (!global.db.antiLinkWarns[chat]) global.db.antiLinkWarns[chat] = {};
    return global.db.antiLinkWarns[chat];
};

const addWarning = async (chat, sender, conn, reason, viaPoll = false) => {
    const warnDB = getWarnDB(chat);
    const count = (warnDB[sender] || 0) + 1;
    warnDB[sender] = count;

    // 😤 رسالة استفزازية إيلا كانت المحاولة عبر ثغرة (poll) - باش نبينو أننا فطنين
    const tauntLine = viaPoll
        ? `\n\n😏 خبيتي الرابط فـ poll باش تتخطى البوت؟ احنا ما تشتغل معانا لعب الاطفال هاذا.`
        : '';

    if (count >= 3) {
        delete warnDB[sender];
        try {
            await conn.sendMessage(chat, {
                text: `⛔ *طرد نهائي*\n\n@${sender.split('@')[0]} تم طردك من المجموعة\nالسبب: ${reason} - تجاوز 3 تحذيرات${tauntLine}`,
                mentions: [sender]
            });
        } catch (e) {
            console.log('anti-link warn-msg error:', e?.message || e);
        }
        try {
            await conn.groupParticipantsUpdate(chat, [sender], 'remove');
        } catch (e) {
            console.log('anti-link kick error:', e?.message || e);
            try {
                await conn.sendMessage(chat, {
                    text: `⚠️ تعذّر طرد @${sender.split('@')[0]} تلقائيًا (تأكدو أن البوت أدمين)، يرجى من الإدارة التدخل يدويًا.`,
                    mentions: [sender]
                });
            } catch {}
        }
        return count;
    }

    try {
        await conn.sendMessage(chat, {
            text:
                `🚫 *تم حذف الرابط*\n\n@${sender.split('@')[0]}\n` +
                `السبب: ${reason}\n\n` +
                `📌 التحذير: ${count} / 3${count === 2 ? '\n⚠️ تحذير أخير! التكرار القادم يعني الطرد الفوري.' : ''}` +
                tauntLine +
                `\n\n> يرجى الالتزام بقوانين المجموعة`,
            mentions: [sender]
        });
    } catch (e) {
        console.log('anti-link warn-msg error:', e?.message || e);
    }
    return count;
};

// 🔓 كيفك رسائل ملفوفة (ephemeral / view-once) باش نوصلو للمحتوى الحقيقي
// polls كثير من التطبيقات كيبعتوهم ملفوفين جوا هاد الأنواع
function unwrapMessage(msg) {
    if (!msg) return msg;
    const wrappers = [
        'ephemeralMessage',
        'viewOnceMessage',
        'viewOnceMessageV2',
        'viewOnceMessageV2Extension',
        'documentWithCaptionMessage'
    ];
    let current = msg;
    for (let i = 0; i < 5; i++) { // حماية من اللف اللانهائي
        const key = wrappers.find(w => current?.[w]?.message);
        if (!key) break;
        current = current[key].message;
    }
    return current;
}

async function antiLinkHandler(m, conn) {
    if (!m.chat?.endsWith('@g.us')) return false; // فقط فالجروبات

    // 🐛 DEBUG: باش نشوفو واش الهاندلر كيتوصل ليه أصلا مع رسائل poll
    // وشنو كايوصل بالضبط جوا m.message. عندما تتأكد أن كلشي خدام، يمكنك تشيل هاد السطر.
    console.log('[anti-link DEBUG] mtype:', m.mtype, '| message keys:', Object.keys(m.message || {}));

    const g = global.db?.groups?.[m.chat];
    if (!g?.antiLink) return false;

    // 🔐 إعفاء المالك/الأدمين — نتاكدو بفحص فريش زيادة على m.isOwner/m.isAdmin
    let exempt = m.isOwner || m.isAdmin || false;
    if (!exempt) {
        try {
            const metadata = await conn.groupMetadata(m.chat);
            const senderNum = m.sender?.split('@')[0];
            const participant = metadata.participants.find(
                p => p.id === m.sender || p.id?.split('@')[0] === senderNum
            );
            exempt = participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch (e) {
            console.log('anti-link metadata fetch error:', e?.message || e);
        }
    }
    if (exempt) return false;

    // 🔓 نفكو أي غلاف (ephemeral/view-once) قبل ما نقلبو على الـ poll
    const unwrapped = unwrapMessage(m.message) || {};

    // 🐛 DEBUG: تأكد واش كاين poll جوا الرسالة الملفوفة
    if (unwrapped !== m.message) {
        console.log('[anti-link DEBUG] كانت الرسالة ملفوفة! keys بعد الفك:', Object.keys(unwrapped));
    }

    // 🗳️ استخراج نص الـ poll (السؤال + الخيارات) — هادي هي الثغرة اللي كانت خبّاية الرابط
    const pollMsg = unwrapped?.pollCreationMessage
        || unwrapped?.pollCreationMessageV2
        || unwrapped?.pollCreationMessageV3;

    let pollText = '';
    if (pollMsg) {
        const pollName = pollMsg.name || '';
        const pollOptions = (pollMsg.options || [])
            .map(o => o.optionName || '')
            .join(' ');
        pollText = `${pollName} ${pollOptions}`;
        // 🐛 DEBUG
        console.log('[anti-link DEBUG] pollMsg found, extracted text:', JSON.stringify(pollText));
    }

    // 📝 جمع النص من كل المصادر الممكنة (بما فيها الآن الـ poll)
    const rawText = [
        m.text,
        m.body,
        m.caption,
        m.message?.conversation,
        m.message?.extendedTextMessage?.text,
        m.message?.imageMessage?.caption,
        m.message?.videoMessage?.caption,
        m.quoted?.text,
        m.quoted?.caption,
        pollText
    ].filter(Boolean).join(' ');

    if (!rawText) return false;

    // 🧠 تطبيع النص: كايشيل حيل التمويه (مسافات، [.]، (dot)، حروف مخفية، أرقام بدل حروف)
    const normalized = rawText
        .toLowerCase()
        .replace(/[\u200b\u200c\u200d\u2060\u180e\uFEFF\u00ad\uFFF9-\uFFFB]/g, '')
        .replace(/0/g, 'o')
        .replace(/1/g, 'l')
        .replace(/3/g, 'e')
        .replace(/4/g, 'a')
        .replace(/@/g, 'a')
        .replace(/\(dot\)|\[dot\]|\s+dot\s+|\{dot\}/gi, '.')
        .replace(/\[\.\]|\(\.\)|\{\.\}/g, '.')
        .replace(/\s*\.\s*/g, '.')
        .replace(/\.{2,}/g, '.')
        .replace(/\s+/g, '');

    // 🔗 غير روابط جروبات/قنوات واتساب — بلا https/www، ومع دعم أي بارامترات فالآخر
    const linkRegex = /(chat\.whatsapp\.com\/[a-z0-9]{10,}|whatsapp\.com\/channel\/[a-z0-9]{10,}|wa\.me\/[a-z0-9]{6,})/i;

    if (!linkRegex.test(normalized)) return false;

    // 🗑️ محاولة حذف مباشرة
    // ملاحظة: رسائل الـ poll فواتساب صعيبة الحذف (خصوصا poll ديال شخص آخر عبر بوت غير أدمين
    // فبعض الحالات)، البوت غادي يحاول يحذف بنفس الطريقة، وإيلا فشل غادي يكمل التحذير/الطرد.
    try {
        await conn.sendMessage(m.chat, { delete: m.key });
    } catch (e) {
        console.log('anti-link delete error:', e?.message || e);
    }

    const reason = pollMsg
        ? 'نشر رابط جروب/قناة مخبّى داخل استطلاع (Poll) 🗳️🔗'
        : 'نشر رابط جروب/قناة 🔗';

    await addWarning(m.chat, m.sender, conn, reason, !!pollMsg);
    return true;
}

export default async function before(m, { conn }) {
    try {
        return await antiLinkHandler(m, conn);
    } catch (e) {
        console.log('anti-link fatal error:', e?.message || e);
        return false;
    }
}
