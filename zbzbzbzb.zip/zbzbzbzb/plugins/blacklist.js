// ضع هاد الملف فـ ./plugins/blacklist.js

/*
╔══════════════════════════════════════════════════════════════╗
║  📖 شنو هو الـ LID؟ (بشكل بسيط)                                  ║
╠══════════════════════════════════════════════════════════════╣
║                                                                  ║
║  فـ واتساب، كل عضو عندو "بطاقة تعريف" (jid) باش الأنظمة تعرفو بيها.║
║                                                                  ║
║  📱 قبل: البطاقة كانت دايماً = رقم الهاتف                        ║
║      مثال: 212600000000@s.whatsapp.net                         ║
║                                                                  ║
║  🕵️ دابا: واتساب زاد خيار خصوصية "إخفاء رقمي"                   ║
║      إلا فعّلو شخص هاد الخيار، البوت ما يشوفش رقمو الحقيقي،      ║
║      وكيوصلو عوضو رقم مستعار عشوائي اسمو LID                    ║
║      مثال: 91847362910@lid   ← هذا ماشي رقم هاتف حقيقي!         ║
║                                                                  ║
║  ⚠️ المشكل: بعض أوامر واتساب (كيفاش تطرد شخص مثلاً)             ║
║      خاصها الـ jid الصحيح ديال هاد الجروب بالضبط،                ║
║      وإلا خلطنا بين lid و jid، العملية كتفشل بصمت.               ║
║                                                                  ║
║  ✅ الحل ديالنا: دالة resolveRealJid تحت كتدور فأعضاء الجروب      ║
║      وتلقى العلاقة بين الـ lid والرقم الحقيقي (إلا كانت متوفرة)، ║
║      ولوقت الطرد كتستعمل المعرف الصحيح ديال كل جروب بذاتو.       ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════╝
*/

import { addToBlacklist, removeFromBlacklist, getBlacklist } from '../system/blacklist.js';

// ⚠️ عدّل هذي الأرقام لأرقام المالكين الحقيقية (نفس اللي بملف index.js بالضبط)
const PROTECTED_OWNERS = [
    "212625654754@s.whatsapp.net",
    "212721125336@s.whatsapp.net"
];

// 🔑 كتحول أي معرف lid (مخفي) لرقم حقيقي، بالبحث فأعضاء الجروب الحالي.
// شوف الشرح الكامل فأعلى الملف.
// بنية العضو الحقيقية: { id: "xxxx@lid", phoneNumber: "212xxxxxxxxx@s.whatsapp.net", admin }
const resolveRealJid = async (conn, chat, candidate) => {
    if (!candidate) return null;
    if (candidate.endsWith('@s.whatsapp.net')) return candidate;

    try {
        const metadata = await conn.groupMetadata(chat);
        const p = metadata?.participants?.find(x => x.id === candidate);
        if (p?.phoneNumber) return p.phoneNumber;
    } catch (e) {
        console.error('فشل حل هوية العضو (lid → رقم):', e);
    }

    return candidate; // ما لقيناش رقم حقيقي، نرجعو كيفما جا (fallback)
};

// 🔑 رقم البوت ممكن يجي بصيغ مختلفة حسب الجهاز (بنقطة، بنقطتين، أو بلا شي)
// هاد الدالة كتاخد غير الأرقام من البداية، بغض النظر شنو الفاصل
const getBotNumber = (conn) => {
    const raw = conn?.user?.id || '';
    const digits = raw.match(/^\d+/)?.[0];
    return digits ? `${digits}@s.whatsapp.net` : null;
};

const blacklist = async (m, { conn }) => {
    if (!PROTECTED_OWNERS.includes(m.sender)) {
        await conn.sendMessage(m.chat, {
            text: '*♡ 🇩🇪 الأمر ده لـ المطورين فقط 🇩🇪♡*'
        }, { quoted: m });
        return;
    }

    // نشيل البادئة وكلمة الأمر من بداية النص إلا كانو موجودين
    // (بعض الأطر كتبعث النص كامل ".بلاك اضافة ..." بلا ما تشيل الأمر)
    const PREFIXES = ['.', '/', '!', '7away', 'hamza', 'bitch'];
    const COMMAND_WORDS = ['بلاك', 'blacklist', 'حظر'];

    let raw = (m.text || '').trim();

    for (const p of PREFIXES) {
        if (raw.toLowerCase().startsWith(p.toLowerCase())) {
            raw = raw.slice(p.length).trim();
            break;
        }
    }
    for (const c of COMMAND_WORDS) {
        if (raw.toLowerCase().startsWith(c.toLowerCase())) {
            raw = raw.slice(c.length).trim();
            break;
        }
    }

    const args = raw.split(/\s+/).filter(Boolean);
    const sub = (args[0] || '').toLowerCase();

    // تحديد الهدف الأولي: منشن، أو رد على رسالة، أو رقم مكتوب يدوي
    const numberArg = args.slice(1).join('').replace(/[^0-9]/g, '');
    let targetJid =
        m.mentionedJid?.[0] ||
        m.quoted?.sender ||
        (numberArg ? `${numberArg}@s.whatsapp.net` : null);

    // 🔑 نحاول نحلو أي معرف مخفي (lid) للرقم الحقيقي عبر بيانات الجروب الحالي
    if (targetJid && m.isGroup) {
        targetJid = await resolveRealJid(conn, m.chat, targetJid);
    }

    // ============ إضافة ============
    if (['اضافة', 'add', 'ضيف'].includes(sub)) {
        if (!targetJid) {
            await conn.sendMessage(m.chat, {
                text: '*❌ حدد رقم، منشن، أو رد على رسالة الشخص*\n\nمثال: .بلاك اضافة 212600000000'
            }, { quoted: m });
            return;
        }

        // ⚠️ إلا بقا المعرف مخفي (lid) رغم محاولة الحل، نحذر بدل ما نخزن رقم فاسد
        if (!targetJid.endsWith('@s.whatsapp.net')) {
            await conn.sendMessage(m.chat, {
                text: `⚠️ *ما قدرتش نلقى الرقم الحقيقي ديال هاد العضو*\n\n` +
                      `معرفو مخفي (lid) وما قدرتش نحلو من بيانات الجروب.\n` +
                      `جرب رد على رسالة توصلت منو مباشرة فنفس الجروب لي هو عضو فيه.`
            }, { quoted: m });
            return;
        }

        const addResult = addToBlacklist(targetJid);

        if (addResult === 'protected') {
            await conn.sendMessage(m.chat, {
                text: `🛡️ *ما نقدرش نزيد هاد الرقم للقائمة السوداء*\n\nهذا رقم مالك محمي، ما يمكنش يتحظر.`,
                mentions: [targetJid]
            }, { quoted: m });
            return;
        }

        // 🚨 طرد فوري من كل الجروبات الحالية لي البوت فيها أدمن
        let kickedFrom = 0;
        try {
            const allGroups = await conn.groupFetchAllParticipating();
            const botJid = getBotNumber(conn);

            for (const gid of Object.keys(allGroups)) {
                try {
                    const metadata = allGroups[gid];

                    const mp = metadata.participants?.find(p =>
                        p.id === targetJid || p.phoneNumber === targetJid
                    );
                    if (!mp) continue;

                    const botP = metadata.participants.find(p =>
                        p.id === botJid || p.phoneNumber === botJid
                    );
                    const botIsAdmin = botP?.admin === 'admin' || botP?.admin === 'superadmin';
                    if (!botIsAdmin) continue;

                    // نستعمل المعرف الأصلي ديال هاد الجروب بالضبط (lid) باش الطرد يضمن يخدم
                    await conn.groupParticipantsUpdate(gid, [mp.id], 'remove');
                    kickedFrom++;
                } catch (e) {
                    console.error('فشل طرد من جروب:', gid, e);
                }
            }
        } catch (e) {
            console.error('فشل جلب قائمة الجروبات:', e);
        }

        await conn.sendMessage(m.chat, {
            text: `⛔ *تمت إضافة العضو للقائمة السوداء*\n⊱⋅ ──────────── ⋅⊰\n\n` +
                  `👤 @${targetJid.split('@')[0]}\n` +
                  `👢 تم طرده فوراً من ${kickedFrom} جروب${kickedFrom === 1 ? '' : 'ات'} البوت فيها أدمن\n` +
                  `♻️ وغادي يتطرد تلقائياً من أي جروب جديد يحاول يدخل ليه`,
            mentions: [targetJid]
        }, { quoted: m });
        return;
    }

    // ============ حذف ============
    if (['حذف', 'remove', 'شيل'].includes(sub)) {
        if (!targetJid) {
            await conn.sendMessage(m.chat, {
                text: '*❌ حدد رقم، منشن، أو رد على رسالة الشخص*'
            }, { quoted: m });
            return;
        }
        const ok = removeFromBlacklist(targetJid);
        await conn.sendMessage(m.chat, {
            text: ok
                ? `✅ تم حذف @${targetJid.split('@')[0]} من القائمة السوداء`
                : '⚠️ هذا الرقم ماشي فالقائمة السوداء أصلاً',
            mentions: [targetJid]
        }, { quoted: m });
        return;
    }

    // ============ عرض ============
    if (['قائمة', 'list', 'عرض'].includes(sub)) {
        const list = getBlacklist();
        if (!list.length) {
            await conn.sendMessage(m.chat, { text: '📋 القائمة السوداء فارغة حالياً' }, { quoted: m });
            return;
        }
        const text = list.map((j, i) => `${i + 1}. @${j.split('@')[0]}`).join('\n');
        await conn.sendMessage(m.chat, {
            text: `📋 *القائمة السوداء (${list.length})*\n⊱⋅ ──────────── ⋅⊰\n\n${text}`,
            mentions: list
        }, { quoted: m });
        return;
    }

    // ============ مساعدة ============
    await conn.sendMessage(m.chat, {
        text: `*📋 أوامر القائمة السوداء*\n⊱⋅ ──────────── ⋅⊰\n\n` +
              `.بلاك اضافة [رقم / منشن / رد]\n` +
              `.بلاك حذف [رقم / منشن / رد]\n` +
              `.بلاك قائمة`
    }, { quoted: m });
};

blacklist.command = ['بلاك', 'blacklist', 'حظر'];
export default blacklist;
