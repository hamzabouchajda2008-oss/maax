import axios from "axios";

const CONSUMET_URL = "https://api.consumet.org/anime/gogoanime";

let handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply("مثال: .انمي Naruto");

  if (command === "انمي") {
    try {
      const { data } = await axios.get(`${CONSUMET_URL}/${encodeURIComponent(text)}`);
      const results = data.results;

      if (!results || results.length === 0) return m.reply("❌ لم يتم العثور على نتائج!");

      const sections = [{
        title: "📺 نتائج البحث",
        rows: results.map(anime => ({
          title: anime.title,
          description: `🆔 ${anime.id}`,
          id: `.تحميل_انمي ${anime.id}`
        }))
      }];

      return await conn.sendButtonNormal(m.chat, {
        media: { url: results[0]?.image },
        mediaType: 'image',
        caption: `📌 *نتائج البحث عن:* "${text}"\n\nاختر الأنمي من القائمة أدناه:`,
        buttons: [
          { name: "single_select", params: { title: "🎬 اختر الأنمي", sections } }
        ],
        mentions: [m.sender]
      }, m);
    } catch (e) {
      return m.reply("❌ حدث خطأ أثناء البحث عن الأنمي.");
    }
  }

  if (command === "تحميل_انمي") {
    try {
      const { data } = await axios.get(`${CONSUMET_URL}/info/${text}`);

      const episodeSections = [{
        title: `📺 ${data.title}`,
        rows: data.episodes.map(ep => ({
          title: `الحلقة ${ep.number}`,
          description: `اضغط لجلب روابط التحميل`,
          id: `.جلب_حلقة ${ep.id}`
        }))
      }];

      return await conn.sendButtonNormal(m.chat, {
        media: { url: data.image },
        mediaType: 'image',
        caption: `🎬 *${data.title}*\n🎭 النوع: ${data.genres?.join(", ")}\n📅 السنة: ${data.releaseDate}\n\n📝 ${data.description?.slice(0, 200)}...`,
        buttons: [
          { name: "single_select", params: { title: "🎬 اختر الحلقة", sections: episodeSections } }
        ],
        mentions: [m.sender]
      }, m);
    } catch (e) {
      return m.reply("❌ حدث خطأ أثناء جلب تفاصيل الأنمي.");
    }
  }

  if (command === "جلب_حلقة") {
    try {
      const { data } = await axios.get(`${CONSUMET_URL}/watch/${text}`);

      if (!data.sources || data.sources.length === 0) return m.reply("❌ لم يتم العثور على روابط لهذه الحلقة.");

      const qualitySections = [{
        title: `🎬 الحلقة`,
        rows: data.sources.map(source => ({
          title: `📥 جودة: ${source.quality}`,
          description: "اضغط للتحميل المباشر",
          id: `.رابط_تحميل ${source.url}|${source.quality}`
        }))
      }];

      return await conn.sendButtonNormal(m.chat, {
        media: { url: "https://cdn.pixabay.com/photo/2017/08/30/01/05/milky-way-2695569_1280.jpg" },
        mediaType: 'image',
        caption: `🎬 *اختر جودة الحلقة المطبوبة للتحميل:*`,
        buttons: [
          { name: "single_select", params: { title: "📥 الجودة", sections: qualitySections } }
        ],
        mentions: [m.sender]
      }, m);
    } catch (e) {
      return m.reply("❌ حدث خطأ أثناء جلب سيرفرات الحلقة.");
    }
  }

  if (command === "رابط_تحميل") {
    const [url, quality] = text.split("|");

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
      await conn.sendMessage(m.chat, {
        document: { url: url },
        mimetype: "video/mp4",
        fileName: `Anime_Episode_${quality}.mp4`,
        caption: `✅ تم التحميل بجودة *${quality}*\n بواسطة 𝐉𝐎𝐘 𝐁𝐎𝐘 𝐁𝐎𝐓`
      }, { quoted: m });

      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (e) {
      await m.reply(`❌ تعذر تحميل الملف مباشرة إلى الواتساب (قد يكون حجم الحلقة كبيراً).\n\n🔗 *رابط التحميل المباشر:*\n${url}`);
    }
  }
};

handler.usage = ["انمي"];
handler.command = ["انمي", "تحميل_انمي", "جلب_حلقة", "رابط_تحميل"];
handler.category = "downloads";

export default handler;
