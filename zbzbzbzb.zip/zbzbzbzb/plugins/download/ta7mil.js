// =============================================
// 📌 سكربت تحميل الأفلام والمسلسلات - متوافق مع بوتك
// =============================================

// =============================================
// 📌 المكتبات المطلوبة للتثبيت
// =============================================
/*
npm install yt-search axios cheerio @rindev/lk21dl-core movies-downloader
*/

import yts from "yt-search";
import axios from "axios";
import cheerio from "cheerio";
import lk21dl from "@rindev/lk21dl-core";
import moviesDownloader from 'movies-downloader';
import fs from 'fs';
import path from 'path';

// =============================================
// 📌 دوال البحث والتحميل
// =============================================

// البحث من LK21
async function searchLk21(query) {
    try {
        const results = await lk21dl.search(query);
        return results;
    } catch (e) {
        console.error('[LK21 Error]', e.message);
        return [];
    }
}

// تحميل من LK21
async function downloadLk21(url, filename) {
    try {
        const result = await lk21dl.download(url, `./downloads/${filename}.mp4`);
        return result;
    } catch (e) {
        console.error('[Download Error]', e.message);
        return null;
    }
}

// البحث من EgyBest
async function searchEgyBest(query) {
    try {
        const url = `https://egybest.uno/search/${encodeURIComponent(query)}`;
        const response = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        const $ = cheerio.load(response.data);
        const results = [];
        
        $('.movie-item').each((i, el) => {
            const title = $(el).find('.title').text().trim();
            const link = 'https://egybest.uno' + $(el).find('a').attr('href');
            const year = $(el).find('.year').text().trim();
            const rating = $(el).find('.rating').text().trim();
            results.push({ title, link, year, rating });
        });
        
        return results;
    } catch (e) {
        console.error('[EgyBest Error]', e.message);
        return [];
    }
}

// البحث من تورنت
async function searchTorrent(query) {
    try {
        const results = await moviesDownloader.search(query);
        return results;
    } catch (e) {
        console.error('[Torrent Error]', e.message);
        return [];
    }
}

// =============================================
// 📌 معالج الأوامر
// =============================================

let handler = async (m, { conn, text, command, usedPrefix }) => {
    // التحقق من الصلاحيات
    if (!global.owner?.includes(m.sender)) {
        return m.reply('❌ هذا الأمر خاص بمالك البوت فقط');
    }

    if (!text) {
        return m.reply(
            `╭───(   🎬 𝐉𝐎𝐘 𝐁𝐎𝐘 𝐌𝐎𝐕𝐈𝐄   )───\n` +
            `├ 📌 اكتب اسم الفيلم أو المسلسل.\n` +
            `├ مثال: ${usedPrefix}${command} The Walking Dead\n` +
            `╰──────────────────☉`
        );
    }

    await conn.sendMessage(m.chat, { react: { text: "🎬", key: m.key } });

    let results = [];

    // === مرحلة 1: البحث عن الفيلم ===
    try {
        // محاولة البحث من LK21 أولاً
        results = await searchLk21(text);
        
        // إذا لم يجد، ابحث من EgyBest
        if (results.length === 0) {
            results = await searchEgyBest(text);
        }
        
        // إذا لم يجد، ابحث من تورنت
        if (results.length === 0) {
            results = await searchTorrent(text);
        }

        if (results.length === 0) {
            await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
            return m.reply("❌ لم يتم العثور على فيلم بهذا الاسم");
        }

    } catch (err) {
        console.error("[Movie Error - Search]:", err);
        await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        return m.reply("❌ حدث خطأ أثناء البحث.");
    }

    // === مرحلة 2: عرض النتائج ===
    const caption =
        `╭───(   🎬 𝐉𝐎𝐘 𝐁𝐎𝐘 𝐌𝐎𝐕𝐈𝐄   )───\n` +
        `├ 📌 *نتائج البحث عن:* ${text}\n` +
        `├ 📊 *عدد النتائج:* ${results.length}\n` +
        `╰────────────────────☉\n\n`;

    let list = '';
    results.slice(0, 10).forEach((r, i) => {
        list += `${i+1}. *${r.title || r.name || 'غير معروف'}*\n`;
        list += `📅 ${r.year || r.releaseYear || 'غير معروف'} | ⭐ ${r.rating || r.voteAverage || 'لا يوجد'}\n`;
        list += `🔗 ${r.link || r.url || r.magnet || 'لا يوجد رابط'}\n\n`;
    });

    await m.reply(caption + list);

    // === مرحلة 3: تحميل الفيلم (إذا كان هناك رابط مباشر) ===
    const firstResult = results[0];
    if (firstResult.link && firstResult.link.includes('lk21')) {
        await m.reply('⏳ جاري تحميل الفيلم... قد يستغرق بعض الوقت.');
        
        try {
            const filename = firstResult.title || 'movie';
            const result = await downloadLk21(firstResult.link, filename);
            
            if (result) {
                await conn.sendMessage(m.chat, {
                    document: fs.readFileSync(`./downloads/${filename}.mp4`),
                    fileName: `${filename}.mp4`,
                    mimetype: 'video/mp4',
                    caption: `✅ *تم التحميل*\n📁 ${filename}.mp4`
                });
            } else {
                await m.reply('❌ فشل التحميل، تأكد من الرابط');
            }
        } catch (err) {
            console.error("[Movie Error - Download]:", err);
            await m.reply("❌ فشل تحميل الفيلم.");
        }
    } else if (firstResult.magnet) {
        await m.reply(`🔗 *رابط التورنت:*\n${firstResult.magnet}\n\nاستخدم برنامج تورنت للتحميل.`);
    } else {
        await m.reply('🔗 *رابط المشاهدة:*\n' + (firstResult.link || firstResult.url || 'لا يوجد رابط'));
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
};

// =============================================
// 📌 إعدادات الأمر
// =============================================

handler.help = ["movie", "film", "فيلم"];
handler.command = ["فيلم", "movie", "film", "افلام", "مسلسل", "series"];
handler.tags = ["downloader"];
handler.owner = true;

export default handler;