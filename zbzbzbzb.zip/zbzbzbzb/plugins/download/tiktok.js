import axios from "axios";

const RAPIDAPI_KEY = "a418eb4c91msh89d00f1d7800685p1d0ce6jsn5822a8664c09"; // نفس المفتاح ديالك
const RAPIDAPI_HOST = "tiktok-scraper7.p.rapidapi.com";

const ff = async (m, { text, conn }) => {
  if (!text) {
    return m.reply("❌ حط اسم شخص أو كلمة بحث جنب الأمر\n\nمثال: *.تيك lofi*");
  }

  await conn.sendMessage(m.chat, { react: { text: "⌛", key: m.key } });

  try {
    console.log("[Tiktok] بدء البحث عن:", text);

    const { data } = await axios.get(`https://${RAPIDAPI_HOST}/feed/search`, {
      params: {
        keywords: text,
        region: "us",
        count: 10,
        cursor: 0,
        publish_time: 0,
        sort_type: 0,
      },
      headers: {
        "X-RapidAPI-Key": RAPIDAPI_KEY,
        "X-RapidAPI-Host": RAPIDAPI_HOST,
      },
      timeout: 30000,
    });

    console.log("[Tiktok] الرد:", JSON.stringify(data).slice(0, 300));

    if (data.code !== 0 || !data.data?.videos?.length) {
      console.log("[Tiktok] لا نتائج. code:", data.code, "msg:", data.msg);
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return m.reply("❌ ما لقيتش فيديوهات لهاد الكلمة، جرب كلمة أخرى.");
    }

    const videos = data.data.videos
      .filter((v) => v.play || v.wmplay)
      .slice(0, 4);

    if (!videos.length) {
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      return m.reply("❌ ما لقيتش روابط صالحة للفيديوهات.");
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    for (const [i, v] of videos.entries()) {
      const author = v.author?.nickname || v.author?.unique_id || "غير معروف";
      const durationText = v.duration ? `${v.duration}s` : "";

      try {
        await conn.sendMessage(
          m.chat,
          {
            video: { url: v.play || v.wmplay },
            caption:
              `🎬 *${i + 1}/${videos.length}*\n` +
              `📌 ${v.title || "بدون وصف"}\n` +
              `👤 ${author}\n` +
              `⏱️ ${durationText}`,
          },
          { quoted: m }
        );
      } catch (sendErr) {
        console.error(`[Tiktok Send Error] فيديو ${i + 1}:`, sendErr.message);
      }
    }
  } catch (error) {
    console.error("[Tiktok Search Error]:", error.message);
    console.error("[Tiktok Search Error] التفاصيل:", error.response?.data || "");
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply("❌ صار خطأ أثناء البحث، جرب مرة أخرى.");
  }
};

ff.usage = ["تيك"];
ff.category = "downloads";
ff.command = ["تيك", "tiktok", "tt"];
export default ff;