import yts from "yt-search";
import axios from "axios";

const RAPIDAPI_KEY = "4aa9ff52a9mshea36929c30571e8p142beajsn06dd81d0f3ef";
const RAPIDAPI_HOST = "youtube-mp36.p.rapidapi.com";

async function getMp3Link(videoId, retries = 8) {
  for (let i = 0; i < retries; i++) {
    const { data } = await axios.get(`https://${RAPIDAPI_HOST}/dl`, {
      params: { id: videoId },
      headers: {
        "X-RapidAPI-Key": RAPIDAPI_KEY,
        "X-RapidAPI-Host": RAPIDAPI_HOST,
      },
      timeout: 30000,
    });

    if (data.status === "ok" && data.link) {
      return data;
    }

    if (data.status === "processing" || data.progress < 100) {
      await new Promise((r) => setTimeout(r, 3000));
      continue;
    }

    throw new Error("فشل التحويل: " + (data.msg || JSON.stringify(data)));
  }
  throw new Error("انتهت المحاولات، الخدمة بطيئة حاليًا");
}

function formatDuration(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  const query = text ? text.trim() : "";
  if (!query) {
    return m.reply(
      `╭───(   𝐉𝐎𝐘 𝐁𝐎𝐘 𝐁𝐎𝐓   )───\n` +
      `├ 🇲🇦 اكتب اسم الأغنية أو رابط يوتيوب.\n` +
      `├ مثال: ${usedPrefix}${command} l'morphiniya 33\n` +
      `╰──────────────────☉`
    );
  }

  await conn.sendMessage(m.chat, { react: { text: "⌛", key: m.key } });

  let video, result;

  // === مرحلة 1: البحث + جيب رابط MP3 ===
  try {
    const search = await yts(query);
    if (!search.videos.length) throw new Error("لم يتم العثور على الفيديو");
    video = search.videos[0];
    result = await getMp3Link(video.videoId);
  } catch (err) {
    console.error("[Play Error - Search/Link]:", err);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    return m.reply("❌ ما لقيتش الأغنية أو فشل التحويل.");
  }

  // === مرحلة 2: إرسال الصورة والبيانات ===
  const durationText = result.duration
    ? formatDuration(result.duration)
    : video.timestamp || "غير معروف";

  const caption =
    `╭───(   🎵 𝐉𝐎𝐘 𝐁𝐎𝐘 𝐌𝐔𝐒𝐈𝐂   )───\n` +
    `├ 📌 *العنوان:* ${result.title || video.title}\n` +
    `├ ⏱️ *المدة:* ${durationText}\n` +
    `├ 👁️ *المشاهدات:* ${video.views ? video.views.toLocaleString() : "?"}\n` +
    `├ 📤 *القناة:* ${video.author?.name || "غير معروف"}\n` +
    `├ 🔗 *الرابط:* ${video.url}\n` +
    `╰────────────────────☉\n\n` +
    `⏳ جاري إرسال الأغنية...`;

  try {
    await conn.sendMessage(
      m.chat,
      { image: { url: video.image || video.thumbnail }, caption },
      { quoted: m }
    );
  } catch (err) {
    console.error("[Play Error - Image]:", err);
    // كمل حتى لو الصورة فشلات
  }

  // === مرحلة 3: تحميل الصوت ===
  let audioBuffer;
  try {
    console.log("[Play] بدء تحميل الصوت من:", result.link);
    const audioRes = await axios.get(result.link, {
      responseType: "arraybuffer",
      timeout: 60000,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://youtube-mp36.p.rapidapi.com/",
        "Accept": "*/*",
      },
    });
    audioBuffer = Buffer.from(audioRes.data);
    console.log("[Play] حجم الملف المحمل:", audioBuffer.length, "bytes");

    if (!audioBuffer.length) throw new Error("الملف فارغ بعد التحميل");
  } catch (err) {
    console.error("[Play Error - Download Audio]:", err.message);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    return m.reply("❌ فشل تحميل الصوت من السيرفر، يرجى المحاولة لاحقاً.");
  }

  // === مرحلة 4: إرسال الصوت (بدون بطاقة/صورة) ===
  try {
    console.log("[Play] جاري إرسال الصوت لـ:", m.chat);
    await conn.sendMessage(
      m.chat,
      {
        audio: audioBuffer,
        mimetype: "audio/mpeg",
        ptt: false,
        fileName: `${result.title || video.title}.mp3`,
      },
      { quoted: m }
    );
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    console.log("[Play] تم الإرسال بنجاح");
  } catch (err) {
    console.error("[Play Error - Send Audio]:", err);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    await m.reply("❌ فشل إرسال الصوت لواتساب، يرجى المحاولة لاحقاً.");
  }
};

handler.help = ["play"];
handler.command = ["اغنيه", "فيديو", "اغنية", "play", "video", "شغل"];
handler.tags = ["downloader"];
handler.limit = true;

export default handler;
