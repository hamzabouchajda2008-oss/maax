/* 
by: JOY BOY
*/

const example = async (m, { conn }) => {

conn.msgUrl(m.chat,
  '*🔥 Special Offer*',
  {
    img: '',
    title: '',
    body: '',
    big: true,
    mentions: ['212625654754@s.whatsapp.net']
  },
  m
)

};

example.usage = ["تست1"]


/* ↓ قسم الأمر ↓ */
example.category = "example"


/* ↓ استخدم الأوامر ↓ */
example.command = ["تست1"] 


/* ↓ بتعمل ايقاف ل الأمر ↓ */
example.disabled = false 

/* ↓ استخدام الأمر بعد ثانيه من الاستخدام لمنع الاسبام ↓ */
example.cooldown = 1000; 


/* ↓ استخدام الأمر ب بدايه أو لا ↓ */
example.usePrefix = false; 

export default example;
