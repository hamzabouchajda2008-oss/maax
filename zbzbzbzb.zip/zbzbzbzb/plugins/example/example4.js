const example = async (m, { conn }) => {

await conn.sendCarousel(m.chat, {
  headerText: '📸 Image Gallery',
  globalFooterText: 'Swipe to see more →',
  cards: [
    {
      imageUrl: 'https://g.top4top.io/p_3700yob0b1.jpg',
      bodyText: '*Anime Girl 1*',
      footerText: '🌸 Cute anime style',
      buttons: [
        { name: 'quick_reply', params: { display_text: '👍 Like', id: 'like1' } }
      ]
    },
    {
      imageUrl: 'https://h.top4top.io/p_37009f24s1.jpg',
      bodyText: '*Anime Girl 2*',
      footerText: '✨ Beautiful character',
      buttons: [
        { name: 'quick_reply', params: { display_text: '❤️ Love', id: 'love2' } },
        { name: 'cta_copy', params: { display_text: '📋 Copy Code', copy_code: 'IMG2_CODE' } }
      ]
    },
    {
      mediaUrl: 'https://qu.ax/x/6GwxA.mp4',
      mediaType: 'video',
      bodyText: 'Intro Video',
      buttons: [
        { name: 'quick_reply', params: { display_text: '▶️ View Details', id: 'video_details' } }
      ]
    },
    {
      imageUrl: 'https://i.top4top.io/p_37000qovy1.jpg',
      bodyText: '*Anime Girl 3*',
      footerText: '🎨 Amazing artwork',
      buttons: [
        { 
          name: 'single_select', 
          params: { 
            title: '📁 More Options',
            sections: [{
              title: 'Choose action',
              rows: [
                { title: 'Save to gallery', id: 'save3' },
                { title: 'Share with friend', id: 'share3' },
                { title: 'Report image', id: 'report3' }
              ]
            }]
          } 
        }
      ]
    }
  ],
  mentions: [m.sender]
}, m);

};

example.usage = ["تست4"];
example.category = "example";
example.command = ["تست4"];
export default example;
