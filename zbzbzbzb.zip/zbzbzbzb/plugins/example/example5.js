const example = async (m, { conn }) => {

return await conn.sendButtonNormal(m.chat, {
  media: { url: 'https://qu.ax/x/6GwxA.mp4' },
  mediaType: 'video', // or image
  caption: `hi, @${m.sender.split("@")[0]}`,
  buttons: [
    // 1. Quick Reply
    { name: "quick_reply", params: { display_text: "👍 Quick Reply", id: "quick1" } },
    { name: "quick_reply", params: { display_text: "👎 Another Reply", id: "quick2" } },
    
    // 2. Call Button
    { name: "cta_call", params: { display_text: "📞 Call Support", phone_number: "212625654754" } },
    
    // 3. Copy Button
    { name: "cta_copy", params: { display_text: "📋 Copy Code", copy_code: "ABC123XYZ" } },
    
    // 4. Single Select Menu
    { name: "single_select", params: { 
      title: "📋 Choose Option",
      sections: [{
        title: "Menu",
        rows: [
          { title: "Option 1", description: "Description 1", id: "opt1" },
          { title: "Option 2", description: "Description 2", id: "opt2" }
        ]
      }]
    }},
    
    // 5. Call Permission Request
    { name: "call_permission_request", params: { 
      display_text: "📞 Request Call",
      phone_number: "212625654754",
      duration: 60
    }}
  ], 
  mentions: [m.sender]
}, m);

};

example.usage = ["تست5"];
example.category = "example";
example.command = ["تست5"];

export default example;
