import { createCanvas } from 'canvas';

if (!global.redBallGames) global.redBallGames = {};

// رسم شاشة اللعبة التفاعلية
function renderGameScreen(playerX, playerY, lives, score) {
    const canvas = createCanvas(350, 180);
    const ctx = canvas.getContext('2d');

    // خلفية اللعبة
    ctx.fillStyle = '#1e1f29';
    ctx.fillRect(0, 0, 350, 180);

    // أرضية اللعبة والعوائق
    ctx.fillStyle = '#34374c';
    ctx.fillRect(0, 140, 350, 40);

    // العقبات والمنصات
    ctx.fillStyle = '#575b7a';
    ctx.fillRect(100, 110, 45, 30);
    ctx.fillRect(210, 85, 45, 55);

    // هدف النهاية (الباب الذهبي)
    ctx.fillStyle = '#f1c40f';
    ctx.fillRect(300, 95, 25, 45);

    // الكرة الحمراء (اللاعب)
    ctx.fillStyle = '#e74c3c';
    ctx.beginPath();
    ctx.arc(playerX, playerY, 11, 0, Math.PI * 2);
    ctx.fill();

    // تفاصيل الوجه على الكرة
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(playerX + 3, playerY - 3, 3, 0, Math.PI * 2);
    ctx.fill();

    // عداد القلوب والنقاط
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 12px Arial';
    ctx.fillText(`LIVES: ${'❤️'.repeat(lives)}   |   SCORE: ${score}`, 15, 25);

    return canvas.toBuffer('image/png');
}

const handler = async (m, { conn, command }) => {
    const sender = m.sender;
    let session = global.redBallGames[sender];

    // بدء اللعبة
    if (command === 'كورة' || command === 'ball') {
        global.redBallGames[sender] = { x: 30, y: 129, lives: 3, score: 0 };
        session = global.redBallGames[sender];
    } else {
        if (!session) return m.reply("❌ اكتب *.كورة* لبدء اللعبة أولاً!");
    }

    // تحديث مكان الكرة عند ضغط الأزرار
    if (command === 'كرة_يمين' || command === 'ball_right') session.x += 35;
    if (command === 'كرة_يسار' || command === 'ball_left') session.x -= 35;
    if (command === 'كرة_قفز' || command === 'ball_jump') {
        session.y -= 30;
        session.x += 25;
    }

    // الحدود والجاذبية
    if (session.x > 300) session.x = 300; // الوصول للباب
    if (session.x < 20) session.x = 20;
    if (session.y < 129) session.y = 129; // العودة للأرضية

    const buffer = renderGameScreen(session.x, session.y, session.lives, session.score);

    // إرسال الواجهة مع الأزرار
    await conn.sendButton(m.chat, {
        imageUrl: buffer,
        bodyText: `🔴 *HIURA PLATFORMER*\n🎯 *المستوى 1* - تحرك للوصول إلى الباب!`,
        footerText: "𝐉𝐎𝐘 𝐁𝐎𝐘 𝐆𝐀𝐌𝐄𝐒 🎪",
        buttons: [
            { name: "quick_reply", params: { display_text: "⬅️", id: ".كرة_يسار" } },
            { name: "quick_reply", params: { display_text: "⬆️", id: ".كرة_قفز" } },
            { name: "quick_reply", params: { display_text: "➡️", id: ".كرة_يمين" } }
        ]
    }, m);
};

handler.command = ['كورة', 'ball', 'كرة_يمين', 'كرة_يسار', 'كرة_قفز', 'ball_right', 'ball_left', 'ball_jump'];
handler.category = 'games';

export default handler;
