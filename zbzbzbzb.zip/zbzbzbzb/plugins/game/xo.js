let handler = async (m, { conn, command }) => {
	const html = `<style>
*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;box-sizing:border-box}
@keyframes pop{0%{transform:scale(.6);opacity:0}100%{transform:scale(1);opacity:1}}
@keyframes shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-6px)}40%{transform:translateX(6px)}60%{transform:translateX(-4px)}80%{transform:translateX(4px)}}
.pop{animation:pop .28s cubic-bezier(.34,1.56,.64,1)}
.shake{animation:shake .4s}
.lvlBtn{transition:transform .12s}
.lvlBtn:active{transform:scale(.92)}
button{font-family:Arial,sans-serif}
</style>
<body style="margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee;touch-action:manipulation;cursor:pointer">
<div style="width:100%;max-width:560px;margin:auto;padding:14px;box-sizing:border-box">
<div style="background:rgba(255,255,255,.06);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.15);border-radius:20px;overflow:hidden;box-shadow:0 10px 40px rgba(0,0,0,.4)">

<div style="padding:16px 20px;border-bottom:1px solid rgba(255,255,255,.12);display:flex;justify-content:space-between;align-items:center">
<div>
<div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,.45)">NIXEL LEGEND</div>
<div style="font-size:22px;font-weight:bold;color:#fff;display:flex;align-items:center;gap:6px">XO Legend <span style="font-size:14px">👑</span></div>
</div>
<div style="display:flex;align-items:center;gap:10px">
<div style="text-align:left">
<div id="pointsDisplay" style="font-size:15px;font-weight:bold;color:#ffd76a;text-shadow:0 0 10px rgba(255,215,106,.6)">0 ⭐</div>
<div id="streakDisplay" style="font-size:10px;color:rgba(255,255,255,.45)">سلسلة: 0 🔥</div>
</div>
<button id="soundBtn" style="width:34px;height:34px;border-radius:10px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#eee;font-size:15px">🔊</button>
</div>
</div>

<div id="screenHome" style="display:block;padding:22px">
<div style="text-align:center;font-size:13px;color:rgba(255,255,255,.55);margin-bottom:18px">اختار الوضع وابدا التحدي ضد الذكاء الاصطناعي</div>

<button id="campaignBtn" style="width:100%;padding:16px 18px;border-radius:14px;border:1px solid rgba(108,92,231,.5);background:linear-gradient(135deg,rgba(108,92,231,.35),rgba(162,92,231,.2));color:#fff;font-size:16px;font-weight:bold;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
<span>🏆 وضع الحملة</span><span id="campaignProgress" style="font-size:11px;color:rgba(255,255,255,.6);font-weight:normal">0 / 10</span>
</button>
<button id="freeplayBtn" style="width:100%;padding:16px 18px;border-radius:14px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#eee;font-size:16px;font-weight:bold;margin-bottom:18px;display:flex;justify-content:space-between;align-items:center">
<span>⚡ لعب حر</span><span style="font-size:11px;color:rgba(255,255,255,.4);font-weight:normal">اختار الصعوبة</span>
</button>

<div style="display:flex;gap:8px;margin-bottom:16px">
<div style="flex:1;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:10px;text-align:center">
<div id="statWins" style="font-size:18px;font-weight:bold;color:#5aff8f">0</div>
<div style="font-size:10px;color:rgba(255,255,255,.4)">فوز</div>
</div>
<div style="flex:1;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:10px;text-align:center">
<div id="statDraws" style="font-size:18px;font-weight:bold;color:#ffd76a">0</div>
<div style="font-size:10px;color:rgba(255,255,255,.4)">تعادل</div>
</div>
<div style="flex:1;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:10px;text-align:center">
<div id="statLoss" style="font-size:18px;font-weight:bold;color:#ff7a7a">0</div>
<div style="font-size:10px;color:rgba(255,255,255,.4)">خسارة</div>
</div>
</div>

<div style="font-size:11px;color:rgba(255,255,255,.4);margin-bottom:8px">الإنجازات</div>
<div id="achRow" style="display:flex;gap:8px;flex-wrap:wrap"></div>
</div>

<div id="screenCampaign" style="display:none;padding:20px">
<div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
<button class="backBtn" style="width:34px;height:34px;border-radius:10px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#eee">←</button>
<div style="font-size:16px;font-weight:bold">اختار المستوى</div>
</div>
<div id="levelGrid" style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px"></div>
</div>

<div id="screenDiff" style="display:none;padding:20px">
<div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
<button class="backBtn" style="width:34px;height:34px;border-radius:10px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#eee">←</button>
<div style="font-size:16px;font-weight:bold">اختار الصعوبة</div>
</div>
<button class="diffPick" data-d="easy" style="width:100%;text-align:right;padding:14px 18px;border-radius:12px;border:1px solid rgba(90,255,143,.35);background:rgba(90,255,143,.1);color:#fff;font-size:15px;font-weight:bold;margin-bottom:10px">🟢 سهل<div style="font-size:11px;font-weight:normal;color:rgba(255,255,255,.5);margin-top:3px">مناسب للمبتدئين</div></button>
<button class="diffPick" data-d="medium" style="width:100%;text-align:right;padding:14px 18px;border-radius:12px;border:1px solid rgba(255,215,106,.35);background:rgba(255,215,106,.1);color:#fff;font-size:15px;font-weight:bold;margin-bottom:10px">🟡 متوسط<div style="font-size:11px;font-weight:normal;color:rgba(255,255,255,.5);margin-top:3px">تحدي متوازن</div></button>
<button class="diffPick" data-d="hard" style="width:100%;text-align:right;padding:14px 18px;border-radius:12px;border:1px solid rgba(255,122,122,.35);background:rgba(255,122,122,.1);color:#fff;font-size:15px;font-weight:bold;margin-bottom:10px">🔴 صعب<div style="font-size:11px;font-weight:normal;color:rgba(255,255,255,.5);margin-top:3px">AI كيلعب بذكاء عالي</div></button>
<button class="diffPick" data-d="legendary" style="width:100%;text-align:right;padding:14px 18px;border-radius:12px;border:1px solid rgba(255,255,255,.4);background:linear-gradient(135deg,rgba(108,92,231,.3),rgba(255,122,162,.2));color:#fff;font-size:15px;font-weight:bold">👑 أسطوري<div style="font-size:11px;font-weight:normal;color:rgba(255,255,255,.6);margin-top:3px">مستحيل تربح، غير تعادل إلا لعبتي مزيان</div></button>
</div>

<div id="screenGame" style="display:none;padding:16px">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
<button id="menuBtn" style="width:34px;height:34px;border-radius:10px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#eee">☰</button>
<div id="modeLabel" style="font-size:13px;color:rgba(255,255,255,.6);text-align:center;flex:1">-</div>
<div style="width:34px"></div>
</div>
<div id="canvasWrap" style="position:relative">
<canvas id="game" width="480" height="480" style="width:100%;height:auto;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.12);border-radius:16px;display:block"></canvas>
<div id="overlay" style="display:none;position:absolute;top:0;left:0;right:0;bottom:0;border-radius:16px;background:rgba(10,10,18,.75);flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:20px">
<div id="overlayIcon" style="font-size:44px;margin-bottom:6px">🎉</div>
<div id="overlayTitle" style="font-size:22px;font-weight:bold;color:#fff;margin-bottom:6px">ربحتي!</div>
<div id="overlayStars" style="font-size:24px;letter-spacing:4px;margin-bottom:6px"></div>
<div id="overlayPoints" style="font-size:14px;color:#ffd76a;margin-bottom:16px">+0 نقطة</div>
<div style="display:flex;gap:10px">
<button id="retryBtn" style="padding:10px 20px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#eee;font-size:13px">إعادة</button>
<button id="nextBtn" style="padding:10px 20px;border-radius:10px;border:1px solid rgba(108,92,231,.5);background:rgba(108,92,231,.3);color:#fff;font-size:13px;display:none">التالي ⭢</button>
<button id="homeBtn2" style="padding:10px 20px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#eee;font-size:13px">القائمة</button>
</div>
</div>
</div>
<div id="status" style="text-align:center;margin-top:12px;font-size:13px;color:rgba(255,255,255,.6);min-height:18px"></div>
</div>

</div></div>
<script>
(function(){
'use strict';

/* ================= PERSISTENCE ================= */
const SAVE_KEY='xo_legend_save_v2';
function defaultSave(){
return{
points:0,streak:0,bestStreak:0,soundOn:true,
stats:{wins:0,draws:0,losses:0},
campaign:{unlocked:1,stars:{}},
freeplay:{easy:{w:0,l:0,d:0},medium:{w:0,l:0,d:0},hard:{w:0,l:0,d:0},legendary:{w:0,l:0,d:0}},
achievements:{}
};
}
function loadSave(){
let raw=null;
try{raw=localStorage.getItem(SAVE_KEY);}catch(e){}
if(!raw){
try{
const mtch=document.cookie.match(/(?:^|;\\s*)xo_legend_v2=([^;]+)/);
if(mtch)raw=decodeURIComponent(mtch[1]);
}catch(e){}
}
const d=defaultSave();
if(!raw)return d;
try{
const parsed=JSON.parse(raw);
d.points=typeof parsed.points==='number'?parsed.points:0;
d.streak=typeof parsed.streak==='number'?parsed.streak:0;
d.bestStreak=typeof parsed.bestStreak==='number'?parsed.bestStreak:0;
d.soundOn=parsed.soundOn!==false;
if(parsed.stats)Object.assign(d.stats,parsed.stats);
if(parsed.campaign){
if(typeof parsed.campaign.unlocked==='number')d.campaign.unlocked=parsed.campaign.unlocked;
if(parsed.campaign.stars)Object.assign(d.campaign.stars,parsed.campaign.stars);
}
if(parsed.freeplay){
['easy','medium','hard','legendary'].forEach(k=>{if(parsed.freeplay[k])Object.assign(d.freeplay[k],parsed.freeplay[k]);});
}
if(parsed.achievements)Object.assign(d.achievements,parsed.achievements);
return d;
}catch(e){return d;}
}
function persist(){
try{
const str=JSON.stringify(save);
try{localStorage.setItem(SAVE_KEY,str);}catch(e){}
try{document.cookie='xo_legend_v2='+encodeURIComponent(str)+';max-age=31536000;path=/';}catch(e){}
}catch(e){}
}
const save=loadSave();

/* ================= SOUND (offline WebAudio) ================= */
let actx=null;
function ensureAudio(){
if(actx)return;
try{actx=new (window.AudioContext||window.webkitAudioContext)();}catch(e){actx=null;}
}
function tone(freq,dur,type,vol){
if(!save.soundOn||!actx)return;
try{
const o=actx.createOscillator(),g=actx.createGain();
o.type=type||'sine';o.frequency.value=freq;
g.gain.value=(vol!=null?vol:.08);
o.connect(g);g.connect(actx.destination);
o.start();
g.gain.exponentialRampToValueAtTime(.0001,actx.currentTime+dur);
o.stop(actx.currentTime+dur);
}catch(e){}
}
function sfxMove(sym){tone(sym==='X'?520:380,.12,'sine',.07);}
function sfxWin(){tone(660,.15,'triangle',.09);setTimeout(function(){tone(880,.2,'triangle',.09);},120);setTimeout(function(){tone(1100,.28,'triangle',.09);},260);}
function sfxLose(){tone(220,.3,'sawtooth',.06);setTimeout(function(){tone(160,.35,'sawtooth',.06);},150);}
function sfxDraw(){tone(340,.2,'sine',.06);}
function sfxClick(){tone(700,.05,'square',.04);}

/* ================= DOM REFS ================= */
const screenHome=document.getElementById('screenHome');
const screenCampaign=document.getElementById('screenCampaign');
const screenDiff=document.getElementById('screenDiff');
const screenGame=document.getElementById('screenGame');
const screens={home:screenHome,campaign:screenCampaign,diff:screenDiff,game:screenGame};

const pointsDisplay=document.getElementById('pointsDisplay');
const streakDisplay=document.getElementById('streakDisplay');
const soundBtn=document.getElementById('soundBtn');
const statWins=document.getElementById('statWins');
const statDraws=document.getElementById('statDraws');
const statLoss=document.getElementById('statLoss');
const campaignProgress=document.getElementById('campaignProgress');
const achRow=document.getElementById('achRow');
const levelGrid=document.getElementById('levelGrid');
const modeLabel=document.getElementById('modeLabel');
const statusEl=document.getElementById('status');
const canvasWrap=document.getElementById('canvasWrap');
const overlay=document.getElementById('overlay');
const overlayIcon=document.getElementById('overlayIcon');
const overlayTitle=document.getElementById('overlayTitle');
const overlayStars=document.getElementById('overlayStars');
const overlayPoints=document.getElementById('overlayPoints');
const retryBtn=document.getElementById('retryBtn');
const nextBtn=document.getElementById('nextBtn');
const homeBtn2=document.getElementById('homeBtn2');
const menuBtn=document.getElementById('menuBtn');
const c=document.getElementById('game');
const x=c.getContext('2d');
const CELL=c.width/3;

const ACH_LIST=[
{id:'first_win',icon:'🥇',name:'أول فوز'},
{id:'streak_5',icon:'🔥',name:'سلسلة 5'},
{id:'legend_slayer',icon:'👑',name:'قاتل الأسطوري'},
{id:'campaign_master',icon:'🏆',name:'سيد الحملة'},
{id:'flawless',icon:'💎',name:'فوز مثالي'}
];

/* ================= GAME STATE (initialized safely from the start) ================= */
let mode='freeplay';
let level=null;
let diff='easy';
let board=Array(9).fill(null);
let turn='X';
let over=false;
let winLine=null;
let gameMoves=0;
let particles=[];
let thinking=false;
let rafRunning=false;

/* ================= PURE GAME LOGIC ================= */
const LINES=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
function checkWin(b){
for(let li=0;li<LINES.length;li++){
const L=LINES[li],a=L[0],b1=L[1],c1=L[2];
if(b[a]&&b[a]===b[b1]&&b[a]===b[c1])return{winner:b[a],line:L};
}
if(b.every(function(v){return !!v;}))return{winner:'draw',line:null};
return null;
}
function emptyCells(b){const r=[];for(let i=0;i<9;i++)if(!b[i])r.push(i);return r;}
function minimax(b,depth,isMax,alpha,beta){
const res=checkWin(b);
if(res){
if(res.winner==='O')return 10-depth;
if(res.winner==='X')return depth-10;
return 0;
}
if(isMax){
let best=-Infinity;
const cells=emptyCells(b);
for(let i=0;i<cells.length;i++){
const idx=cells[i];
b[idx]='O';
const s=minimax(b,depth+1,false,alpha,beta);
b[idx]=null;
if(s>best)best=s;
if(best>alpha)alpha=best;
if(beta<=alpha)break;
}
return best;
}else{
let best=Infinity;
const cells=emptyCells(b);
for(let i=0;i<cells.length;i++){
const idx=cells[i];
b[idx]='X';
const s=minimax(b,depth+1,true,alpha,beta);
b[idx]=null;
if(s<best)best=s;
if(best<beta)beta=best;
if(beta<=alpha)break;
}
return best;
}
}
function bestMove(b){
let bestScore=-Infinity,move=emptyCells(b)[0];
const cells=emptyCells(b);
for(let i=0;i<cells.length;i++){
const idx=cells[i];
b[idx]='O';
const s=minimax(b,0,false,-Infinity,Infinity);
b[idx]=null;
if(s>bestScore){bestScore=s;move=idx;}
}
return move;
}
function randomMove(b){const e=emptyCells(b);return e[Math.floor(Math.random()*e.length)];}
function findWinningMove(b,sym){
const cells=emptyCells(b);
for(let i=0;i<cells.length;i++){
const idx=cells[i];
b[idx]=sym;
const r=checkWin(b);
b[idx]=null;
if(r&&r.winner===sym)return idx;
}
return null;
}
function smartRandomMove(b){
const win=findWinningMove(b,'O');
if(win!==null)return win;
const block=findWinningMove(b,'X');
if(block!==null)return block;
if(!b[4])return 4;
return randomMove(b);
}
function optimalChance(){
if(mode==='campaign')return Math.min(1,0.1+level*0.09);
const table={easy:.3,medium:.6,hard:.92,legendary:1};
return table[diff]!==undefined?table[diff]:.5;
}

/* ================= UI HELPERS ================= */
function showScreen(name){
Object.keys(screens).forEach(function(k){screens[k].style.display=(k===name)?'block':'none';});
if(name==='home')refreshHome();
if(name==='campaign')buildLevelGrid();
}
function refreshHome(){
pointsDisplay.textContent=save.points+' ⭐';
streakDisplay.textContent='سلسلة: '+save.streak+' 🔥';
statWins.textContent=save.stats.wins;
statDraws.textContent=save.stats.draws;
statLoss.textContent=save.stats.losses;
let completed=0;
for(let i=1;i<=10;i++)if((save.campaign.stars[i]||0)>0)completed++;
campaignProgress.textContent=completed+' / 10';
achRow.innerHTML='';
ACH_LIST.forEach(function(a){
const unlocked=!!save.achievements[a.id];
const el=document.createElement('div');
el.style.cssText='width:52px;height:52px;border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:18px;border:1px solid '+(unlocked?'rgba(255,215,106,.5)':'rgba(255,255,255,.1)')+';background:'+(unlocked?'rgba(255,215,106,.12)':'rgba(255,255,255,.03)')+';opacity:'+(unlocked?'1':'.35');
el.innerHTML='<div>'+a.icon+'</div><div style="font-size:8px;margin-top:2px;color:rgba(255,255,255,.6)">'+a.name+'</div>';
achRow.appendChild(el);
});
soundBtn.textContent=save.soundOn?'🔊':'🔇';
}
function buildLevelGrid(){
levelGrid.innerHTML='';
for(let i=1;i<=10;i++){
const unlocked=i<=save.campaign.unlocked;
const stars=save.campaign.stars[i]||0;
const btn=document.createElement('button');
btn.className='lvlBtn';
btn.style.cssText='height:66px;border-radius:12px;border:1px solid '+(unlocked?'rgba(108,92,231,.5)':'rgba(255,255,255,.08)')+';background:'+(unlocked?'rgba(108,92,231,.18)':'rgba(255,255,255,.03)')+';color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;opacity:'+(unlocked?'1':'.4');
if(unlocked){
btn.innerHTML='<div style="font-size:17px;font-weight:bold">'+i+'</div><div style="font-size:9px;color:#ffd76a">'+('★'.repeat(stars)+'☆'.repeat(3-stars))+'</div>';
(function(lvl){
btn.addEventListener('click',function(){sfxClick();startGame('campaign',lvl,null);});
})(i);
}else{
btn.innerHTML='<div style="font-size:16px">🔒</div>';
}
levelGrid.appendChild(btn);
}
}

/* ================= GAME FLOW ================= */
function startGame(m,lvl,d){
mode=m;level=lvl;diff=d;
board=Array(9).fill(null);
turn='X';over=false;winLine=null;gameMoves=0;particles=[];thinking=false;
overlay.style.display='none';
modeLabel.textContent=(mode==='campaign')?('الحملة - المستوى '+level):('لعب حر - '+({easy:'سهل',medium:'متوسط',hard:'صعب',legendary:'أسطوري'})[diff]);
statusEl.textContent='دورك (X)';
showScreen('game');
drawBoard();
}
function burst(px,py,n,col){
for(let i=0;i<n;i++){
particles.push({x:px,y:py,vx:(Math.random()-.5)*6,vy:-Math.random()*6,life:1,col:col,size:2+Math.random()*3});
}
}
function finishTurn(){
const res=checkWin(board);
if(res){
over=true;winLine=res.line;
drawBoard();
setTimeout(function(){endGame(res.winner);},350);
return;
}
turn=(turn==='X')?'O':'X';
statusEl.textContent=(turn==='X')?'دورك (X)':'كيفكر AI...';
drawBoard();
if(turn==='O'){
thinking=true;
setTimeout(function(){
try{aiThink();}catch(e){thinking=false;}
},380+Math.random()*280);
}
}
function aiThink(){
const chance=optimalChance();
let move;
const b2=board.slice();
if(Math.random()<chance){
move=bestMove(b2);
}else{
move=(Math.random()<.5)?smartRandomMove(board):randomMove(board);
}
if(move===undefined||move===null||board[move]){
const e=emptyCells(board);
if(e.length===0){thinking=false;return;}
move=e[0];
}
board[move]='O';
gameMoves++;
sfxMove('O');
thinking=false;
finishTurn();
}
function endGame(winner){
let starsEarned=0,pointsEarned=0;
const achUnlockedNames=[];
function unlockAch(id,name){
if(!save.achievements[id]){save.achievements[id]=true;achUnlockedNames.push(name);}
}
if(winner==='draw'){
save.stats.draws++;save.streak=0;
sfxDraw();
if(mode==='campaign'){
starsEarned=1;
pointsEarned=40*level;
if(level>=save.campaign.unlocked&&level<10)save.campaign.unlocked=level+1;
if((save.campaign.stars[level]||0)<starsEarned)save.campaign.stars[level]=starsEarned;
}else{
pointsEarned=15;
save.freeplay[diff].d++;
}
overlayIcon.textContent='🤝';overlayTitle.textContent='تعادل';
}else if(winner==='X'){
save.stats.wins++;save.streak++;
if(save.streak>save.bestStreak)save.bestStreak=save.streak;
sfxWin();
unlockAch('first_win','أول فوز');
if(save.streak>=5)unlockAch('streak_5','سلسلة 5');
if(mode==='freeplay'&&diff==='legendary')unlockAch('legend_slayer','قاتل الأسطوري');
if(gameMoves<=3)unlockAch('flawless','فوز مثالي');
if(mode==='campaign'){
starsEarned=(gameMoves<=3)?3:((gameMoves<=4)?2:1);
pointsEarned=100*level+starsEarned*25;
if(level>=save.campaign.unlocked&&level<10)save.campaign.unlocked=level+1;
if((save.campaign.stars[level]||0)<starsEarned)save.campaign.stars[level]=starsEarned;
if(level===10)unlockAch('campaign_master','سيد الحملة');
}else{
const mult={easy:1,medium:1.5,hard:2,legendary:3}[diff];
pointsEarned=Math.round((50+Math.min(save.streak,10)*8)*mult);
save.freeplay[diff].w++;
}
overlayIcon.textContent='🎉';overlayTitle.textContent='ربحتي!';
}else{
save.stats.losses++;save.streak=0;
sfxLose();
canvasWrap.classList.add('shake');
setTimeout(function(){canvasWrap.classList.remove('shake');},420);
if(mode==='freeplay')save.freeplay[diff].l++;
overlayIcon.textContent='😅';overlayTitle.textContent='خسرتي';
pointsEarned=0;
}
save.points+=pointsEarned;
persist();
overlayStars.textContent=(mode==='campaign')?('★'.repeat(starsEarned)+'☆'.repeat(3-starsEarned)):'';
let ptsText=(pointsEarned>0?'+':'')+pointsEarned+' نقطة';
if(achUnlockedNames.length)ptsText+=' | إنجاز جديد: '+achUnlockedNames.join('، ');
overlayPoints.textContent=ptsText;
const canGoNext=(mode==='campaign')&&(winner==='X'||winner==='draw')&&(level<10);
nextBtn.style.display=canGoNext?'inline-block':'none';
overlay.style.display='flex';
overlay.classList.remove('pop');
void overlay.offsetWidth;
overlay.classList.add('pop');
pointsDisplay.textContent=save.points+' ⭐';
streakDisplay.textContent='سلسلة: '+save.streak+' 🔥';
}

/* ================= DRAWING ================= */
function drawX(cx,cy,s){
x.save();
x.strokeStyle='#6c5ce7';x.lineWidth=12;x.lineCap='round';
x.shadowColor='rgba(108,92,231,.65)';x.shadowBlur=14;
x.beginPath();x.moveTo(cx-s,cy-s);x.lineTo(cx+s,cy+s);x.stroke();
x.beginPath();x.moveTo(cx+s,cy-s);x.lineTo(cx-s,cy+s);x.stroke();
x.restore();
}
function drawO(cx,cy,s){
x.save();
x.strokeStyle='#ff7aa2';x.lineWidth=12;
x.shadowColor='rgba(255,122,162,.65)';x.shadowBlur=14;
x.beginPath();x.arc(cx,cy,s,0,Math.PI*2);x.stroke();
x.restore();
}
function drawBoard(){
x.clearRect(0,0,c.width,c.height);
x.strokeStyle='rgba(255,255,255,.18)';x.lineWidth=3;
for(let i=1;i<3;i++){
x.beginPath();x.moveTo(i*CELL,14);x.lineTo(i*CELL,c.height-14);x.stroke();
x.beginPath();x.moveTo(14,i*CELL);x.lineTo(c.width-14,i*CELL);x.stroke();
}
for(let i=0;i<9;i++){
if(!board[i])continue;
const col=i%3,row=Math.floor(i/3);
const cx=col*CELL+CELL/2,cy=row*CELL+CELL/2,s=CELL*.27;
if(board[i]==='X')drawX(cx,cy,s);else drawO(cx,cy,s);
}
if(winLine){
const pt=function(i){return{x:(i%3)*CELL+CELL/2,y:Math.floor(i/3)*CELL+CELL/2};};
const p1=pt(winLine[0]),p2=pt(winLine[2]);
x.save();
x.strokeStyle='rgba(255,255,255,.9)';x.lineWidth=7;x.lineCap='round';
x.shadowColor='rgba(255,255,255,.6)';x.shadowBlur=12;
x.beginPath();x.moveTo(p1.x,p1.y);x.lineTo(p2.x,p2.y);x.stroke();
x.restore();
}
for(let i=0;i<particles.length;i++){
const p=particles[i];
x.fillStyle='rgba('+p.col+','+Math.max(p.life,0)+')';
x.fillRect(p.x,p.y,p.size,p.size);
}
}
function animate(){
if(particles.length){
for(let i=0;i<particles.length;i++){
const p=particles[i];
p.x+=p.vx;p.y+=p.vy;p.vy+=.25;p.life-=.025;
}
particles=particles.filter(function(p){return p.life>0;});
drawBoard();
}
requestAnimationFrame(animate);
}

/* ================= INPUT ================= */
function cellAt(px,py){
const col=Math.floor(px/CELL),row=Math.floor(py/CELL);
if(col<0||col>2||row<0||row>2)return -1;
return row*3+col;
}
function handleCellTap(clientX,clientY){
if(over||turn!=='X'||thinking)return;
ensureAudio();
const rect=c.getBoundingClientRect();
const px=(clientX-rect.left)*(c.width/rect.width);
const py=(clientY-rect.top)*(c.height/rect.height);
const i=cellAt(px,py);
if(i<0||board[i])return;
board[i]='X';
gameMoves++;
sfxMove('X');
const col=i%3,row=Math.floor(i/3);
burst(col*CELL+CELL/2,row*CELL+CELL/2,8,'108,92,231');
finishTurn();
}

/* ================= EVENT BINDINGS (all attached immediately, unconditionally) ================= */
c.addEventListener('pointerdown',function(e){
try{handleCellTap(e.clientX,e.clientY);}catch(err){}
});
document.querySelectorAll('.backBtn').forEach(function(b){
b.addEventListener('click',function(){sfxClick();showScreen('home');});
});
document.getElementById('campaignBtn').addEventListener('click',function(){ensureAudio();sfxClick();showScreen('campaign');});
document.getElementById('freeplayBtn').addEventListener('click',function(){ensureAudio();sfxClick();showScreen('diff');});
document.querySelectorAll('.diffPick').forEach(function(b){
b.addEventListener('click',function(){sfxClick();startGame('freeplay',null,b.getAttribute('data-d'));});
});
soundBtn.addEventListener('click',function(){
save.soundOn=!save.soundOn;
persist();
soundBtn.textContent=save.soundOn?'🔊':'🔇';
ensureAudio();
if(save.soundOn)sfxClick();
});
menuBtn.addEventListener('click',function(){showScreen('home');});
homeBtn2.addEventListener('click',function(){overlay.style.display='none';showScreen('home');});
retryBtn.addEventListener('click',function(){sfxClick();startGame(mode,level,diff);});
nextBtn.addEventListener('click',function(){sfxClick();if(mode==='campaign'&&level<10)startGame('campaign',level+1,null);});

/* ================= BOOT ================= */
drawBoard();
if(!rafRunning){rafRunning=true;requestAnimationFrame(animate);}
showScreen('home');

})();
</script></body>`;

const item = {
  __typename: "GenAIaeacdsnwHtmlPrimitive",
  payload: html,
  trusted_sources: ["nixel.dev"]
}

await new AIRich(conn)
.addSection(AIRich.newLayout('Single', item))
.send(m.chat, { bypassDownload: false })
};

handler.help = handler.command = ["xolegend", "xoai"];
handler.tags = ['owner'];
handler.owner = true;

export default handler;
