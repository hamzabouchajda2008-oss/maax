// ==========================================================
//  NET v4: مركز خدمات (حسابات + روابط متنوعة)، كله بالأزرار والقوائم
//  الأمر: .jjk  (أو .ggk)  ← يفتح القائمة، وكل شيء بعدها بالضغط
//  المالك يشوف زر "🛠 لوحة الإدارة" في القائمة
// ==========================================================
import fs from 'fs';
import path from 'path';

const DEFAULT_SITE = "crunchyroll";
const PAGE = 7;            // عدد العناصر في كل صفحة قائمة
const PENDING_MS = 120000; // مهلة انتظار الإدخال من المالك

/* ---------------- التخزين (ملف مستقل، ما يتأثر بقاعدة البوت) ---------------- */
const DATA_DIR = path.join(process.cwd(), 'net-data');
const DATA_FILE = path.join(DATA_DIR, 'net.json');
function readData() {
  for (const f of [DATA_FILE, DATA_FILE + '.bak']) {
    try { if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { console.error('[NET] read failed', f, e.message); }
  }
  return null;
}
function flush() {
  if (!global.netData) return;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(DATA_FILE)) { try { fs.copyFileSync(DATA_FILE, DATA_FILE + '.bak'); } catch {} }
    const tmp = DATA_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(global.netData));
    fs.renameSync(tmp, DATA_FILE);
  } catch (e) { console.error('[NET] save failed', e.message); }
}
let saveTimer = null;
const save = () => { clearTimeout(saveTimer); saveTimer = setTimeout(flush, 400); };
if (!global.netHooks) {
  global.netHooks = true;
  process.on('exit', () => { try { flush(); } catch {} });
  for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { try { flush(); } catch {} process.exit(0); });
}

/* ---------------- البيانات ---------------- */
const getDB = () => {
  if (!global.netData) {
    // أول تشغيل: نقرأ الملف، وإذا ما وجد نستورد القديم من قاعدة البوت (إن وجد)
    global.netData = readData() || (global.db?.net && typeof global.db.net === 'object' ? JSON.parse(JSON.stringify(global.db.net)) : {});
  }
  const d = global.netData;
  d.admins ||= []; d.casts ||= []; d.links ||= []; d.accs ||= []; d.users ||= {}; d.log ||= []; d.lowAt ||= {};
  d.nl ||= 1; d.na ||= 1; d.nu ||= 1;
  for (const u of Object.values(d.users)) if (!u.uid) u.uid = d.nu++;   // رقم ثابت لكل مستخدم (للأزرار)
  d.cfg ||= {};
  d.cfg.site ||= DEFAULT_SITE; d.cfg.cooldown ??= 8; d.cfg.daily ??= 30; d.cfg.autoOff ??= 3; d.cfg.low ??= 3; d.cfg.priceLink ??= 5; d.cfg.priceAcc ??= 5; d.cfg.refReward ??= 10; d.cfg.welcome ??= 3;
  d.grants ||= {};
  // الخدمات: كل رابط/حساب ينتمي لخدمة. العناصر القديمة تنتقل لخدمة افتراضية تلقائياً
  d.services ||= []; d.ns ||= 1;
  const has = id => d.services.some(s => s.id === id);
  const defSvc = type => {
    let s = d.services.find(x => x.type === type && x.def);
    if (!s) { s = { id: 'S' + d.ns++, name: type === 'acc' ? d.cfg.site : '🔗 روابط', type, off: false, def: true }; d.services.push(s); }
    return s;
  };
  for (const x of d.links) if (!has(x.svc)) x.svc = defSvc('link').id;
  for (const x of d.accs) if (!has(x.svc)) x.svc = defSvc('acc').id;
  return d;
};
global.netPending ||= {};
global.netDraft ||= {};
const CAST_MIN = 3000, CAST_JIT = 3000, CAST_MAX = 500;
const sleep = ms => new Promise(r => setTimeout(r, ms));

const today = () => new Date().toISOString().slice(0, 10);
const alive = x => !x.off && (!x.exp || x.exp > Date.now());
const isUrl = u => /^https?:\/\/[^\s<>"']{4,500}$/.test(u);
const clean = u => String(u || '').trim().replace(/[)\].,;،]+$/, '');
const cut = (s, n) => { s = String(s ?? ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const num = s => String(s).split('@')[0].replace(/\D/g, '');
const addLog = (db, who, txt) => { db.log.push({ t: Date.now(), w: num(who), x: txt }); if (db.log.length > 50) db.log.shift(); };
const status = x => (x.off ? '⛔ معطّل' : x.exp && x.exp < Date.now() ? '⌛ منتهي' : '✅ فعّال');
const expTxt = x => (x.exp ? new Date(x.exp).toISOString().slice(0, 10) : 'بدون انتهاء');
const allItems = db => [...db.links, ...db.accs];
const findItem = (db, id) => allItems(db).find(x => x.id === String(id).toUpperCase());
const findSvc = (db, id) => db.services.find(s => s.id === String(id).toUpperCase());
const itemsOf = (db, s) => (s.type === 'acc' ? db.accs : db.links).filter(x => x.svc === s.id);
const availOf = (db, s) => itemsOf(db, s).filter(alive).length;
const totalAvail = (db, type) => db.services.filter(s => s.type === type && !s.off).reduce((n, s) => n + availOf(db, s), 0);
const svcIcon = s => (s.type === 'acc' ? '🔐' : '🔗');
const clampPage = (p, total) => Math.min(Math.max(0, Number(p) || 0), Math.max(0, Math.ceil(total / PAGE) - 1));

// تحديد المالك: الأمر المكتوب يتحقق منه الفريمورك (m.isOwner) فنسجّل معرّفاته،
// وضغطات الأزرار (اللي ما يمر عليها فحص الفريمورك) نتعرف عليه من المعرّفات المسجلة
const idsOf = m => [...new Set([m.sender, m.key?.participant, m.participant, m.lid, !m.isGroup ? m.chat : null].filter(x => typeof x === 'string' && x))];
function checkOwner(m, bot, db) {
  const mine = idsOf(m);
  if (m.isOwner) {
    for (const i of mine) if (!db.admins.includes(i)) db.admins.push(i);
    if (db.admins.length > 20) db.admins.splice(0, db.admins.length - 20);
    return true;
  }
  if (bot?.config?.owners?.some(o => mine.some(i => i === o.jid || i === o.lid))) return true;
  return mine.some(i => db.admins.includes(i));
}

// اسم المستخدم ورقمه الحقيقي (للعرض في لوحة الإدارة)
async function rememberUser(m, user) {
  if (m.pushName) user.name = cut(String(m.pushName), 30);
  if (user.phone) return;
  const okJid = x => typeof x === 'string' && /@s\.whatsapp\.net$/.test(x);
  let cand = [m.sender, m.key?.participantAlt, m.key?.remoteJidAlt, m.key?.senderPn, m.senderPn].find(okJid);
  if (!cand && /@lid$/.test(String(m.sender)) && typeof m.lid2jid === 'function') {
    try { const r = await Promise.race([m.lid2jid(m.sender), new Promise(res => setTimeout(() => res(null), 1500))]); if (okJid(r)) cand = r; } catch {}
  }
  if (cand) user.phone = num(cand);
}

function wpick(pool) {
  const w = pool.map(x => 1 / ((1 + x.uses) * (1 + x.reports)));
  let r = Math.random() * w.reduce((a, b) => a + b, 0);
  for (let i = 0; i < pool.length; i++) { r -= w[i]; if (r <= 0) return pool[i]; }
  return pool[pool.length - 1];
}
function pick(arr, user, key) {
  const ok = arr.filter(alive);
  if (!ok.length) return null;
  user[key] ||= [];
  let pool = ok.filter(x => !user[key].includes(x.id));
  if (!pool.length) { user[key] = []; pool = ok; }
  const item = wpick(pool);
  user[key].push(item.id);
  return { item, rem: pool.length - 1 };
}

/* ---------------- اللغات (عربي / English) ---------------- */
const I18N = {
  ar: {
    menu_body: '*مركز الروابط والحسابات*\n⊱⋅ ──────────── ⋅⊰\n🔗 روابط متاحة: *{links}*\n🔐 حسابات متاحة: *{accs}*\n{rank} • المستوى *{lvl}*\n💰 نقاطك: *{pts}*\n🔔 التنبيهات: *{sub}*',
    menu_foot: 'كل شيء بالضغط، ما تحتاج تكتب أوامر',
    on: 'مفعّلة', off: 'متوقفة',
    b_link: '🔗 احصل على رابط', b_acc: '🔐 احصل على حساب', b_profile: '👤 ملفي', b_more: '☰ المزيد', sec_more: 'المزيد',
    r_daily: '🎁 مكافأة يومية', r_daily_d: 'نقاط وXP كل يوم',
    r_shop: '🛒 المتجر', r_shop_d: 'استبدل نقاطك',
    r_report: '🚩 بلّغ عن مشكلة', r_report_d: 'إذا ما اشتغل شيء',
    r_sub_on: '🔔 اشترك بالتنبيهات', r_sub_off: '🔕 إلغاء التنبيهات', r_sub_d: 'إعلانات الروابط الجديدة',
    r_lang: '🌐 اللغة', r_lang_d: 'العربية / English',
    r_help: '📖 المساعدة', r_help_d: 'طريقة الاستخدام',
    r_admin: '🛠 لوحة الإدارة', r_admin_d: 'للمالك فقط',
    b_menu: '🏠 القائمة',
    link_title: '🔗 رابطك جاهز',
    link_body: '{url}\n\n📦 باقي لك: *{rem}* جديد\n✨ +{xp} XP\n\n_📋 انسخ الرابط وافتحه في كروم، أو اضغط فتح مباشر_',
    link_foot: 'ما اشتغل؟ اضغط بلّغ ثم آخر',
    b_copy: '📋 نسخ الرابط', b_open: '🚀 فتح مباشر', b_next_link: '🔄 رابط آخر', b_bad: '🚩 ما اشتغل',
    acc_title: '🔐 بيانات الدخول',
    acc_body: '👤 اليوزر:\n```{user}```\n🔑 كلمة السر:\n```{pass}```\n\n🌐 الموقع: *{site}*\n📦 باقي لك: *{rem}* جديد\n✨ +{xp} XP',
    b_copy_u: '📋 نسخ اليوزر', b_copy_p: '📋 نسخ كلمة السر', b_next_acc: '🔄 حساب آخر',
    wait: '*⏳ استنى {s} ثانية وجرّب*',
    limit: '*⛔ وصلت حدك اليومي ({n})*\nجرّب بكرة، أو ارفع مستواك، أو اشترِ طلبات من المتجر 🛒',
    no_links: '*❌ لا توجد روابط متاحة الآن*', no_accs: '*❌ لا توجد حسابات متاحة الآن*',
    banned: '*🚫 أنت محظور من استخدام هذا النظام*',
    rep_none: '*ما عندك شيء تبلّغ عنه بعد.*\nاطلب رابط أو حساب أولاً.',
    rep_dup: '*✅ بلّغت عنه من قبل، شكراً لك*',
    rep_ok: '*✅ وصل بلاغك، شكراً*{extra}\nاضغط الزر تاخذ بديل.{bonus}',
    auto_off: '\n🔧 تم تعطيله تلقائياً',
    b_new_link: '🔄 رابط جديد', b_new_acc: '🔄 حساب جديد',
    sub_on: '*🔔 تم تفعيل التنبيهات*\nراح توصلك رسالة لما تنزل روابط جديدة.',
    sub_off: '*🔕 تم إيقاف التنبيهات*\nما راح توصلك رسائل إعلانية.',
    help_title: '📖 المساعدة',
    help_body: '*طريقة الاستخدام*\n⊱⋅ ──────────── ⋅⊰\n1️⃣ اضغط *احصل على رابط*\n2️⃣ اضغط *نسخ* وافتح *كروم* والصق في شريط العنوان، أو اضغط *فتح مباشر*\n3️⃣ ما اشتغل؟ اضغط *بلّغ* ثم *آخر*\n\n*🏅 المستويات والنقاط*\n• كل استخدام يعطيك XP ويرفع مستواك\n• المستوى الأعلى = انتظار أقل وحد يومي أكبر\n• استلم *مكافأة يومية* كل يوم وزد سلسلتك 🔥\n• استبدل نقاطك في *المتجر* 🛒',
    b_profile_btn: '👤 ملفي',
    prof_title: '👤 ملفي',
    prof_body: '*{name}*\n⊱⋅ ──────────── ⋅⊰\n{rank} • المستوى *{lvl}*\n{bar} {pct}%\n✨ XP: *{xp}* ({need} للمستوى التالي)\n💰 النقاط: *{pts}*\n🔥 الأيام المتتالية: *{streak}*\n📊 مرات الاستخدام: *{total}*\n\n*🎖 مزايا مستواك*\n⏱ الانتظار بين الطلبات: {cd} ث\n📅 الحد اليومي: {lim}',
    daily_ok: '*🎁 مكافأتك اليومية*\n💰 +{pts} نقطة\n✨ +{xp} XP\n🔥 أيام متتالية: *{streak}*\n\n_ارجع بكرة تكمل السلسلة وتزيد المكافأة._',
    daily_done: '*✅ استلمت مكافأة اليوم*\nارجع بكرة 🌙',
    shop_title: '🛒 المتجر',
    shop_body: '*المتجر*\n⊱⋅ ──────────── ⋅⊰\n💰 نقاطك: *{pts}*\n\n⚡ *طلبات إضافية*\n+{n} طلب لليوم بسعر {cost} نقاط\n(عندك اليوم +{extra} إضافية)',
    b_buy: '⚡ +{n} طلبات ({cost})',
    buy_ok: '*✅ تم الشراء*\nأضفنا +{n} طلب لليوم.\n💰 المتبقي: {pts}',
    buy_no: '*❌ نقاطك ما تكفي*\nتحتاج {need} نقطة إضافية.\nاجمعها من المكافأة اليومية والاستخدام.',
    lang_title: '🌐 اللغة / Language',
    lang_body: '*اختر لغتك*\n*Choose your language*',
    lang_set: '*✅ تم اختيار العربية*',
    lvl_up: '*🎉 ارتقيت للمستوى {lvl}!*\n{rank}\n💰 +{bonus} نقاط هدية\n⏱ انتظارك الآن {cd} ث • 📅 حدك {lim}',
    bc_title: '📢 إعلان', bc_head: '*📢 إعلان جديد*', bc_foot: 'وصلتك لأنك مشترك بالتنبيهات',
    ranks: ['مبتدئ', 'نشيط', 'محترف', 'خبير', 'أسطورة']
  },
  en: {
    menu_body: '*Links & Accounts Hub*\n⊱⋅ ──────────── ⋅⊰\n🔗 Links available: *{links}*\n🔐 Accounts available: *{accs}*\n{rank} • Level *{lvl}*\n💰 Your points: *{pts}*\n🔔 Alerts: *{sub}*',
    menu_foot: 'Everything is one tap away, no commands needed',
    on: 'ON', off: 'OFF',
    b_link: '🔗 Get a link', b_acc: '🔐 Get an account', b_profile: '👤 Profile', b_more: '☰ More', sec_more: 'More',
    r_daily: '🎁 Daily reward', r_daily_d: 'Points and XP every day',
    r_shop: '🛒 Shop', r_shop_d: 'Spend your points',
    r_report: '🚩 Report a problem', r_report_d: 'If something fails',
    r_sub_on: '🔔 Turn on alerts', r_sub_off: '🔕 Turn off alerts', r_sub_d: 'New links announcements',
    r_lang: '🌐 Language', r_lang_d: 'العربية / English',
    r_help: '📖 Help', r_help_d: 'How it works',
    r_admin: '🛠 Admin panel', r_admin_d: 'Owner only',
    b_menu: '🏠 Menu',
    link_title: '🔗 Your link is ready',
    link_body: '{url}\n\n📦 You have *{rem}* more new\n✨ +{xp} XP\n\n_📋 Copy the link and open it in Chrome, or tap Open now_',
    link_foot: 'Not working? Tap Report, then Next',
    b_copy: '📋 Copy link', b_open: '🚀 Open now', b_next_link: '🔄 Next link', b_bad: '🚩 Not working',
    acc_title: '🔐 Login details',
    acc_body: '👤 Username:\n```{user}```\n🔑 Password:\n```{pass}```\n\n🌐 Site: *{site}*\n📦 You have *{rem}* more new\n✨ +{xp} XP',
    b_copy_u: '📋 Copy username', b_copy_p: '📋 Copy password', b_next_acc: '🔄 Next account',
    wait: '*⏳ Wait {s}s and try again*',
    limit: '*⛔ Daily limit reached ({n})*\nTry tomorrow, level up, or buy extra requests in the shop 🛒',
    no_links: '*❌ No links available right now*', no_accs: '*❌ No accounts available right now*',
    banned: '*🚫 You are banned from this system*',
    rep_none: '*You have nothing to report yet.*\nGet a link or an account first.',
    rep_dup: '*✅ You already reported it, thanks*',
    rep_ok: '*✅ Report received, thank you*{extra}\nTap the button to get a replacement.{bonus}',
    auto_off: '\n🔧 It was disabled automatically',
    b_new_link: '🔄 New link', b_new_acc: '🔄 New account',
    sub_on: '*🔔 Alerts enabled*\nYou will get a message when new links drop.',
    sub_off: '*🔕 Alerts disabled*\nYou will not receive announcements.',
    help_title: '📖 Help',
    help_body: '*How to use*\n⊱⋅ ──────────── ⋅⊰\n1️⃣ Tap *Get a link*\n2️⃣ Tap *Copy*, open *Chrome* and paste into the address bar, or tap *Open now*\n3️⃣ Not working? Tap *Report* then *Next*\n\n*🏅 Levels & points*\n• Every use gives XP and raises your level\n• Higher level = shorter wait and bigger daily limit\n• Claim the *daily reward* and grow your streak 🔥\n• Spend points in the *shop* 🛒',
    b_profile_btn: '👤 Profile',
    prof_title: '👤 My profile',
    prof_body: '*{name}*\n⊱⋅ ──────────── ⋅⊰\n{rank} • Level *{lvl}*\n{bar} {pct}%\n✨ XP: *{xp}* ({need} to next level)\n💰 Points: *{pts}*\n🔥 Day streak: *{streak}*\n📊 Total uses: *{total}*\n\n*🎖 Your level perks*\n⏱ Wait between requests: {cd}s\n📅 Daily limit: {lim}',
    daily_ok: '*🎁 Your daily reward*\n💰 +{pts} points\n✨ +{xp} XP\n🔥 Day streak: *{streak}*\n\n_Come back tomorrow to keep the streak and earn more._',
    daily_done: '*✅ Today\'s reward already claimed*\nSee you tomorrow 🌙',
    shop_title: '🛒 Shop',
    shop_body: '*Shop*\n⊱⋅ ──────────── ⋅⊰\n💰 Your points: *{pts}*\n\n⚡ *Extra requests*\n+{n} requests for today, {cost} points\n(You have +{extra} extra today)',
    b_buy: '⚡ +{n} requests ({cost})',
    buy_ok: '*✅ Purchased*\nAdded +{n} requests for today.\n💰 Left: {pts}',
    buy_no: '*❌ Not enough points*\nYou need {need} more.\nEarn them from the daily reward and by using the bot.',
    lang_title: '🌐 اللغة / Language',
    lang_body: '*اختر لغتك*\n*Choose your language*',
    lang_set: '*✅ English selected*',
    lvl_up: '*🎉 You reached level {lvl}!*\n{rank}\n💰 +{bonus} bonus points\n⏱ Your wait is now {cd}s • 📅 limit {lim}',
    bc_title: '📢 Announcement', bc_head: '*📢 New announcement*', bc_foot: 'You received this because you subscribed to alerts',
    ranks: ['Newbie', 'Active', 'Pro', 'Expert', 'Legend']
  }
};
Object.assign(I18N.ar, {
  b_link_p: '🔗 رابط ({p} نقاط)', b_acc_p: '🔐 حساب ({p} نقاط)',
  b_next_link: '🔄 رابط آخر ({p})', b_next_acc: '🔄 حساب آخر ({p})',
  r_missions: '🎯 المهمات', r_missions_d: 'اكسب نقاط بمهام بسيطة',
  r_invite: '👥 ادعُ أصدقاءك', r_invite_d: 'نقاط على كل صديق',
  link_body: '{url}\n\n💰 -{cost} • رصيدك: *{bal}*\n📦 باقي لك: *{rem}* جديد\n✨ +{xp} XP\n\n_📋 انسخ الرابط وافتحه في كروم، أو اضغط فتح مباشر_',
  acc_body: '👤 اليوزر:\n```{user}```\n🔑 كلمة السر:\n```{pass}```\n\n🌐 الموقع: *{site}*\n💰 -{cost} • رصيدك: *{bal}*\n📦 باقي لك: *{rem}* جديد\n✨ +{xp} XP',
  nopts_title: '💰 نقاطك ما تكفي',
  nopts: '*رصيدك: {pts} نقطة*\nالسعر: *{p}* • تحتاج *{need}* نقطة إضافية\n\n*كيف تكسب نقاط؟*\n🎁 المكافأة اليومية\n🎯 مهمات بسيطة\n👥 دعوة أصدقاء',
  refund: '*💰 تم استرجاع {p} نقاط*\nالرابط أو الحساب اللي بلّغت عنه تعطّل، وأرجعنا لك نقاطك.',
  help_body: '*طريقة الاستخدام*\n⊱⋅ ──────────── ⋅⊰\n1️⃣ اكسب نقاط: 🎁 المكافأة اليومية، 🎯 المهمات، 👥 دعوة الأصدقاء\n2️⃣ اشترِ *رابط* أو *حساب* بنقاطك\n3️⃣ انسخه وافتح *كروم* والصق في شريط العنوان، أو اضغط *فتح مباشر*\n4️⃣ ما اشتغل؟ اضغط *بلّغ*، وإذا تعطّل تسترجع نقاطك تلقائياً\n\n*🏅 المستويات*\n• كل استخدام يعطيك XP\n• المستوى الأعلى = انتظار أقل وحد يومي أكبر',
  shop_body: '*المتجر*\n⊱⋅ ──────────── ⋅⊰\n💰 نقاطك: *{pts}*\n\n🔗 رابط: *{pl}* نقاط\n🔐 حساب: *{pa}* نقاط\n⚡ +{n} طلبات إضافية لليوم: *{cost}* نقاط\n(عندك اليوم +{extra} إضافية)',
  mis_title: '🎯 المهمات',
  mis_body: '*مهمات اليوم* (تتجدد كل يوم)\n{daily}\n\n*مهمات لمرة واحدة*\n{once}\n\n_تكتمل تلقائياً وتوصلك النقاط مباشرة._',
  mis_done: '*🎯 أنجزت مهمة!*\n{t}\n💰 +{pts} نقاط • ✨ +{xp} XP',
  invite_title: '👥 دعوة الأصدقاء',
  invite_body: '*ادعُ أصدقاءك واكسب نقاط*\n⊱⋅ ──────────── ⋅⊰\n🔑 كودك: *{code}*\n👥 دعواتك الناجحة: *{n}*\n\n🎁 تاخذ *{p}* نقاط عن كل صديق يستلم أول مكافأة يومية له\n🎁 وصديقك ياخذ *{w}* نقاط هدية ترحيب\n\nاضغط *نسخ الدعوة* وأرسلها لأصدقائك.',
  invite_msg: 'جرّب هذا البوت، فيه روابط وحسابات مميزة 👇\n{link}',
  invite_msg_nolink: 'جرّب هذا البوت واكتب له:\n.jjk ref {code}',
  b_copy_invite: '📋 نسخ الدعوة',
  ref_ok: '*🎉 أهلاً بك!*\nجاءتك هدية ترحيب *{w}* نقاط.\nاستلم مكافأتك اليومية عشان صديقك ياخذ مكافأته.',
  ref_bad: '*ℹ️ كود الدعوة غير صالح أو مستخدم من قبل*',
  ref_paid: '*🎉 صديقك استلم أول مكافأة*\n💰 +{p} نقاط لك\n👥 مجموع دعواتك: {n}',
  grant_in: '*🎁 حصلت على {p} نقطة من الإدارة*\n💰 رصيدك الآن: {bal}',
  grant_out: '*ℹ️ تم خصم {p} نقطة من رصيدك*\n💰 رصيدك الآن: {bal}',
  daily_ok: '*🎁 مكافأتك اليومية*\n💰 +{pts} نقاط\n✨ +{xp} XP\n🔥 أيام متتالية: *{streak}*\n\n_ارجع بكرة تكمل السلسلة وتزيد المكافأة._',
  b_buy_extra: '⚡ +{n} طلبات ({cost})',
});
Object.assign(I18N.en, {
  b_link_p: '🔗 Link ({p} pts)', b_acc_p: '🔐 Account ({p} pts)',
  b_next_link: '🔄 Next link ({p})', b_next_acc: '🔄 Next account ({p})',
  r_missions: '🎯 Missions', r_missions_d: 'Earn points with easy tasks',
  r_invite: '👥 Invite friends', r_invite_d: 'Points for every friend',
  link_body: '{url}\n\n💰 -{cost} • Balance: *{bal}*\n📦 You have *{rem}* more new\n✨ +{xp} XP\n\n_📋 Copy the link and open it in Chrome, or tap Open now_',
  acc_body: '👤 Username:\n```{user}```\n🔑 Password:\n```{pass}```\n\n🌐 Site: *{site}*\n💰 -{cost} • Balance: *{bal}*\n📦 You have *{rem}* more new\n✨ +{xp} XP',
  nopts_title: '💰 Not enough points',
  nopts: '*Balance: {pts} points*\nPrice: *{p}* • you need *{need}* more\n\n*How to earn points?*\n🎁 Daily reward\n🎯 Easy missions\n👥 Invite friends',
  refund: '*💰 {p} points refunded*\nThe link or account you reported was disabled, so we returned your points.',
  help_body: '*How to use*\n⊱⋅ ──────────── ⋅⊰\n1️⃣ Earn points: 🎁 daily reward, 🎯 missions, 👥 invite friends\n2️⃣ Buy a *link* or an *account* with your points\n3️⃣ Copy it, open *Chrome* and paste into the address bar, or tap *Open now*\n4️⃣ Not working? Tap *Report*. If it gets disabled you are refunded automatically\n\n*🏅 Levels*\n• Every use gives XP\n• Higher level = shorter wait and bigger daily limit',
  shop_body: '*Shop*\n⊱⋅ ──────────── ⋅⊰\n💰 Your points: *{pts}*\n\n🔗 Link: *{pl}* points\n🔐 Account: *{pa}* points\n⚡ +{n} extra requests today: *{cost}* points\n(You have +{extra} extra today)',
  mis_title: '🎯 Missions',
  mis_body: '*Today\'s missions* (reset daily)\n{daily}\n\n*One-time missions*\n{once}\n\n_They complete automatically and points arrive instantly._',
  mis_done: '*🎯 Mission complete!*\n{t}\n💰 +{pts} points • ✨ +{xp} XP',
  invite_title: '👥 Invite friends',
  invite_body: '*Invite friends and earn points*\n⊱⋅ ──────────── ⋅⊰\n🔑 Your code: *{code}*\n👥 Successful invites: *{n}*\n\n🎁 You get *{p}* points for each friend who claims their first daily reward\n🎁 Your friend gets *{w}* welcome points\n\nTap *Copy invite* and send it to your friends.',
  invite_msg: 'Try this bot, it has great links and accounts 👇\n{link}',
  invite_msg_nolink: 'Try this bot and send it:\n.jjk ref {code}',
  b_copy_invite: '📋 Copy invite',
  ref_ok: '*🎉 Welcome!*\nYou got *{w}* welcome points.\nClaim your daily reward so your friend gets theirs.',
  ref_bad: '*ℹ️ Invite code is invalid or already used*',
  ref_paid: '*🎉 Your friend claimed their first reward*\n💰 +{p} points for you\n👥 Total invites: {n}',
  grant_in: '*🎁 You received {p} points from the admins*\n💰 Balance: {bal}',
  grant_out: '*ℹ️ {p} points were deducted*\n💰 Balance: {bal}',
  daily_ok: '*🎁 Your daily reward*\n💰 +{pts} points\n✨ +{xp} XP\n🔥 Day streak: *{streak}*\n\n_Come back tomorrow to keep the streak and earn more._',
  b_buy_extra: '⚡ +{n} requests ({cost})',
});
// نصوص نظام الخدمات (جديدة)
Object.assign(I18N.ar, {
  b_services: '🗂 الخدمات', b_again: '🔄 التالي',
  svc_title: '🗂 الخدمات', svc_list: '📂 اختر خدمة',
  svc_body: '*اختر الخدمة اللي تبغاها*\n⊱⋅ ──────────── ⋅⊰\n🔐 خدمات الحسابات: *{a}*\n🔗 خدمات الروابط: *{l}*\nالصفحة {p} من {t}\n\n_اضغط على القائمة واختر_',
  sec_acc: '🔐 الحسابات', sec_link: '🔗 الروابط', sec_nav: 'تنقّل',
  svc_avail: '✅ {n} متاح', svc_out: '⛔ نفد المخزون',
  svc_none: '*لا توجد خدمات متاحة الآن*\nارجع لاحقاً 🙏',
  svc_out_msg: '*⛔ نفد المخزون في {name}*\nجرّب خدمة ثانية أو ارجع لاحقاً.',
  svc_prev: '⬅️ السابق', svc_next: '➡️ التالي', svc_page: 'صفحة {p}',
});
Object.assign(I18N.en, {
  b_services: '🗂 Services', b_again: '🔄 Next',
  svc_title: '🗂 Services', svc_list: '📂 Pick a service',
  svc_body: '*Pick the service you want*\n⊱⋅ ──────────── ⋅⊰\n🔐 Account services: *{a}*\n🔗 Link services: *{l}*\nPage {p} of {t}\n\n_Open the list and choose_',
  sec_acc: '🔐 Accounts', sec_link: '🔗 Links', sec_nav: 'Navigate',
  svc_avail: '✅ {n} available', svc_out: '⛔ Out of stock',
  svc_none: '*No services available right now*\nPlease come back later 🙏',
  svc_out_msg: '*⛔ {name} is out of stock*\nTry another service or come back later.',
  svc_prev: '⬅️ Previous', svc_next: '➡️ Next', svc_page: 'Page {p}',
});
const T = (u, k, v = {}) => {
  const lang = u?.lang === 'en' ? 'en' : 'ar';
  const s = I18N[lang][k] ?? I18N.ar[k] ?? k;
  return typeof s === 'string' ? s.replace(/\{(\w+)\}/g, (m, key) => (key in v ? String(v[key]) : m)) : s;
};
const tr = (c, k, v) => T(c.user, k, v);
const bm = c => ['r', tr(c, 'b_menu'), 'net:menu'];

/* ---------------- المستويات والنقاط ---------------- */
const XP_USE = 5, XP_REPORT = 3, PTS_REPORT = 1, REPORT_REWARDS_PER_DAY = 3;
const DAILY_XP = 10, SHOP = { cost: 10, n: 5 };
const RANK_FROM = [1, 3, 5, 8, 12];          // المستوى الذي تبدأ عنده كل رتبة
const RANK_ICON = ['🌱', '🔰', '⭐', '💎', '👑'];
const lvlOf = xp => Math.floor(Math.sqrt(Math.max(0, xp || 0) / 25)) + 1;
const xpFor = lvl => 25 * (lvl - 1) ** 2;
const rankIdx = lvl => { let i = 0; RANK_FROM.forEach((r, k) => { if (lvl >= r) i = k; }); return i; };
const rankOf = (lvl, lang) => `${RANK_ICON[rankIdx(lvl)]} ${I18N[lang === 'en' ? 'en' : 'ar'].ranks[rankIdx(lvl)]}`;
const bar = p => { const n = Math.round(Math.max(0, Math.min(100, p)) / 10); return '▰'.repeat(n) + '▱'.repeat(10 - n); };
const cooldownFor = (db, lvl) => Math.max(2, db.cfg.cooldown - Math.floor(lvl / 2));
const extraToday = u => (u.extraDay === today() ? u.extra || 0 : 0);
const dailyFor = (db, u) => (db.cfg.daily ? db.cfg.daily + (lvlOf(u.xp) - 1) * 2 + extraToday(u) : 0);
function gain(c, xp, pts = 0) {
  const u = c.user, before = lvlOf(u.xp);
  u.xp = (u.xp || 0) + xp; u.pts = (u.pts || 0) + pts;
  const after = lvlOf(u.xp);
  if (after > before) { c.lvlUp = after; u.pts += 5 * (after - before); }
}
async function announceLevel(c) {
  if (!c.lvlUp) return;
  const l = c.lvlUp; c.lvlUp = 0;
  const lim = dailyFor(c.db, c.user);
  await c.conn.sendMessage(c.m.chat, { text: tr(c, 'lvl_up', { lvl: l, rank: rankOf(l, c.user.lang), bonus: 5, cd: cooldownFor(c.db, l), lim: lim || '∞' }) });
}

const priceOf = (db, tab) => (tab === 'link' ? db.cfg.priceLink : db.cfg.priceAcc);
const codeOf = k => (Number(num(k)) || 0).toString(36);
const botNum = conn => String(conn?.user?.id || '').split(':')[0].split('@')[0].replace(/\D/g, '');

/* ---------------- المهمات ---------------- */
const MISSIONS = [
  { id: 'd_claim', daily: true, ev: 'daily', goal: 1, pts: 1, xp: 5, ar: '🎁 استلم المكافأة اليومية', en: '🎁 Claim the daily reward' },
  { id: 'd_profile', daily: true, ev: 'profile', goal: 1, pts: 1, xp: 3, ar: '👤 افتح ملفك الشخصي', en: '👤 Open your profile' },
  { id: 'd_report', daily: true, ev: 'report', goal: 1, pts: 2, xp: 5, ar: '🚩 بلّغ عن مشكلة', en: '🚩 Report a problem' },
  { id: 'o_sub', ev: 'sub', goal: 1, pts: 3, xp: 10, ar: '🔔 فعّل التنبيهات', en: '🔔 Turn on alerts' },
  { id: 'o_buy5', ev: 'buy', goal: 5, pts: 5, xp: 20, ar: '🛒 اشترِ 5 عناصر', en: '🛒 Buy 5 items' },
  { id: 'o_s3', ev: 'streak', goal: 3, pts: 5, xp: 15, ar: '🔥 سلسلة 3 أيام', en: '🔥 3-day streak' },
  { id: 'o_s7', ev: 'streak', goal: 7, pts: 15, xp: 40, ar: '🔥 سلسلة 7 أيام', en: '🔥 7-day streak' },
  { id: 'o_inv3', ev: 'invite', goal: 3, pts: 10, xp: 30, ar: '👥 ادعُ 3 أصدقاء', en: '👥 Invite 3 friends' },
];
function misState(u) {
  u.misO ||= { p: {}, done: {} };
  if (!u.misD || u.misD.day !== today()) u.misD = { day: today(), p: {}, done: {} };
}
async function mission(c, ev, n = 1, abs = false) {
  const u = c.user; misState(u);
  const finished = [];
  for (const ms of MISSIONS.filter(x => x.ev === ev)) {
    const st = ms.daily ? u.misD : u.misO;
    if (st.done[ms.id]) continue;
    st.p[ms.id] = abs ? n : (st.p[ms.id] || 0) + n;
    if (st.p[ms.id] >= ms.goal) { st.done[ms.id] = true; st.p[ms.id] = ms.goal; gain(c, ms.xp, ms.pts); finished.push(ms); }
  }
  const lang = u.lang === 'en' ? 'en' : 'ar';
  for (const ms of finished) { try { await c.conn.sendMessage(c.m.chat, { text: tr(c, 'mis_done', { t: ms[lang], pts: ms.pts, xp: ms.xp }) }); } catch {} }
  if (finished.length) await announceLevel(c);
}

async function payReferral(c) {
  const { db, conn, user } = c;
  if (!user.refBy || user.refPaid) return;
  user.refPaid = true;
  const inv = db.users[user.refBy];
  if (!inv || (inv.invited || 0) >= 100) return;
  inv.invited = (inv.invited || 0) + 1;
  inv.pts = (inv.pts || 0) + db.cfg.refReward;
  const ic = { db, conn, bot: c.bot, user: inv, m: { chat: inv.dm || user.refBy } };
  try {
    await conn.sendMessage(ic.m.chat, { text: T(inv, 'ref_paid', { p: db.cfg.refReward, n: inv.invited }) });
    await mission(ic, 'invite', 1);
  } catch {}
}

async function giveTo(c, key, amt) {
  const u = c.db.users[key]; if (!u) return false;
  u.pts = Math.max(0, (u.pts || 0) + amt);
  try { await c.conn.sendMessage(u.dm || key, { text: T(u, amt >= 0 ? 'grant_in' : 'grant_out', { p: Math.abs(amt), bal: u.pts }) }); } catch {}
  return true;
}
const usersByNumber = (db, d) => Object.keys(db.users).filter(k => num(k) === d || db.users[k].phone === d);

/* ---------------- بناء الواجهة ---------------- */
// spec: { title, body, footer, list:{title, sections:[{title, rows:[[title, desc, id]]}]}, btns:[['r'|'c'|'u', text, value]] }
async function ui(conn, jid, spec) {
  const b = new Button(conn).setBody(spec.body || ' ');
  if (spec.title) b.setTitle(spec.title);
  if (spec.footer) b.setFooter(spec.footer);
  if (spec.list) {
    b.addSelection(spec.list.title || 'القائمة');
    for (const s of spec.list.sections) {
      b.makeSection(cut(s.title, 24));
      for (const r of s.rows) b.makeRow('', cut(r[0], 24), cut(r[1] || '', 72), r[2]);
    }
  }
  for (const [t, text, v] of spec.btns || []) {
    if (t === 'r') b.addReply(cut(text, 24), v);
    else if (t === 'c') b.addCopy(cut(text, 24), v);
    else if (t === 'u') b.addUrl(cut(text, 24), v);
  }
  return b.send(jid);
}

/* ---------------- شاشات المستخدم ---------------- */
const BACK_MENU = ['r', '🏠 القائمة', 'net:menu'];
const BACK_ADMIN = ['r', '🔙 الإدارة', 'net:admin'];

async function screenMenu(c) {
  const { db, conn, m, owner, user } = c;
  const lvl = lvlOf(user.xp);
  const rows = [
    [tr(c, 'r_daily'), tr(c, 'r_daily_d'), 'net:daily'],
    [tr(c, 'r_shop'), tr(c, 'r_shop_d'), 'net:shop'],
    [tr(c, 'r_report'), tr(c, 'r_report_d'), 'net:report'],
    user.sub ? [tr(c, 'r_sub_off'), tr(c, 'r_sub_d'), 'net:unsub'] : [tr(c, 'r_sub_on'), tr(c, 'r_sub_d'), 'net:sub'],
    [tr(c, 'r_lang'), tr(c, 'r_lang_d'), 'net:lang'],
    [tr(c, 'r_help'), tr(c, 'r_help_d'), 'net:help'],
  ];
  if (owner) rows.push([tr(c, 'r_admin'), tr(c, 'r_admin_d'), 'net:admin']);
  return ui(conn, m.chat, {
    title: '✦ NET ✦',
    body: tr(c, 'menu_body', { links: totalAvail(db, 'link'), accs: totalAvail(db, 'acc'), rank: rankOf(lvl, user.lang), lvl, pts: user.pts || 0, sub: tr(c, user.sub ? 'on' : 'off') }),
    footer: tr(c, 'menu_foot'),
    list: { title: tr(c, 'b_more'), sections: [{ title: tr(c, 'sec_more'), rows }] },
    btns: [['r', tr(c, 'b_services'), 'net:svc:0'], ['r', tr(c, 'b_profile'), 'net:profile'], ['r', tr(c, 'r_daily'), 'net:daily']]
  });
}

// قائمة الخدمات للمستخدم (مرتبة: الحسابات أولاً ثم الروابط، مع صفحات)
async function screenServices(c, page = 0, type = '') {
  const { db, conn, m } = c;
  const list = db.services.filter(s => !s.off && (!type || s.type === type))
    .sort((a, b) => (a.type === b.type ? 0 : a.type === 'acc' ? -1 : 1) || String(a.name).localeCompare(String(b.name), 'ar'));
  if (!list.length) return ui(conn, m.chat, { title: tr(c, 'svc_title'), body: tr(c, 'svc_none'), btns: [bm(c)] });
  const pages = Math.ceil(list.length / PAGE);
  page = clampPage(page, list.length);
  const slice = list.slice(page * PAGE, page * PAGE + PAGE);
  const sections = [];
  for (const t of ['acc', 'link']) {
    const rows = slice.filter(s => s.type === t).map(s => {
      const n = availOf(db, s);
      return [`${svcIcon(s)} ${s.name}`, n > 0 ? tr(c, 'svc_avail', { n }) : tr(c, 'svc_out'), 'net:sv:' + s.id];
    });
    if (rows.length) sections.push({ title: tr(c, t === 'acc' ? 'sec_acc' : 'sec_link'), rows });
  }
  const nav = [];
  const sfx = type ? ':' + type : '';
  if (page > 0) nav.push([tr(c, 'svc_prev'), tr(c, 'svc_page', { p: page }), `net:svc:${page - 1}${sfx}`]);
  if (page < pages - 1) nav.push([tr(c, 'svc_next'), tr(c, 'svc_page', { p: page + 2 }), `net:svc:${page + 1}${sfx}`]);
  if (nav.length) sections.push({ title: tr(c, 'sec_nav'), rows: nav });
  return ui(conn, m.chat, {
    title: tr(c, 'svc_title'),
    body: tr(c, 'svc_body', { a: list.filter(s => s.type === 'acc').length, l: list.filter(s => s.type === 'link').length, p: page + 1, t: pages }),
    list: { title: tr(c, 'svc_list'), sections },
    btns: [bm(c)]
  });
}

async function screenHelp(c) {
  return ui(c.conn, c.m.chat, {
    title: tr(c, 'help_title'),
    body: tr(c, 'help_body'),
    btns: [['r', tr(c, 'b_services'), 'net:svc:0'], ['r', tr(c, 'b_profile'), 'net:profile'], bm(c)]
  });
}

async function screenProfile(c) {
  const { db, conn, m, user } = c;
  const lvl = lvlOf(user.xp), xp = user.xp || 0;
  const base = xpFor(lvl), next = xpFor(lvl + 1);
  const pct = Math.floor(((xp - base) / (next - base)) * 100);
  const lim = dailyFor(db, user);
  return ui(conn, m.chat, {
    title: tr(c, 'prof_title'),
    body: tr(c, 'prof_body', { name: m.pushName || num(m.sender), rank: rankOf(lvl, user.lang), lvl, bar: bar(pct), pct, xp, need: next - xp, pts: user.pts || 0, streak: user.streak || 0, total: user.total || 0, cd: cooldownFor(db, lvl), lim: lim || '∞' }),
    btns: [['r', tr(c, 'r_daily'), 'net:daily'], ['r', tr(c, 'r_shop'), 'net:shop'], bm(c)]
  });
}

async function screenDaily(c) {
  const { conn, m, user } = c;
  if (user.lastDaily === today()) return ui(conn, m.chat, { body: tr(c, 'daily_done'), btns: [['r', tr(c, 'b_profile'), 'net:profile'], bm(c)] });
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  user.streak = user.lastDaily === yesterday ? (user.streak || 0) + 1 : 1;
  user.lastDaily = today();
  const pts = 5 + Math.min(user.streak, 7);
  gain(c, DAILY_XP, pts);
  await ui(conn, m.chat, { title: '🎁', body: tr(c, 'daily_ok', { pts, xp: DAILY_XP, streak: user.streak }), btns: [['r', tr(c, 'b_profile'), 'net:profile'], ['r', tr(c, 'r_shop'), 'net:shop'], bm(c)] });
  return announceLevel(c);
}

async function screenShop(c) {
  const { conn, m, user } = c;
  return ui(conn, m.chat, {
    title: tr(c, 'shop_title'),
    body: tr(c, 'shop_body', { pts: user.pts || 0, n: SHOP.n, cost: SHOP.cost, extra: extraToday(user), pl: c.db.cfg.priceLink, pa: c.db.cfg.priceAcc }),
    btns: [['r', tr(c, 'b_buy', { n: SHOP.n, cost: SHOP.cost }), 'net:buy'], ['r', tr(c, 'r_daily'), 'net:daily'], bm(c)]
  });
}

async function buyExtra(c) {
  const { conn, m, user } = c;
  if ((user.pts || 0) < SHOP.cost) return ui(conn, m.chat, { body: tr(c, 'buy_no', { need: SHOP.cost - (user.pts || 0) }), btns: [['r', tr(c, 'r_daily'), 'net:daily'], bm(c)] });
  user.pts -= SHOP.cost;
  user.extra = extraToday(user) + SHOP.n; user.extraDay = today();
  return ui(conn, m.chat, { body: tr(c, 'buy_ok', { n: SHOP.n, pts: user.pts }), btns: [['r', tr(c, 'b_services'), 'net:svc:0'], ['r', tr(c, 'r_shop'), 'net:shop'], bm(c)] });
}

async function screenLang(c) {
  return ui(c.conn, c.m.chat, {
    title: T({ lang: 'ar' }, 'lang_title'),
    body: T({ lang: 'ar' }, 'lang_body'),
    btns: [['r', '🇸🇦 العربية', 'net:lg:ar'], ['r', '🇬🇧 English', 'net:lg:en']]
  });
}

/* ---------------- شاشات الإدارة ---------------- */
async function screenAdmin(c) {
  const { db, conn, m } = c;
  const rep = allItems(db).filter(x => x.reports > 0).length;
  return ui(conn, m.chat, {
    title: '🛠 لوحة الإدارة',
    body: `*لوحة التحكم*\n⊱⋅ ──────────── ⋅⊰\n🗂 الخدمات: ${db.services.length} (🔐 ${db.services.filter(s => s.type === 'acc').length} • 🔗 ${db.services.filter(s => s.type === 'link').length})\n🔐 حسابات متاحة: ${totalAvail(db, 'acc')}/${db.accs.length}\n🔗 روابط متاحة: ${totalAvail(db, 'link')}/${db.links.length}\n🚩 عناصر عليها بلاغات: ${rep}\n👥 المستخدمون: ${Object.keys(db.users).length}`,
    footer: 'اختر قسم من القائمة',
    list: {
      title: '📂 الأقسام',
      sections: [
        { title: 'الإدارة', rows: [
          ['🗂 إدارة الخدمات', `${db.services.length} خدمة`, 'net:a:svc:0'],
          ['➕ إضافة جديد', 'حسابات أو روابط لخدمة', 'net:a:add'],
          ['🚩 البلاغات', `${rep} عنصر`, 'net:a:rep'],
        ] },
        { title: 'المتابعة', rows: [
          ['📢 رسالة إعلانية', `${Object.values(db.users).filter(u => u.sub && !u.banned).length} مشترك`, 'net:a:cast'],
          ['👥 المستخدمون', `${Object.keys(db.users).length} مستخدم`, 'net:a:users:0'],
          ['📊 الإحصائيات', 'ملخص كامل', 'net:a:stats'],
          ['⚙️ الإعدادات', 'الكولداون والحدود', 'net:a:set'],
          ['📜 السجل', 'آخر العمليات', 'net:a:log'],
          ['💾 نسخة احتياطية', 'ملف JSON (في الخاص)', 'net:a:backup'],
        ] },
      ]
    },
    btns: [BACK_MENU]
  });
}

async function screenServicesAdmin(c, page = 0) {
  const { db, conn, m } = c;
  const list = db.services.slice().sort((a, b) => (a.type === b.type ? 0 : a.type === 'acc' ? -1 : 1));
  if (!list.length) return ui(conn, m.chat, { title: '🗂 الخدمات', body: '*ما فيه خدمات بعد.*\nاضغط "➕ إضافة" وأنشئ أول خدمة (مثال: Netflix).', btns: [['r', '➕ إضافة', 'net:a:add'], BACK_ADMIN] });
  const pages = Math.ceil(list.length / PAGE);
  page = clampPage(page, list.length);
  const rows = list.slice(page * PAGE, page * PAGE + PAGE).map(s => [
    `${svcIcon(s)} ${s.name}${s.off ? ' ⛔' : ''}`,
    `${availOf(db, s)}/${itemsOf(db, s).length} متاح • 👁${itemsOf(db, s).reduce((n, x) => n + x.uses, 0)}`, 'net:a:sv:' + s.id]);
  const nav = [];
  if (page > 0) nav.push(['⬅️ السابق', `صفحة ${page}`, `net:a:svc:${page - 1}`]);
  if (page < pages - 1) nav.push(['➡️ التالي', `صفحة ${page + 2}`, `net:a:svc:${page + 1}`]);
  return ui(conn, m.chat, {
    title: '🗂 الخدمات',
    body: `*إدارة الخدمات*\nالصفحة ${page + 1} من ${pages} • المجموع ${list.length}\n_اختر خدمة لإدارتها_`,
    list: { title: '🗂 الخدمات', sections: [{ title: 'الخدمات', rows }, ...(nav.length ? [{ title: 'تنقّل', rows: nav }] : [])] },
    btns: [['r', '➕ إضافة', 'net:a:add'], BACK_ADMIN]
  });
}

async function screenServiceAdmin(c, id) {
  const { db, conn, m } = c;
  const s = findSvc(db, id);
  if (!s) return conn.sendMessage(m.chat, { text: '*❌ الخدمة غير موجودة*' });
  const items = itemsOf(db, s);
  return ui(conn, m.chat, {
    title: `${svcIcon(s)} ${cut(s.name, 20)}`,
    body: `*${s.name}*\n⊱⋅ ──────────── ⋅⊰\n📌 النوع: ${s.type === 'acc' ? '🔐 حسابات' : '🔗 روابط'}\n📌 الحالة: ${s.off ? '⛔ معطّلة' : '✅ فعّالة'}\n📦 العناصر: ${items.length} (متاح ${availOf(db, s)})\n👁 مرات الاستخدام: ${items.reduce((n, x) => n + x.uses, 0)}\n🚩 البلاغات: ${items.reduce((n, x) => n + x.reports, 0)}`,
    list: { title: '⚙️ إجراءات', sections: [{ title: 'اختر إجراء', rows: [
      ['📦 عرض العناصر', `${items.length} عنصر`, `net:a:items:${s.id}:0`],
      ['➕ إضافة عناصر', s.type === 'acc' ? 'أرسل حسابات' : 'أرسل روابط', 'net:ps:' + s.id],
      ['✏️ إعادة تسمية', 'غيّر اسم الخدمة', 'net:sn:' + s.id],
      [s.off ? '✅ تفعيل الخدمة' : '⛔ تعطيل الخدمة', s.off ? 'تظهر للمستخدمين' : 'تختفي عن المستخدمين', 'net:st:' + s.id],
      ['🗑 حذف الخدمة', 'تحذف معها كل عناصرها', 'net:sd:' + s.id],
    ] }] },
    btns: [['r', '🔙 الخدمات', 'net:a:svc:0'], BACK_ADMIN]
  });
}

async function screenItems(c, svcId, page) {
  const { db, conn, m } = c;
  const s = findSvc(db, svcId);
  if (!s) return screenServicesAdmin(c, 0);
  const arr = itemsOf(db, s);
  const pages = Math.max(1, Math.ceil(arr.length / PAGE));
  page = clampPage(page, arr.length);
  const rows = arr.slice(page * PAGE, page * PAGE + PAGE).map(x => [
    `${x.id} ${x.off ? '⛔' : x.exp && x.exp < Date.now() ? '⌛' : '✅'}`,
    `${s.type === 'acc' ? x.user : x.url} | 👁${x.uses} 🚩${x.reports}`, 'net:i:' + x.id]);
  const nav = [];
  if (page > 0) nav.push(['⬅️ السابق', `صفحة ${page}`, `net:a:items:${s.id}:${page - 1}`]);
  if (page < pages - 1) nav.push(['➡️ التالي', `صفحة ${page + 2}`, `net:a:items:${s.id}:${page + 1}`]);
  const label = `${svcIcon(s)} ${s.name}`;
  if (!arr.length) return ui(conn, m.chat, { title: cut(label, 24), body: '*لا يوجد شيء في هذه الخدمة بعد.*', btns: [['r', '➕ إضافة', 'net:ps:' + s.id], ['r', '🔙 الخدمة', 'net:a:sv:' + s.id]] });
  return ui(conn, m.chat, {
    title: cut(label, 24),
    body: `*${label}*\nالصفحة ${page + 1} من ${pages} • المجموع ${arr.length}\n\n_اختر عنصر لإدارته_`,
    list: { title: '📋 العناصر', sections: [{ title: 'العناصر', rows }, ...(nav.length ? [{ title: 'تنقّل', rows: nav }] : [])] },
    btns: [['r', '➕ إضافة', 'net:ps:' + s.id], ['r', '🔙 الخدمة', 'net:a:sv:' + s.id]]
  });
}

async function screenItem(c, id) {
  const { db, conn, m } = c;
  const it = findItem(db, id);
  if (!it) return conn.sendMessage(m.chat, { text: '*❌ العنصر غير موجود*' });
  const isL = !!it.url;
  const s = findSvc(db, it.svc);
  return ui(conn, m.chat, {
    title: `${isL ? '🔗' : '🔐'} ${it.id}`,
    body: `*${isL ? 'رابط' : 'حساب'} ${it.id}*\n⊱⋅ ──────────── ⋅⊰\n🗂 الخدمة: ${s ? s.name : '-'}\n${isL ? `🌐 ${it.url}` : `👤 ${it.user}`}\n📌 الحالة: ${status(it)}\n⏳ الانتهاء: ${expTxt(it)}\n👁 الاستخدام: ${it.uses}\n🚩 البلاغات: ${it.reports}`,
    btns: [
      ['r', it.off ? '✅ تفعيل' : '⛔ تعطيل', 'net:t:' + it.id],
      ['r', '⏳ تحديد انتهاء', 'net:e:' + it.id],
      ['r', '🗑 حذف', 'net:d:' + it.id],
      ['r', '🔙 رجوع', s ? `net:a:items:${s.id}:0` : 'net:a:svc:0']
    ]
  });
}

async function screenReports(c) {
  const { db, conn, m } = c;
  const list = allItems(db).filter(x => x.reports > 0).sort((a, b) => b.reports - a.reports).slice(0, 9);
  if (!list.length) return ui(conn, m.chat, { title: '🚩 البلاغات', body: '*✅ لا توجد بلاغات حالياً*', btns: [BACK_ADMIN] });
  return ui(conn, m.chat, {
    title: '🚩 البلاغات',
    body: `*البلاغات*\nعناصر عليها بلاغات: ${list.length}\n_الأعلى بلاغاً أولاً. اختر عنصر لمعالجته._`,
    list: { title: '🚩 العناصر', sections: [{ title: 'بلاغات', rows: list.map(x => [`${x.id} | ${x.reports} بلاغ`, `${findSvc(db, x.svc)?.name || ''} • ${x.url || x.user} • ${x.off ? 'معطّل' : 'فعّال'}`, 'net:i:' + x.id]) }] },
    btns: [['r', '🧹 تصفير الكل', 'net:a:clr'], BACK_ADMIN]
  });
}

const userLabel = (k, u) => u.name || (u.phone ? '+' + u.phone : num(k));
async function screenUsers(c, page = 0) {
  const { db, conn, m } = c;
  const all = Object.entries(db.users).sort((a, b) => (b[1].total || 0) - (a[1].total || 0) || (b[1].joined || 0) - (a[1].joined || 0));
  if (!all.length) return ui(conn, m.chat, { title: '👥 المستخدمون', body: '*لا يوجد مستخدمون بعد*', btns: [BACK_ADMIN] });
  const pages = Math.ceil(all.length / PAGE);
  page = clampPage(page, all.length);
  const rows = all.slice(page * PAGE, page * PAGE + PAGE).map(([k, u]) => [
    `${u.banned ? '🚫 ' : ''}${userLabel(k, u)}`,
    `Lv${lvlOf(u.xp)} • ${u.total || 0} استخدام • ${u.phone || num(k)}`, 'net:u:' + u.uid]);
  const nav = [];
  if (page > 0) nav.push(['⬅️ السابق', `صفحة ${page}`, `net:a:users:${page - 1}`]);
  if (page < pages - 1) nav.push(['➡️ التالي', `صفحة ${page + 2}`, `net:a:users:${page + 1}`]);
  return ui(conn, m.chat, {
    title: '👥 المستخدمون',
    body: `*المستخدمون* (${all.length})\nالصفحة ${page + 1} من ${pages}\n_الأكثر نشاطاً أولاً. اختر مستخدم._`,
    list: { title: '👥 الأعضاء', sections: [{ title: 'الأعضاء', rows }, ...(nav.length ? [{ title: 'تنقّل', rows: nav }] : [])] },
    btns: [BACK_ADMIN]
  });
}

async function screenUser(c, n) {
  const { db, conn, m } = c;
  const key = Object.keys(db.users).find(k => String(db.users[k].uid) === String(n));
  if (!key) return conn.sendMessage(m.chat, { text: '*❌ المستخدم غير موجود*' });
  const u = db.users[key];
  return ui(conn, m.chat, {
    title: '👤 ' + cut(userLabel(key, u), 20),
    body: `*${userLabel(key, u)}*\n⊱⋅ ──────────── ⋅⊰\n📞 الرقم: ${u.phone ? '+' + u.phone : 'غير معروف'}\n🆔 المعرّف: ${num(key)}\n📌 الحالة: ${u.banned ? '🚫 محظور' : '✅ عادي'}\n📊 مجموع الاستخدام: ${u.total || 0}\n🏅 المستوى: ${lvlOf(u.xp)} | ✨ ${u.xp || 0} XP | 💰 ${u.pts || 0}\n🌐 اللغة: ${u.lang === 'en' ? 'English' : 'العربية'}\n🔔 التنبيهات: ${u.sub ? 'مفعّلة' : 'متوقفة'}\n📅 اليوم: ${u.day === today() ? u.n : 0}\n🚩 بلاغاته: ${(u.reported || []).length}`,
    btns: [[ 'r', u.banned ? '✅ فك الحظر' : '🚫 حظر', (u.banned ? 'net:ubn:' : 'net:ub:') + n ], ['r', '🔙 المستخدمون', 'net:a:users:0'], BACK_ADMIN]
  });
}

async function screenStats(c) {
  const { db, conn, m } = c;
  const all = allItems(db);
  const svcs = db.services.slice().sort((a, b) => itemsOf(db, b).reduce((n, x) => n + x.uses, 0) - itemsOf(db, a).reduce((n, x) => n + x.uses, 0)).slice(0, 8)
    .map(s => `${svcIcon(s)} ${cut(s.name, 18)}: ${availOf(db, s)}/${itemsOf(db, s).length} • 👁${itemsOf(db, s).reduce((n, x) => n + x.uses, 0)}`).join('\n') || 'لا يوجد';
  return ui(conn, m.chat, {
    title: '📊 الإحصائيات',
    body: `*الإحصائيات*\n⊱⋅ ──────────── ⋅⊰\n🗂 الخدمات: ${db.services.length}\n🔗 روابط فعّالة: ${totalAvail(db, 'link')} من ${db.links.length}\n🔐 حسابات فعّالة: ${totalAvail(db, 'acc')} من ${db.accs.length}\n👁 مرات الاستخدام: ${all.reduce((s, x) => s + x.uses, 0)}\n🚩 مجموع البلاغات: ${all.reduce((s, x) => s + x.reports, 0)}\n👥 المستخدمون: ${Object.keys(db.users).length}\n🔔 المشتركون بالتنبيهات: ${Object.values(db.users).filter(u => u.sub).length}\n🚫 المحظورون: ${Object.values(db.users).filter(u => u.banned).length}\n⏳ تنتهي خلال 3 أيام: ${all.filter(x => x.exp && x.exp > Date.now() && x.exp - Date.now() < 3 * 86400000).length}\n\n*🏆 أكثر الخدمات استخداماً*\n${svcs}`,
    btns: [BACK_ADMIN]
  });
}

async function screenSettings(c) {
  const { db, conn, m } = c;
  const g = db.cfg;
  return ui(conn, m.chat, {
    title: '⚙️ الإعدادات',
    body: `*الإعدادات الحالية*\n⊱⋅ ──────────── ⋅⊰\n🌐 الاسم الافتراضي للحسابات: ${g.site}\n⏱ الانتظار بين الطلبات: ${g.cooldown} ث\n📅 الحد اليومي: ${g.daily}\n🔧 تعطيل تلقائي بعد: ${g.autoOff} بلاغ\n⚠️ تنبيه المخزون عند: ${g.low}`,
    list: { title: '✏️ تعديل إعداد', sections: [{ title: 'اختر الإعداد', rows: [
      ['🌐 الاسم الافتراضي', cut(g.site, 40), 'net:s:site'],
      ['⏱ الانتظار', `${g.cooldown} ثانية`, 'net:s:cooldown'],
      ['📅 الحد اليومي', String(g.daily), 'net:s:daily'],
      ['🔧 التعطيل التلقائي', `${g.autoOff} بلاغ`, 'net:s:autoOff'],
      ['⚠️ تنبيه المخزون', String(g.low), 'net:s:low'],
    ] }] },
    btns: [BACK_ADMIN]
  });
}

async function screenLog(c) {
  const { db, conn, m } = c;
  const rows = db.log.slice(-15).reverse().map(l => `${new Date(l.t).toISOString().slice(5, 16).replace('T', ' ')} | ${l.w} | ${l.x}`).join('\n');
  return ui(conn, m.chat, { title: '📜 السجل', body: '*آخر العمليات*\n⊱⋅ ──────────── ⋅⊰\n' + (rows || 'لا يوجد'), btns: [BACK_ADMIN] });
}

// ➕ إضافة: الخطوة 1، نوع المحتوى
async function screenAdd(c) {
  return ui(c.conn, c.m.chat, {
    title: '➕ إضافة',
    body: '*ماذا تريد تضيف؟*\n⊱⋅ ──────────── ⋅⊰\n🔐 *حسابات*: تختار المنصة (Netflix مثلاً) ثم ترسل الحسابات بصيغة `user:pass`\n🔗 *روابط*: تختار الخدمة (جروبات مثلاً) ثم ترسل الروابط\n\n_الحسابات تضاف في الخاص فقط._',
    btns: [['r', '🔐 حسابات', 'net:p:addacc'], ['r', '🔗 روابط', 'net:p:addlink'], BACK_ADMIN]
  });
}

// ➕ إضافة: الخطوة 2، اختيار الخدمة أو إنشاء جديدة
async function screenPickService(c, type) {
  const { db, conn, m } = c;
  const label = type === 'acc' ? 'الحسابات' : 'الروابط';
  const list = db.services.filter(s => s.type === type).slice(-8).reverse();
  const rows = list.map(s => [`${svcIcon(s)} ${s.name}${s.off ? ' ⛔' : ''}`, `${itemsOf(db, s).length} عنصر • أضف لها`, 'net:ps:' + s.id]);
  rows.push(['➕ خدمة جديدة', type === 'acc' ? 'اكتب اسم المنصة' : 'اكتب اسم الخدمة', 'net:pn:' + type]);
  return ui(conn, m.chat, {
    title: type === 'acc' ? '🔐 إضافة حسابات' : '🔗 إضافة روابط',
    body: `*اختر الخدمة*\nتضيف ${label} لخدمة موجودة، أو تنشئ خدمة جديدة باسم تختاره.`,
    list: { title: '🗂 الخدمات', sections: [{ title: type === 'acc' ? 'منصات الحسابات' : 'خدمات الروابط', rows }] },
    btns: [['r', '🔙 رجوع', 'net:a:add'], BACK_ADMIN]
  });
}

async function screenCast(c) {
  const { db, conn, m } = c;
  const subs = Object.values(db.users).filter(u => u.sub && !u.banned).length;
  const last = db.casts.at(-1);
  return ui(conn, m.chat, {
    title: '📢 الرسائل الإعلانية',
    body: `*إرسال إعلان للمشتركين*\n⊱⋅ ──────────── ⋅⊰\n🔔 المشتركون: *${subs}*\n${last ? `📨 آخر إعلان: ${new Date(last.t).toISOString().slice(0, 16).replace('T', ' ')}\n✅ وصل: ${last.sent} | ❌ فشل: ${last.fail}` : '📨 ما أرسلت إعلان بعد'}\n\n_الإعلان يوصل فقط لمن اشترك بزر "اشترك بالتنبيهات"، وهذا يحمي رقم البوت من الحظر._`,
    btns: [['r', '✍️ رسالة جديدة', 'net:c:new'], BACK_ADMIN]
  });
}

async function sendCast(c, text) {
  const { db, conn, m } = c;
  global.netCasting = true;
  let sent = 0, fail = 0, streak = 0, stopped = false;
  try {
    const seen = new Set();
    const targets = [];
    for (const [k, u] of Object.entries(db.users)) {
      if (!u.sub || u.banned) continue;
      const jid = u.dm || k;
      if (seen.has(jid)) continue;
      seen.add(jid); targets.push({ jid, u });
    }
    for (const t of targets.slice(0, CAST_MAX)) {
      try {
        await ui(conn, t.jid, {
          title: T(t.u, 'bc_title'),
          body: `${T(t.u, 'bc_head')}\n⊱⋅ ──────────── ⋅⊰\n${text}`,
          footer: T(t.u, 'bc_foot'),
          btns: [['r', T(t.u, 'b_services'), 'net:svc:0'], ['r', T(t.u, 'b_menu'), 'net:menu'], ['r', T(t.u, 'r_sub_off'), 'net:unsub']]
        });
        sent++; streak = 0; t.u.fails = 0;
      } catch (e) {
        fail++; streak++; t.u.fails = (t.u.fails || 0) + 1;
        if (t.u.fails >= 3) t.u.sub = false;
      }
      if (streak >= 5) { stopped = true; break; }
      await sleep(CAST_MIN + Math.random() * CAST_JIT);
    }
    db.casts.push({ t: Date.now(), sent, fail, total: targets.length, text: cut(text, 60) });
    if (db.casts.length > 30) db.casts.shift();
    addLog(db, m.sender, `cast ${sent}/${targets.length}`);
  } finally {
    global.netCasting = false;
    save();
  }
  return ui(conn, m.chat, {
    title: '📢 انتهى الإرسال',
    body: `*${stopped ? '⚠️ توقف الإرسال لكثرة الأخطاء المتتالية' : '✅ انتهى الإرسال'}*\n✅ وصل: ${sent}\n❌ فشل: ${fail}`,
    btns: [BACK_ADMIN]
  });
}

/* ---------------- الخدمات (التوزيع) ---------------- */
async function serve(c, svc) {
  const { db, conn, m, owner, user } = c;
  const tab = svc.type === 'acc' ? 'acc' : 'link';
  const lvl = lvlOf(user.xp);
  if (!owner) {
    const wait = Math.ceil(((user.t || 0) + cooldownFor(db, lvl) * 1000 - Date.now()) / 1000);
    if (wait > 0) return conn.sendMessage(m.chat, { text: tr(c, 'wait', { s: wait }) });
    if (user.day !== today()) { user.day = today(); user.n = 0; }
    const lim = dailyFor(db, user);
    if (lim && user.n >= lim) return conn.sendMessage(m.chat, { text: tr(c, 'limit', { n: lim }) });
  }
  const got = pick(itemsOf(db, svc), user, tab === 'link' ? 'seenL' : 'seenA');
  if (!got) return ui(conn, m.chat, { body: tr(c, 'svc_out_msg', { name: svc.name }), btns: [['r', tr(c, 'b_services'), 'net:svc:0'], bm(c)] });
  const it = got.item;
  it.uses++; user.total = (user.total || 0) + 1; user.n = (user.n || 0) + 1; user.t = Date.now(); user.last = it.id;
  gain(c, XP_USE);

  // تنبيه المخزون لكل خدمة على حدة
  const left = availOf(db, svc);
  if (left <= db.cfg.low && !db.lowAt[svc.id]) {
    db.lowAt[svc.id] = true;
    for (const o of c.bot?.config?.owners || []) { try { await conn.sendMessage(o.jid, { text: `⚠️ *تنبيه مخزون*\nباقي ${left} فقط في *${svc.name}*. أضف المزيد من لوحة الإدارة.` }); } catch {} }
  } else if (left > db.cfg.low) db.lowAt[svc.id] = false;

  const strip = s => s.replace(/💰 -\d+ • [^\n]*\n/, ''); // سطر الأسعار مخفي حالياً
  const vars = { url: it.url, user: it.user, pass: it.pass, site: svc.name, rem: got.rem, xp: XP_USE, cost: 0, bal: user.pts || 0 };
  if (tab === 'link') {
    await ui(conn, m.chat, {
      title: cut(`${svcIcon(svc)} ${svc.name}`, 24),
      body: `📦 *${svc.name}*\n` + strip(tr(c, 'link_body', vars)),
      footer: tr(c, 'link_foot'),
      btns: [['c', tr(c, 'b_copy'), it.url], ['u', tr(c, 'b_open'), it.url], ['r', tr(c, 'b_again'), 'net:sv:' + svc.id], ['r', tr(c, 'b_bad'), 'net:rp:' + it.id], ['r', tr(c, 'b_services'), 'net:svc:0']]
    });
  } else {
    await ui(conn, m.chat, {
      title: cut(`${svcIcon(svc)} ${svc.name}`, 24),
      body: strip(tr(c, 'acc_body', vars)),
      footer: tr(c, 'link_foot'),
      btns: [['c', tr(c, 'b_copy_u'), it.user], ['c', tr(c, 'b_copy_p'), it.pass], ['r', tr(c, 'b_again'), 'net:sv:' + svc.id], ['r', tr(c, 'b_bad'), 'net:rp:' + it.id], ['r', tr(c, 'b_services'), 'net:svc:0']]
    });
  }
  return announceLevel(c);
}

async function serveById(c, id) {
  const s = findSvc(c.db, id);
  if (!s || s.off) return ui(c.conn, c.m.chat, { body: tr(c, 'svc_none'), btns: [['r', tr(c, 'b_services'), 'net:svc:0'], bm(c)] });
  return serve(c, s);
}

// توافق مع الأزرار القديمة (رابط/حساب): خدمة وحدة تفتح مباشرة، وأكثر من وحدة تعرض القائمة
async function serveType(c, type) {
  const arr = c.db.services.filter(s => !s.off && s.type === type);
  return arr.length === 1 ? serve(c, arr[0]) : screenServices(c, 0, type);
}

async function reportItem(c, id) {
  const { db, conn, m, user } = c;
  const it = id ? findItem(db, id) : findItem(db, user.last || '');
  if (!it) return ui(conn, m.chat, { body: tr(c, 'rep_none'), btns: [['r', tr(c, 'b_services'), 'net:svc:0'], bm(c)] });
  user.reported ||= [];
  const again = ['r', tr(c, 'b_again'), it.svc && findSvc(db, it.svc) ? 'net:sv:' + it.svc : 'net:svc:0'];
  if (user.reported.includes(it.id)) return ui(conn, m.chat, { body: tr(c, 'rep_dup'), btns: [again, bm(c)] });
  user.reported.push(it.id);
  it.reports++;
  let extra = '';
  if (db.cfg.autoOff && it.reports >= db.cfg.autoOff && !it.off) {
    it.off = true; extra = tr(c, 'auto_off');
    for (const o of c.bot?.config?.owners || []) { try { await conn.sendMessage(o.jid, { text: `🚩 *تعطيل تلقائي*\n${it.id} (${findSvc(db, it.svc)?.name || ''}) وصل ${it.reports} بلاغ\n${it.url || it.user}` }); } catch {} }
  }
  // مكافأة صغيرة على البلاغ (بحد يومي حتى ما يُستغل)
  let bonus = '';
  if (user.repDay !== today()) { user.repDay = today(); user.repN = 0; }
  if (user.repN < REPORT_REWARDS_PER_DAY) { user.repN++; gain(c, XP_REPORT, PTS_REPORT); bonus = `\n✨ +${XP_REPORT} XP • 💰 +${PTS_REPORT}`; }
  await ui(conn, m.chat, { body: tr(c, 'rep_ok', { extra, bonus }), btns: [again, bm(c)] });
  return announceLevel(c);
}

/* ---------------- الإدخال المعلّق (المالك يرسل نص بعد ضغط زر) ---------------- */
const PROMPTS = {
  exp: '⏳ *أرسل عدد الأيام* (مثال 7)، أو 0 لإلغاء الانتهاء',
  cast: '📢 *اكتب الرسالة الإعلانية الآن* (حتى 700 حرف)',
  site: '🌐 *أرسل الاسم الافتراضي الجديد للحسابات*',
  cooldown: '⏱ *أرسل عدد الثواني* بين كل طلب',
  daily: '📅 *أرسل الحد اليومي* لكل شخص (0 = بلا حد)',
  autoOff: '🔧 *أرسل عدد البلاغات* للتعطيل التلقائي (0 = إيقاف)',
  low: '⚠️ *أرسل الرقم* الذي يظهر عنده تنبيه المخزون'
};
function promptFor(db, act, arg) {
  if (act === 'addacc' || act === 'addlink') {
    const n = findSvc(db, arg)?.name || '';
    return act === 'addacc' ? `🔐 *أرسل الآن حسابات ${n}*\nبصيغة \`user:pass\` (كل حساب بسطر)` : `🔗 *أرسل الآن روابط ${n}*\n(كل رابط بسطر)`;
  }
  if (act === 'svcname') return arg === 'acc' ? '🏷 *اكتب اسم المنصة*\n(مثال: Netflix, Crunchyroll, Spotify)' : '🏷 *اكتب اسم الخدمة*\n(مثال: جروبات، قنوات، أدوات)';
  if (act === 'svcrename') return `✏️ *اكتب الاسم الجديد* للخدمة *${findSvc(db, arg)?.name || ''}*`;
  return PROMPTS[act] || '';
}
async function askInput(c, act, arg, note = '') {
  if (act === 'addacc' && c.m.isGroup) return c.conn.sendMessage(c.m.chat, { text: '*🔒 إضافة الحسابات في الخاص فقط، عشان كلمات السر ما تظهر للناس.*\nافتح الخاص مع البوت واكتب .jjk' });
  global.netPending[c.m.sender] = { act, arg, exp: Date.now() + PENDING_MS, chat: c.m.chat };
  return c.conn.sendMessage(c.m.chat, { text: `${note ? note + '\n\n' : ''}${promptFor(c.db, act, arg)}\n\n_للإلغاء اكتب: الغاء_` });
}
const cleanName = s => String(s || '').replace(/[*_~`\n\r]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 30);

async function handleInput(c, p, text) {
  const { db, conn, m } = c;
  delete global.netPending[m.sender];
  if (/^(الغاء|إلغاء|cancel)$/i.test(text.trim())) return conn.sendMessage(m.chat, { text: '*تم الإلغاء*' });
  const done = (msg, btns) => ui(conn, m.chat, { body: msg, btns });

  if (p.act === 'svcname') {
    const name = cleanName(text);
    if (name.length < 2) return done('*❌ الاسم قصير أو غير صالح*', [['r', '🔁 حاول مرة ثانية', 'net:pn:' + p.arg], BACK_ADMIN]);
    const type = p.arg === 'acc' ? 'acc' : 'link';
    let svc = db.services.find(s => s.type === type && s.name.toLowerCase() === name.toLowerCase());
    const existed = !!svc;
    if (!svc) { svc = { id: 'S' + db.ns++, name, type, off: false }; db.services.push(svc); addLog(db, m.sender, `new service ${svc.id}`); }
    return askInput(c, type === 'acc' ? 'addacc' : 'addlink', svc.id, `*✅ ${existed ? 'الخدمة موجودة' : 'تم إنشاء الخدمة'}: ${svc.name}*`);
  }

  if (p.act === 'addlink' || p.act === 'addacc') {
    const svc = findSvc(db, p.arg);
    if (!svc || svc.type !== (p.act === 'addacc' ? 'acc' : 'link')) return done('*❌ الخدمة غير موجودة، ابدأ من ➕ إضافة*', [['r', '➕ إضافة', 'net:a:add'], BACK_ADMIN]);
    const next = [['r', '➕ المزيد لنفس الخدمة', 'net:ps:' + svc.id], ['r', '🗂 الخدمة', 'net:a:sv:' + svc.id], BACK_ADMIN];
    if (p.act === 'addlink') {
      const urls = text.split(/\s+/).map(clean).filter(Boolean);
      let ok = 0, bad = 0, dup = 0;
      for (const u of urls) {
        if (!isUrl(u)) { bad++; continue; }
        if (db.links.some(x => x.url === u && x.svc === svc.id)) { dup++; continue; }
        db.links.push({ id: 'L' + db.nl++, svc: svc.id, url: u, uses: 0, reports: 0, off: false, exp: 0 }); ok++;
      }
      addLog(db, m.sender, `add روابط x${ok} → ${svc.id}`);
      return done(`*✅ أضفت ${ok} رابط إلى ${svc.name}*${dup ? `\n♻️ مكرر: ${dup}` : ''}${bad ? `\n⚠️ مرفوض (ليس رابط صحيح): ${bad}` : ''}\n📦 المجموع في الخدمة: ${itemsOf(db, svc).length}`, next);
    }
    let ok = 0, bad = 0, dup = 0;
    for (const ln of text.split('\n').map(s => s.trim()).filter(Boolean)) {
      const i = ln.indexOf(':');
      const user = i > 0 ? ln.slice(0, i).trim() : '', pass = i > 0 ? ln.slice(i + 1).trim() : '';
      if (!user || !pass || user.length > 120 || pass.length > 120) { bad++; continue; }
      if (db.accs.some(x => x.user === user && x.pass === pass && x.svc === svc.id)) { dup++; continue; }
      db.accs.push({ id: 'A' + db.na++, svc: svc.id, user, pass, uses: 0, reports: 0, off: false, exp: 0 }); ok++;
    }
    addLog(db, m.sender, `add حسابات x${ok} → ${svc.id}`);
    return done(`*✅ أضفت ${ok} حساب إلى ${svc.name}*${dup ? `\n♻️ مكرر: ${dup}` : ''}${bad ? `\n⚠️ مرفوض: ${bad} (الصيغة user:pass)` : ''}\n📦 المجموع في الخدمة: ${itemsOf(db, svc).length}\n_يُفضّل حذف رسالتك التي فيها كلمات السر._`, next);
  }

  if (p.act === 'svcrename') {
    const svc = findSvc(db, p.arg); const name = cleanName(text);
    if (!svc) return done('*❌ الخدمة غير موجودة*', [BACK_ADMIN]);
    if (name.length < 2) return done('*❌ الاسم قصير أو غير صالح*', [['r', '🔁 حاول مرة ثانية', 'net:sn:' + svc.id], BACK_ADMIN]);
    if (db.services.some(s => s !== svc && s.type === svc.type && s.name.toLowerCase() === name.toLowerCase())) return done('*❌ يوجد خدمة بنفس الاسم*', [['r', '🔁 اسم آخر', 'net:sn:' + svc.id], BACK_ADMIN]);
    svc.name = name; addLog(db, m.sender, `rename ${svc.id}`);
    return done(`*✅ تم تغيير الاسم إلى ${name}*`, [['r', '🗂 الخدمة', 'net:a:sv:' + svc.id], BACK_ADMIN]);
  }

  if (p.act === 'cast') {
    const t = text.trim();
    if (t.length > 700) return done('*❌ الرسالة طويلة، الحد 700 حرف*', [['r', '✍️ أعد الكتابة', 'net:c:new'], BACK_ADMIN]);
    global.netDraft[m.sender] = { text: t, exp: Date.now() + 600000 };
    const subs = Object.values(db.users).filter(u => u.sub && !u.banned).length;
    return ui(conn, m.chat, {
      title: '📢 معاينة الإعلان',
      body: `*هذي معاينة رسالتك:*\n⊱⋅ ──────────── ⋅⊰\n${t}\n⊱⋅ ──────────── ⋅⊰\n📨 سترسل إلى *${subs}* مشترك`,
      btns: [['r', '✅ إرسال الآن', 'net:c:go'], ['r', '✏️ تعديل', 'net:c:new'], ['r', '❌ إلغاء', 'net:c:no']]
    });
  }
  if (p.act === 'exp') {
    const it = findItem(db, p.arg), d = Number(text.trim());
    if (!it || !Number.isFinite(d) || d < 0) return done('*❌ رقم غير صحيح*', [BACK_ADMIN]);
    it.exp = d === 0 ? 0 : Date.now() + d * 86400000;
    addLog(db, m.sender, `exp ${it.id} ${d}`);
    return done(d === 0 ? `*♾ ${it.id} بدون انتهاء*` : `*⏳ ${it.id} ينتهي بعد ${d} يوم*`, [['r', '🔙 العنصر', 'net:i:' + it.id], BACK_ADMIN]);
  }
  if (p.act === 'site') {
    db.cfg.site = cut(cleanName(text), 80) || db.cfg.site; addLog(db, m.sender, 'set site');
    return done('*✅ تم الحفظ*', [['r', '⚙️ الإعدادات', 'net:a:set'], BACK_ADMIN]);
  }
  if (['cooldown', 'daily', 'autoOff', 'low'].includes(p.act)) {
    const v = Number(text.trim());
    if (!Number.isFinite(v) || v < 0 || v > 100000) return done('*❌ أرسل رقماً صحيحاً*', [['r', '⚙️ الإعدادات', 'net:a:set']]);
    db.cfg[p.act] = Math.floor(v); addLog(db, m.sender, `set ${p.act} ${v}`);
    return done(`*✅ تم الحفظ: ${v}*`, [['r', '⚙️ الإعدادات', 'net:a:set'], BACK_ADMIN]);
  }
}

/* ---------------- الموزّع الرئيسي ---------------- */
async function dispatch(m, ctx, id) {
  const { conn, bot } = ctx;
  const db = getDB();
  const owner = checkOwner(m, bot, db);
  const user = (db.users[m.sender] ||= { uid: db.nu++, total: 0, t: 0, day: '', n: 0, banned: false, reported: [], xp: 0, pts: 0, streak: 0, joined: Date.now() });
  if (!user.uid) user.uid = db.nu++;
  if (!m.isGroup) user.dm = m.chat;
  await rememberUser(m, user);
  const c = { db, conn, m, bot, owner, user };
  const [, a, b1, b2, b3] = id.split(':');

  if (user.banned && !owner) return conn.sendMessage(m.chat, { text: tr(c, 'banned') });

  // أوامر المستخدمين
  if (a === 'menu') return user.lang ? screenMenu(c) : screenLang(c);
  if (a === 'svc') return screenServices(c, Number(b1) || 0, b2 === 'acc' || b2 === 'link' ? b2 : '');
  if (a === 'sv') return serveById(c, b1);
  if (a === 'link') return serveType(c, 'link');
  if (a === 'acc') return serveType(c, 'acc');
  if (a === 'rp') return reportItem(c, b1);
  if (a === 'report') return reportItem(c, null);
  if (a === 'help') return screenHelp(c);
  if (a === 'profile') return screenProfile(c);
  if (a === 'daily') return screenDaily(c);
  if (a === 'shop') return screenShop(c);
  if (a === 'buy') return buyExtra(c);
  if (a === 'lang') return screenLang(c);
  if (a === 'lg') {
    if (b1 !== 'ar' && b1 !== 'en') return;
    user.lang = b1;
    await conn.sendMessage(m.chat, { text: tr(c, 'lang_set') });
    return screenMenu(c);
  }
  if (a === 'sub' || a === 'unsub') {
    user.sub = a === 'sub'; user.fails = 0;
    return ui(conn, m.chat, { body: tr(c, user.sub ? 'sub_on' : 'sub_off'), btns: [bm(c)] });
  }

  // كل ما بعد هذا للمالك فقط
  if (!owner) return conn.sendMessage(m.chat, { text: '*❌ هذا القسم للمالك فقط*\n_إذا أنت المالك: اكتب .jjk مرة واحدة ليتعرف عليك البوت، ثم جرّب الزر._' });

  if (a === 'admin') return screenAdmin(c);
  if (a === 'a') {
    if (b1 === 'svc') return screenServicesAdmin(c, Number(b2) || 0);
    if (b1 === 'sv') return screenServiceAdmin(c, b2);
    if (b1 === 'items') return (b2 === 'L' || b2 === 'A') ? screenServicesAdmin(c, 0) : screenItems(c, b2, Number(b3) || 0);
    if (b1 === 'add') return screenAdd(c);
    if (b1 === 'rep') return screenReports(c);
    if (b1 === 'cast') return screenCast(c);
    if (b1 === 'users') return screenUsers(c, Number(b2) || 0);
    if (b1 === 'stats') return screenStats(c);
    if (b1 === 'set') return screenSettings(c);
    if (b1 === 'log') return screenLog(c);
    if (b1 === 'clr') {
      allItems(db).forEach(x => (x.reports = 0));
      Object.values(db.users).forEach(u => (u.reported = []));
      addLog(db, m.sender, 'clear reports');
      return ui(conn, m.chat, { body: '*✅ تم تصفير كل البلاغات*', btns: [BACK_ADMIN] });
    }
    if (b1 === 'backup') {
      if (m.isGroup) return conn.sendMessage(m.chat, { text: '*🔒 النسخة الاحتياطية في الخاص فقط، لأن فيها الحسابات.*' });
      await conn.sendMessage(m.chat, { document: Buffer.from(JSON.stringify(db, null, 2)), mimetype: 'application/json', fileName: `net-backup-${today()}.json` });
      return ui(conn, m.chat, { body: '*💾 هذي نسخة احتياطية، احفظها بمكان آمن.*', btns: [BACK_ADMIN] });
    }
    return;
  }
  // ➕ إضافة: اختيار النوع ← الخدمة ← إرسال المحتوى
  if (a === 'p') return (b1 === 'addacc' || b1 === 'addlink') ? screenPickService(c, b1 === 'addacc' ? 'acc' : 'link') : undefined;
  if (a === 'pn') return askInput(c, 'svcname', b1 === 'acc' ? 'acc' : 'link');
  if (a === 'ps') {
    const s = findSvc(db, b1);
    if (!s) return conn.sendMessage(m.chat, { text: '*❌ الخدمة غير موجودة*' });
    return askInput(c, s.type === 'acc' ? 'addacc' : 'addlink', s.id);
  }
  // إدارة الخدمة
  if (a === 'sn') { if (!findSvc(db, b1)) return conn.sendMessage(m.chat, { text: '*❌ الخدمة غير موجودة*' }); return askInput(c, 'svcrename', b1.toUpperCase()); }
  if (a === 'st') {
    const s = findSvc(db, b1); if (!s) return conn.sendMessage(m.chat, { text: '*❌ الخدمة غير موجودة*' });
    s.off = !s.off; addLog(db, m.sender, `${s.off ? 'off' : 'on'} ${s.id}`);
    return screenServiceAdmin(c, s.id);
  }
  if (a === 'sd') {
    const s = findSvc(db, b1); if (!s) return conn.sendMessage(m.chat, { text: '*❌ الخدمة غير موجودة*' });
    return ui(conn, m.chat, { title: '🗑 تأكيد الحذف', body: `*حذف الخدمة ${s.name}؟*\nراح تنحذف معها *${itemsOf(db, s).length}* عنصر نهائياً.`, btns: [['r', '✅ نعم، احذف', 'net:sdok:' + s.id], ['r', '❌ لا', 'net:a:sv:' + s.id]] });
  }
  if (a === 'sdok') {
    const s = findSvc(db, b1); if (!s) return conn.sendMessage(m.chat, { text: '*❌ الخدمة غير موجودة*' });
    db.links = db.links.filter(x => x.svc !== s.id); db.accs = db.accs.filter(x => x.svc !== s.id);
    db.services = db.services.filter(x => x !== s);
    addLog(db, m.sender, `del service ${s.id}`);
    return ui(conn, m.chat, { body: `*🗑 تم حذف الخدمة ${s.name}*`, btns: [['r', '🗂 الخدمات', 'net:a:svc:0'], BACK_ADMIN] });
  }
  if (a === 'c') {
    if (b1 === 'new') return askInput(c, 'cast');
    if (b1 === 'no') { delete global.netDraft[m.sender]; return ui(conn, m.chat, { body: '*تم إلغاء الإعلان*', btns: [BACK_ADMIN] }); }
    if (b1 === 'go') {
      const d = global.netDraft[m.sender];
      if (!d || d.exp < Date.now()) return ui(conn, m.chat, { body: '*⌛ انتهت مهلة المعاينة، اكتب الرسالة من جديد.*', btns: [['r', '✍️ رسالة جديدة', 'net:c:new'], BACK_ADMIN] });
      if (global.netCasting) return conn.sendMessage(m.chat, { text: '*⏳ يوجد إرسال شغّال الآن، انتظر ينتهي.*' });
      delete global.netDraft[m.sender];
      const n = Object.values(db.users).filter(u => u.sub && !u.banned).length;
      if (!n) return ui(conn, m.chat, { body: '*ما فيه مشتركين بعد.*\nالمستخدمون يشتركون من زر "🔔 اشترك بالتنبيهات" في القائمة.', btns: [BACK_ADMIN] });
      await conn.sendMessage(m.chat, { text: `*🚀 بدأ الإرسال إلى ${n} مشترك*\nيرسل بشكل متدرّج لحماية الرقم، وأخبرك عند الانتهاء.` });
      sendCast(c, d.text).catch(e => console.error('[NET cast]', e));
      return;
    }
    return;
  }
  if (a === 'i') return screenItem(c, b1);
  if (a === 't') {
    const it = findItem(db, b1); if (!it) return conn.sendMessage(m.chat, { text: '*❌ غير موجود*' });
    it.off = !it.off; if (!it.off) it.reports = 0;
    addLog(db, m.sender, `${it.off ? 'off' : 'on'} ${it.id}`);
    return screenItem(c, it.id);
  }
  if (a === 'd') {
    const it = findItem(db, b1); if (!it) return conn.sendMessage(m.chat, { text: '*❌ غير موجود*' });
    return ui(conn, m.chat, { title: '🗑 تأكيد الحذف', body: `*هل تريد حذف ${it.id} نهائياً؟*\n${it.url || it.user}`, btns: [['r', '✅ نعم، احذف', 'net:dok:' + it.id], ['r', '❌ لا', 'net:i:' + it.id]] });
  }
  if (a === 'dok') {
    const it = findItem(db, b1); if (!it) return conn.sendMessage(m.chat, { text: '*❌ غير موجود*' });
    db.links = db.links.filter(x => x !== it); db.accs = db.accs.filter(x => x !== it);
    addLog(db, m.sender, `del ${it.id}`);
    return ui(conn, m.chat, { body: `*🗑 تم حذف ${it.id}*`, btns: [['r', '🗂 الخدمة', it.svc ? 'net:a:sv:' + it.svc : 'net:a:svc:0'], BACK_ADMIN] });
  }
  if (a === 'e') { if (!findItem(db, b1)) return conn.sendMessage(m.chat, { text: '*❌ غير موجود*' }); return askInput(c, 'exp', b1.toUpperCase()); }
  if (a === 'u') return screenUser(c, b1);
  if (a === 'ub' || a === 'ubn') {
    const key = Object.keys(db.users).find(k => String(db.users[k].uid) === String(b1));
    if (key) { db.users[key].banned = a === 'ub'; addLog(db, m.sender, `${a === 'ub' ? 'ban' : 'unban'} ${b1}`); }
    return screenUser(c, b1);
  }
  if (a === 's' && PROMPTS[b1]) return askInput(c, b1);
}

/* ---------------- قراءة ضغطة الزر ---------------- */
function getId(m) {
  const pools = [m.message, m.msg].filter(Boolean);
  for (let x of pools) {
    x = x?.ephemeralMessage?.message || x?.viewOnceMessage?.message || x?.viewOnceMessageV2?.message || x;
    const pj = x?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || x?.nativeFlowResponseMessage?.paramsJson;
    if (pj) { try { const id = JSON.parse(pj).id; if (id) return String(id); } catch {} }
    const id = x?.buttonsResponseMessage?.selectedButtonId || x?.listResponseMessage?.singleSelectReply?.selectedRowId || x?.templateButtonReplyMessage?.selectedId;
    if (id) return String(id);
  }
  if (typeof m.text === 'string' && /^net:/.test(m.text.trim())) return m.text.trim();
  return null;
}

/* ---------------- الأمر والـ before ---------------- */
let handler = async (m, ctx) => {
  try {
    const db = getDB();
    const rest = (m.text || '').replace(/^\s*(?:\S+\s+)??\S*?(?:jjk|ggk)\s*/i, '').trim().toLowerCase();
    let id = 'net:menu';
    if (['link', 'رابط'].includes(rest)) id = 'net:link';
    else if (['acc', 'حساب', 'حسابات'].includes(rest)) id = 'net:acc';
    else if (['services', 'service', 'خدمات', 'الخدمات'].includes(rest)) id = 'net:svc:0';
    else if (['بلاغ', 'report'].includes(rest)) id = 'net:report';
    else if (['help', 'مساعدة', 'شرح'].includes(rest)) id = 'net:help';
    else if (['lang', 'language', 'لغة', 'اللغة'].includes(rest)) id = 'net:lang';
    else if (['profile', 'me', 'ملفي', 'حسابي'].includes(rest)) id = 'net:profile';
    else if (['daily', 'يومي', 'مكافأة'].includes(rest)) id = 'net:daily';
    else if (['shop', 'متجر', 'المتجر'].includes(rest)) id = 'net:shop';
    else if (['admin', 'ادارة', 'إدارة'].includes(rest)) id = 'net:admin';
    else if (rest === 'id') {
      const owner = checkOwner(m, ctx.bot, db);
      return m.reply(`*🪪 معرّفك:*\n${idsOf(m).join('\n')}\n\n*الصلاحية:* ${owner ? '🛠 مالك' : '👤 عضو'}`);
    }
    await dispatch(m, ctx, id);
  } catch (e) {
    console.error('[NET]', e);
    try { await m.reply('*⚠️ صار خطأ مؤقت، جرّب مرة ثانية بعد ثواني*'); } catch {}
  } finally { save(); }
};

handler.before = async (m, ctx) => {
  try {
    if (m.fromMe || m.isBaileys) return;
    const id = getId(m);
    if (id && id.startsWith('net:')) {
      try { await dispatch(m, ctx, id); } catch (e) { console.error('[NET]', e); try { await m.reply('*⚠️ صار خطأ مؤقت، جرّب مرة ثانية*'); } catch {} }
      save();
      return true;
    }
    const p = global.netPending[m.sender];
    if (!p) return;
    const text = typeof m.text === 'string' ? m.text : '';
    if (p.exp < Date.now()) { delete global.netPending[m.sender]; return; }
    if (!text) return;
    if (p.chat !== m.chat) return;
    if (/^[./!#]/.test(text.trim())) { delete global.netPending[m.sender]; return; }
    const db = getDB();
    const owner = checkOwner(m, ctx.bot, db);
    if (!owner) { delete global.netPending[m.sender]; return; }
    const c = { db, conn: ctx.conn, m, bot: ctx.bot, owner };
    try { await handleInput(c, p, text); } catch (e) { console.error('[NET]', e); }
    save();
    return true;
  } catch (e) { console.error('[NET]', e); }
};

handler.help = handler.command = ["jjk", "ggk"];
handler.tags = ['main'];

export default handler;
