import fs from 'fs';

const MENU_TIMEOUT = 120000;

// ⚠️ عدّل هذا المسار ليطابق مكان الفيديو الفعلي عندك على السيرفر
const VIDEO_PATH = '/home/container/sub/AhaTik_tatwile_78adc006-5955-4c79-a836-b43111c60e1d_.mp4';

const CATEGORIES = [
    [1, 'التـحـمـيـل', 'downloads', '📂'],
    [2, 'الـمـجـمـوعـات', 'group', '🐞'],
    [3, 'الـمـلـصـقـات', 'sticker', '🌄'],
    [4, 'الـمـطـوريـن', 'owner', '🇩🇪'],
    [5, 'امـثـلـه', 'example', '✳️'],
    [6, 'الـادوات', 'tools', '🚀'],
    [7, 'الـبـحـث', 'search', '🌐'],
    [8, 'الادمــن', 'admin', '👨🏻‍⚖️'],
    [9, 'الالــعـاب', 'games', '🎮'],
    [10, 'الچيف', 'gif', '✴️'],
    [11, 'الـبــنـك', 'bank', '💰'],
    [12, 'الـذكـاء الاصـطـنـاعـي', 'ai', '🤖'],
    [13, 'الـبـوتـات الـفـرعـي', 'sub', '♥️'],
    [14, 'مـعـلومـات الـبـوت', 'info', '🗃️'],
    [15, 'الـالــقــاب', 'nicknames', '🫯'],
    [16, 'الـلـوجـوهــات', 'logos', '🎡'],
    [17, 'تـغـيـر الاصـوات', 'voices', '📢'],
    [18, 'أخــرى', 'other', '🌹']
];

const getCat = n => CATEGORIES.find(c => c[0] === n);

if (!global.menus) global.menus = {};

const clean = () => {
    const now = Date.now();
    Object.keys(global.menus).forEach(k => {
        if (now - global.menus[k].time > MENU_TIMEOUT) delete global.menus[k];
    });
};

const menu = async (m, { conn, bot }) => {
    clean();
    
    const cmds = await bot.getAllCommands();
    const cats = {};
    
    cmds.forEach(c => {
        if (!c.usage?.length) return;
        const cat = c.category || 'other';
        if (!cats[cat]) cats[cat] = [];
        cats[cat].push(c);
    });

    const txt = `
┏━━━━━ ✦ 🕷️ 𝗝𝗢𝗬 𝗕𝗢𝗬 𝗕𝗢𝗧 ✦ ━━━━━┓

  رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا
  الَّذِينَ سَبَقُونَا بِالْإِيمَانِ

┗━━━━━━━━━━━━━━━━━━━━━━━┛

  『 *الأقسام المتاحة* 』

${CATEGORIES.map(c => `   ${c[3]}  *${c[0]}* ▸ ${c[1]}`).join('\n')}

┏━━━━━━━━━━━━━━━━━━━━━━━┓
   ↩️ رد على هذه الرسالة برقم القسم فقط
┗━━━━━━━━━━━━━━━━━━━━━━━┛

        © 𝗝𝗢𝗬 𝗕𝗢𝗬`;

    // إرسال الفيديو بدون contextInfo معقد لضمان الظهور في واتساب العادي
    const msg = await conn.sendMessage(m.chat, { 
        video: fs.readFileSync(VIDEO_PATH),
        caption: txt,
        mentions: [m.sender]
    }, { quoted: m });
  
    global.menus[msg.key.id] = { cats, chatId: m.chat, time: Date.now() };
};

menu.before = async (m, { conn, bot }) => {
    clean();
    
    const menuData = global.menus[m.quoted?.id];
    if (!menuData) return false;
    
    const cat = getCat(parseInt(m.text));
    if (!cat) {
        await conn.sendMessage(m.chat, { text: '*❌≥ اختار رقم من القائمة بس*' }, { quoted: m });
        return true;
    }
    
    const cmds = menuData.cats[cat[2]];
    if (!cmds?.length) {
        await conn.sendMessage(m.chat, { text: '*❌≥ القسم فاضي*' }, { quoted: m });
        return true;
    }
    
    await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, id: m.quoted.id, fromMe: true } }).catch(() => {});
    delete global.menus[m.quoted.id];
    
    const cmdsList = cmds.map(c => `   ${cat[3]}  /${c.usage.join(`\n   ${cat[3]}  /`)}`).join('\n');
    
    await conn.sendMessage(m.chat, { 
        video: fs.readFileSync(VIDEO_PATH),
        caption: `
┏━━━━━ ${cat[3]} ━━━━━┓
   *قـسـم ${cat[1]}*
┗━━━━━━━━━━━━━━━┛

${cmdsList}

┏━━━━━━━━━━━━━━━┓
   © 𝗝𝗢𝗬 𝗕𝗢𝗬 ~ ${bot.config.info.nameBot}
┗━━━━━━━━━━━━━━━┛
   رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا`.trim(),
        mentions: [m.sender]
    }, { quoted: m });
    
    return true;
};

menu.command = ['الاوامر', 'القائمة', 'menu', 'اوامر'];
export default menu;
