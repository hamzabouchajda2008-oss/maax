const run = async (m) => {
  return m.reply("❌ تم تعطيل نظام التنصيب والبوتات الفرعية نهائياً من قبل المطور.");
};

run.command = ["البوتات", "bots", "تنصيب", "subbot", "bot"];
run.noSub = true;
run.usage = ["تنصيب"];
run.category = "البوتات";
run.owner = true;

export default run;
