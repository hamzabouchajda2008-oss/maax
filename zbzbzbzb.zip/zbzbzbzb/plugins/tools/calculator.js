let handler = async (m, { conn, command }) => {
	const html = `<style>*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;box-sizing:border-box}
.btn{transition:transform .08s,background .15s}
.btn:active{transform:scale(.93)}
</style>
<body style="margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee">
<div style="width:100%;max-width:420px;margin:auto;padding:16px;box-sizing:border-box">
<div style="background:rgba(255,255,255,.06);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.15);border-radius:20px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.35)">

<div style="padding:16px 20px;border-bottom:1px solid rgba(255,255,255,.1)">
<div style="font-size:11px;letter-spacing:1.5px;color:rgba(255,255,255,.45)">NIXEL CALC</div>
<div style="font-size:16px;font-weight:bold;color:#fff">Calculator</div>
</div>

<div style="padding:20px 20px 10px">
<div id="expr" style="min-height:20px;text-align:right;font-size:13px;color:rgba(255,255,255,.4);word-break:break-all;font-variant-numeric:tabular-nums">&nbsp;</div>
<div id="display" style="min-height:52px;text-align:right;font-size:38px;font-weight:600;color:#fff;word-break:break-all;font-variant-numeric:tabular-nums;overflow-x:auto;white-space:nowrap">0</div>
</div>

<div style="padding:16px 16px 20px;display:grid;grid-template-columns:repeat(4,1fr);gap:10px">

<button class="btn" onclick="act('clear')" style="grid-column:span 2;padding:16px 0;border:none;border-radius:14px;background:rgba(255,90,90,.15);color:#ff8a8a;font-size:16px;font-weight:600">AC</button>
<button class="btn" onclick="act('back')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:18px">⌫</button>
<button class="btn" onclick="op('/')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(108,92,231,.25);color:#a29bfe;font-size:20px;font-weight:600">÷</button>

<button class="btn" onclick="num('7')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">7</button>
<button class="btn" onclick="num('8')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">8</button>
<button class="btn" onclick="num('9')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">9</button>
<button class="btn" onclick="op('*')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(108,92,231,.25);color:#a29bfe;font-size:20px;font-weight:600">×</button>

<button class="btn" onclick="num('4')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">4</button>
<button class="btn" onclick="num('5')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">5</button>
<button class="btn" onclick="num('6')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">6</button>
<button class="btn" onclick="op('-')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(108,92,231,.25);color:#a29bfe;font-size:20px;font-weight:600">−</button>

<button class="btn" onclick="num('1')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">1</button>
<button class="btn" onclick="num('2')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">2</button>
<button class="btn" onclick="num('3')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">3</button>
<button class="btn" onclick="op('+')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(108,92,231,.25);color:#a29bfe;font-size:20px;font-weight:600">+</button>

<button class="btn" onclick="act('sign')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:17px">±</button>
<button class="btn" onclick="num('0')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">0</button>
<button class="btn" onclick="num('.')" style="padding:16px 0;border:none;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:19px">.</button>
<button class="btn" onclick="act('equals')" style="padding:16px 0;border:none;border-radius:14px;background:linear-gradient(135deg,#6c5ce7,#a29bfe);color:#fff;font-size:20px;font-weight:700;box-shadow:0 4px 14px rgba(108,92,231,.4)">=</button>

</div>
</div>
</div>

<script>
let current='0', prevValue=null, operator=null, justEquals=false, exprText='';
const display=document.getElementById('display');
const exprEl=document.getElementById('expr');
const opSymbol={'+':'+','-':'−','*':'×','/':'÷'};

function render(){
  display.textContent = formatNum(current);
  exprEl.textContent = exprText || '\\u00A0';
}
function formatNum(v){
  if(v==='' || v==='-') return v||'0';
  let n=parseFloat(v);
  if(isNaN(n)) return '0';
  if(Math.abs(n)>=1e12) return n.toExponential(4);
  let s=v.includes('.')? v : String(n);
  return s;
}
function num(d){
  if(justEquals){ current='0'; exprText=''; justEquals=false; }
  if(d==='.' && current.includes('.')) return;
  if(current==='0' && d!=='.') current=d;
  else current+=d;
  render();
}
function op(o){
  if(operator && !justEquals){ calc(); }
  prevValue=parseFloat(current);
  operator=o;
  exprText = formatNum(String(prevValue)) + ' ' + opSymbol[o];
  current='0';
  justEquals=false;
  render();
}
function calc(){
  if(operator===null || prevValue===null) return;
  let a=prevValue, b=parseFloat(current), r=0;
  switch(operator){
    case '+': r=a+b; break;
    case '-': r=a-b; break;
    case '*': r=a*b; break;
    case '/': r = b===0 ? NaN : a/b; break;
  }
  exprText = formatNum(String(a)) + ' ' + opSymbol[operator] + ' ' + formatNum(String(b)) + ' =';
  current = isNaN(r) ? 'Error' : String(Math.round(r*1e10)/1e10);
  operator=null; prevValue=null;
}
function act(a){
  if(a==='clear'){ current='0'; prevValue=null; operator=null; exprText=''; justEquals=false; }
  else if(a==='back'){ current = current.length>1 ? current.slice(0,-1) : '0'; }
  else if(a==='sign'){ if(current!=='0') current = current.startsWith('-')? current.slice(1) : '-'+current; }
  else if(a==='equals'){ calc(); justEquals=true; }
  render();
}
render();
</script>
</body>`;

	const item = {
		__typename: "GenAIaeacdsnwHtmlPrimitive",
		payload: html,
		trusted_sources: ["nixel.dev"]
	}

	await new AIRich(conn)
	.addSection(AIRich.newLayout('Single', item))
	.send(m.chat, { bypassDownload: false })
};

handler.help = handler.command = ["calc", "calculator"];
handler.tags = ['tools'];
handler.owner = false;

export default handler;