let handler = async (m, { conn, command }) => {
	const uptime = process.uptime();
	const mem = process.memoryUsage();
	const usedMB = (mem.heapUsed / 1024 / 1024).toFixed(2);
	const totalMB = (mem.heapTotal / 1024 / 1024).toFixed(2);
	const memPercent = Math.min(100, Math.round((mem.heapUsed / mem.heapTotal) * 100));

	const html = `<style>*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
</style>
<body style="margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee">
<div style="width:100%;max-width:620px;margin:auto;padding:16px;box-sizing:border-box">
<div style="background:rgba(255,255,255,.06);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.15);border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.35)">

<div style="padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.12);display:flex;justify-content:space-between;align-items:center">
<div><div style="font-size:11px;letter-spacing:1.5px;color:rgba(255,255,255,.45)">SYSTEM STATUS · LIVE</div><div style="font-size:21px;font-weight:bold;color:#fff">Bot Dashboard</div></div>
<div id="dot" style="width:12px;height:12px;border-radius:50%;background:#4ade80;box-shadow:0 0 12px #4ade80;animation:blink 2s infinite"></div>
</div>

<div style="padding:18px;display:flex;flex-direction:column;gap:14px">

<div style="display:flex;gap:12px">
<div style="flex:1;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:14px">
<div style="font-size:10px;color:rgba(255,255,255,.45);letter-spacing:1px">UPTIME</div>
<div id="uptime" style="font-size:18px;font-weight:bold;color:#fff;margin-top:4px;font-variant-numeric:tabular-nums">0h 0m 0s</div>
</div>
<div style="flex:1;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:14px">
<div style="font-size:10px;color:rgba(255,255,255,.45);letter-spacing:1px">STATUS</div>
<div style="font-size:18px;font-weight:bold;color:#4ade80;margin-top:4px">Online</div>
</div>
</div>

<div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:14px">
<div style="display:flex;justify-content:space-between;font-size:12px;color:rgba(255,255,255,.6);margin-bottom:8px">
<span>MEMORY USAGE</span><span>${usedMB} / ${totalMB} MB</span>
</div>
<div style="width:100%;height:8px;background:rgba(255,255,255,.1);border-radius:4px;overflow:hidden">
<div style="width:${memPercent}%;height:100%;background:linear-gradient(90deg,#6c5ce7,#a29bfe);border-radius:4px;animation:pulse 2.5s infinite"></div>
</div>
<div style="font-size:10px;color:rgba(255,255,255,.35);margin-top:6px">Snapshot at send time — run command again to refresh</div>
</div>

<div style="display:flex;gap:12px">
<div style="flex:1;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:14px;text-align:center">
<div style="font-size:22px;font-weight:bold;color:#fff">${process.version}</div>
<div style="font-size:10px;color:rgba(255,255,255,.45);margin-top:4px">NODE VERSION</div>
</div>
<div style="flex:1;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:14px;text-align:center">
<div style="font-size:22px;font-weight:bold;color:#fff">${process.platform}</div>
<div style="font-size:10px;color:rgba(255,255,255,.45);margin-top:4px">PLATFORM</div>
</div>
</div>

</div>
</div>
</div>
<script>
let startUptime = ${uptime};
let startTime = Date.now();
function tick(){
  let elapsed = startUptime + (Date.now() - startTime) / 1000;
  let h = Math.floor(elapsed / 3600);
  let m = Math.floor((elapsed % 3600) / 60);
  let s = Math.floor(elapsed % 60);
  document.getElementById('uptime').textContent = h + 'h ' + m + 'm ' + s + 's';
  requestAnimationFrame(tick);
}
tick();
</script>
</body>`;

	const item = {
		__typename: "GenAIaeacdsnwHtmlPrimitive",
		payload: html,
		trusted_sources: ["nixel.dev"]
	}

	await new AIRich(conn)
	.addSection(AIRich.newLayout('Single', item))
	.send(m.chat, { bypassDownload: false })
};

handler.help = handler.command = ["dashboard", "dash"];
handler.tags = ['owner'];
handler.owner = true;

export default handler;