let handler = async (m, { conn, command }) => {
	const jid = m.sender;
	const name = conn.getName ? conn.getName(jid) : (m.pushName || 'User');

	const cards = [
		{ symbol: '☀️', title: 'الشمس', color: '#ffd700', text: 'يوم مليء بالوضوح والطاقة الإيجابية. فرصة كنت تنتظرها ستظهر قريبًا.' },
		{ symbol: '🌙', title: 'القمر', color: '#a29bfe', text: 'الحدس هو بوصلتك اليوم. لا تتجاهل شعورك الداخلي تجاه قرار مهم.' },
		{ symbol: '⭐', title: 'النجمة', color: '#74b9ff', text: 'الأمل يتجدد. ما بدأته بصمت سيبدأ يؤتي ثماره قريبًا.' },
		{ symbol: '🔥', title: 'اللهب', color: '#ff6b6b', text: 'شغف قديم يعود للحياة. الوقت مناسب لتجربة شيء كنت تخاف منه.' },
		{ symbol: '🌊', title: 'الموجة', color: '#4ade80', text: 'تغيير قادم، لكنه لصالحك. لا تقاوم التيار، اتركه يأخذك لمكان أفضل.' },
		{ symbol: '💎', title: 'الجوهرة', color: '#e17055', text: 'قيمتك الحقيقية أكبر مما تظن. شخص ما سيراها اليوم بوضوح.' },
		{ symbol: '🗝️', title: 'المفتاح', color: '#fdcb6e', text: 'باب كان مغلقًا سينفتح، لكن المفتاح بيدك أنت لا أحد غيرك.' },
		{ symbol: '🦋', title: 'الفراشة', color: '#fd79a8', text: 'تحول داخلي يحدث بصمت. أنت لست نفس الشخص الذي كنته الشهر الماضي.' },
		{ symbol: '⚡', title: 'الصاعقة', color: '#00cec9', text: 'قرار سريع سيغيّر مسار أسبوعك. ثق بأول انطباع يأتيك.' },
		{ symbol: '🌸', title: 'الزهرة', color: '#ff7675', text: 'علاقة أو صداقة تزهر من جديد. افتح قلبك لمن حولك.' },
		{ symbol: '🏔️', title: 'الجبل', color: '#b2bec3', text: 'تحدٍ صعب أمامك، لكن قوتك أكبر منه بكثير. استمر بالتسلق.' },
		{ symbol: '🕊️', title: 'الطائر', color: '#dfe6e9', text: 'السلام الداخلي أقرب مما تعتقد. تنفّس، الأمور تسير لصالحك.' }
	];

	const userDB = global.db.users[jid];
	const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

	let pick, alreadyDrawn = false;

	if (userDB.lastFateDate === today && userDB.lastFateCard) {
		// نفس اليوم، رجّع نفس البطاقة اللي سحبها
		pick = cards[userDB.lastFateCard - 1]; // -1 لأننا خزناها +1
		alreadyDrawn = true;
	} else {
		// يوم جديد، بطاقة عشوائية جديدة
		const idx = Math.floor(Math.random() * cards.length);
		pick = cards[idx];
		userDB.lastFateDate = today;
		userDB.lastFateCard = idx + 1; // +1 عشان نتفادى حذف القيمة لو كانت 0
	}

	// حساب الوقت المتبقي لمنتصف الليل (الوقت اللي يقدر يسحب فيه بطاقة جديدة)
	const now = new Date();
	const midnight = new Date(now);
	midnight.setHours(24, 0, 0, 0);
	const msLeft = midnight - now;
	const hLeft = Math.floor(msLeft / 3600000);
	const mLeft = Math.floor((msLeft % 3600000) / 60000);

	const cardId = 'c' + Date.now();

	const html = `<style>*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;box-sizing:border-box}
body{margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee;perspective:1200px}
@keyframes floatBg{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-8px) rotate(2deg)}}
@keyframes sparkle{0%,100%{opacity:.2;transform:scale(.8)}50%{opacity:1;transform:scale(1.2)}}
@keyframes glow{0%,100%{box-shadow:0 0 25px rgba(108,92,231,.35)}50%{box-shadow:0 0 45px rgba(108,92,231,.6)}}
.scene{width:100%;max-width:340px;margin:24px auto;height:460px;perspective:1400px}
.card3d{position:relative;width:100%;height:100%;transition:transform 1s cubic-bezier(.22,1,.36,1);transform-style:preserve-3d;cursor:pointer}
.card3d.flipped{transform:rotateY(180deg)}
.card3d.autoflip{transform:rotateY(180deg)}
.face{position:absolute;inset:0;backface-visibility:hidden;border-radius:22px;overflow:hidden;box-shadow:0 15px 50px rgba(0,0,0,.5)}
.back{background:linear-gradient(160deg,#1e1b3a,#2d2154);border:1px solid rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;animation:glow 3s infinite}
.front{background:linear-gradient(160deg,${pick.color}22,#151328);border:1px solid ${pick.color}66;transform:rotateY(180deg);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;text-align:center}
.pattern{position:absolute;inset:14px;border:1.5px solid rgba(255,255,255,.25);border-radius:16px}
.pattern2{position:absolute;inset:22px;border:1px solid rgba(255,255,255,.12);border-radius:12px}
.moonicon{font-size:56px;animation:floatBg 3.5s ease-in-out infinite}
.hint{position:absolute;bottom:26px;left:0;right:0;text-align:center;font-size:11px;color:rgba(255,255,255,.4);letter-spacing:1px}
.sp{position:absolute;font-size:12px;animation:sparkle 2s infinite}
</style>
<div style="width:100%;max-width:420px;margin:auto;padding:10px 16px 20px;box-sizing:border-box">

<div style="text-align:center;margin-bottom:6px">
<div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,.4)">CARD OF FATE</div>
<div style="font-size:18px;font-weight:bold;color:#fff">${name} · بطاقة اليوم</div>
${alreadyDrawn ? `<div style="font-size:11px;color:#fdcb6e;margin-top:4px">لقد سحبت بطاقتك اليوم بالفعل ✦ بطاقة جديدة بعد ${hLeft}س ${mLeft}د</div>` : ''}
</div>

<div class="scene">
<div class="card3d ${alreadyDrawn ? 'autoflip' : ''}" id="${cardId}" onclick="flip_${cardId}()">

<div class="face back">
<div class="pattern"></div>
<div class="pattern2"></div>
<span class="sp" style="top:15%;left:20%">✦</span>
<span class="sp" style="top:75%;left:75%;animation-delay:.6s">✦</span>
<span class="sp" style="top:40%;left:80%;animation-delay:1.1s">✦</span>
<span class="sp" style="top:65%;left:15%;animation-delay:1.6s">✦</span>
<div class="moonicon">🌙</div>
<div class="hint">${alreadyDrawn ? 'اضغط لرؤية بطاقتك مرة أخرى' : 'اضغط لكشف بطاقتك'}</div>
</div>

<div class="face front">
<div class="pattern"></div>
<div style="font-size:58px;margin-bottom:10px">${pick.symbol}</div>
<div style="font-size:22px;font-weight:bold;color:${pick.color};letter-spacing:1px">${pick.title}</div>
<div style="width:40px;height:2px;background:${pick.color};margin:12px 0;opacity:.6"></div>
<div style="font-size:13.5px;line-height:1.7;color:rgba(255,255,255,.85)">${pick.text}</div>
</div>

</div>
</div>

<div style="text-align:center;margin-top:10px">
<span style="font-size:9px;color:rgba(255,255,255,.25);letter-spacing:1px">JOY BOY BOT · بطاقة واحدة يوميًا</span>
</div>

</div>
<script>
function flip_${cardId}(){
  const el = document.getElementById('${cardId}');
  el.classList.toggle('flipped');
}
</script>`;

	const item = {
		__typename: "GenAIaeacdsnwHtmlPrimitive",
		payload: html,
		trusted_sources: ["nixel.dev"]
	}

	await new AIRich(conn)
	.addSection(AIRich.newLayout('Single', item))
	.send(m.chat, { bypassDownload: false })
};

handler.help = handler.command = ["fate", "tarot", "qadar"];
handler.tags = ['tools'];
handler.owner = false;

export default handler;