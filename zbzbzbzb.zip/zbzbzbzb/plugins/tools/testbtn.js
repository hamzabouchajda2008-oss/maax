let handler = async (m, { conn }) => {
	await new Button(conn)
		.setBody('🧪 اختبار: اضغط الزر تحت')
		.addReply('افتح القائمة', '.menu')
		.send(m.chat, { quoted: m });
};

handler.help = handler.command = ["testbtn2"];
handler.tags = ['tools'];
handler.owner = false;

export default handler;