
import net from "net";
import fs from "fs";
import os from "os";
import { fork } from "child_process";

const workerFile = process.argv[2], sockPath = process.argv[3], execArg = process.argv[4] || "";
try { if (process.platform !== "win32") fs.rmSync(sockPath, { force: true }); } catch (e) {}
try { os.setPriority(0, -5); } catch (e) {}

const w = fork(workerFile, [], { execArgv: execArg ? [execArg] : [], stdio: ["ignore", "inherit", "inherit", "ipc"] });
let client = null, busy = false, lastClient = Date.now();

function out(m) { if (client && !client.destroyed) { try { client.write(JSON.stringify(m) + "\n"); } catch (e) {} } }

w.on("message", m => {
    if (m.type === "started") busy = true;
    if (m.type === "ended" || m.type === "error" || m.type === "failed") busy = false;
    out(m);
});
w.on("exit", code => {
    out({ type: "worker_exit", code: code });
    setTimeout(() => { try { if (process.platform !== "win32") fs.rmSync(sockPath, { force: true }); } catch (e) {} process.exit(0); }, 400);
});

net.createServer(s => {
    if (client) { try { client.destroy(); } catch (e) {} }
    client = s;
    let acc = "";
    s.on("data", d => {
        acc += d;
        let i;
        while ((i = acc.indexOf("\n")) >= 0) {
            const line = acc.slice(0, i); acc = acc.slice(i + 1);
            if (!line) continue;
            try {
                const m = JSON.parse(line);
                if (m.type === "__kill") { w.kill("SIGKILL"); }
                else if (m.type === "__ping") { out({ type: "hello", pid: w.pid, hostPid: process.pid, busy: busy }); }
                else { w.send(m); }
            } catch (e) {}
        }
    });
    s.on("close", () => { if (client === s) { client = null; lastClient = Date.now(); } });
    s.on("error", () => {});
    out({ type: "hello", pid: w.pid, hostPid: process.pid, busy: busy });
}).listen(sockPath);

// لو البوت غايب 5 دقائق وما فيه مكالمة شغّالة، نقفل نفسنا
setInterval(() => { if (!client && !busy && Date.now() - lastClient > 300000) w.kill("SIGKILL"); }, 30000);
process.on("uncaughtException", e => console.error("[RING-HOST]", e));
process.on("unhandledRejection", e => console.error("[RING-HOST]", e));
