// ============================================
// 🔗 Anti-Link (Raw Mode) — كيتصل مباشرة بالسوكيت الخام ديال Baileys
// بلا ما يعتمد على نظام تصنيف الرسائل ديال meowsab (اللي كايصنف polls كـ "Other")
// هادشي كيحل مشكل الروابط المخبية جوا استطلاعات (polls)
// ============================================

// ⚠️ عدّل هذا الرقم لرقم المالك الحقيقي (نفس اللي بملف index.js بالضبط)
const OWNERS = ["212625654754@s.whatsapp.net"];

// 🔓 كيفك رسائل ملفوفة (ephemeral / view-once) باش نوصلو للمحتوى الحقيقي
function unwrapMessage(msg) {
    if (!msg) return msg;
    const wrappers = [
        'ephemeralMessage',
        'viewOnceMessage',
        'viewOnceMessageV2',
        'viewOnceMessageV2Extension',
        'documentWithCaptionMessage'
    ];
    let current = msg;
    for (let i = 0; i < 5; i++) {
        const key = wrappers.find(w => current?.[w]?.message);
        if (!key) break;
        current = current[key].message;
    }
    return current;
}

function extractPollText(content) {
    const poll = content?.pollCreationMessage
        || content?.pollCreationMessageV2
        || content?.pollCreationMessageV3;
    if (!poll) return '';
    const name = poll.name || '';
    const options = (poll.options || []).map(o => o.optionName || '').join(' ');
    return `${name} ${options}`;
}

function extractAllText(rawMsg) {
    const content = unwrapMessage(rawMsg) || {};
    return [
        content.conversation,
        content.extendedTextMessage?.text,
        content.imageMessage?.caption,
        content.videoMessage?.caption,
        extractPollText(content)
    ].filter(Boolean).join(' ');
}

function normalize(text) {
    return text
        .toLowerCase()
        .replace(/[\u200b\u200c\u200d\u2060\u180e\uFEFF\u00ad\uFFF9-\uFFFB]/g, '')
        .replace(/0/g, 'o')
        .replace(/1/g, 'l')
        .replace(/3/g, 'e')
        .replace(/4/g, 'a')
        .replace(/@/g, 'a')
        .replace(/\(dot\)|\[dot\]|\s+dot\s+|\{dot\}/gi, '.')
        .replace(/\[\.\]|\(\.\)|\{\.\}/g, '.')
        .replace(/\s*\.\s*/g, '.')
        .replace(/\.{2,}/g, '.')
        .replace(/\s+/g, '');
}

const linkRegex = /(chat\.whatsapp\.com\/[a-z0-9]{10,}|whatsapp\.com\/channel\/[a-z0-9]{10,}|wa\.me\/[a-z0-9]{6,})/i;

function getWarnDB(chat) {
    if (!global.db.antiLinkWarns) global.db.antiLinkWarns = {};
    if (!global.db.antiLinkWarns[chat]) global.db.antiLinkWarns[chat] = {};
    return global.db.antiLinkWarns[chat];
}

async function handleWarning(sock, chat, sender, viaPoll) {
    const warnDB = getWarnDB(chat);
    const count = (warnDB[sender] || 0) + 1;
    warnDB[sender] = count;

    const tauntLine = viaPoll
        ? `\n\n😏 خبيتي الرابط فـ poll باش تتخطى البوت؟ احنا ما تشتغل معانا لعب الاطفال هاذا.`
        : '';

    if (count >= 3) {
        delete warnDB[sender];
        try {
            await sock.sendMessage(chat, {
                text: `⛔ *طرد نهائي*\n\n@${sender.split('@')[0]} تم طردك من المجموعة\nالسبب: نشر رابط جروب/قناة - تجاوز 3 تحذيرات${tauntLine}`,
                mentions: [sender]
            });
        } catch (e) {
            console.log('[raw-antilink] warn-msg error:', e?.message || e);
        }
        try {
            await sock.groupParticipantsUpdate(chat, [sender], 'remove');
        } catch (e) {
            console.log('[raw-antilink] kick error:', e?.message || e);
        }
        return;
    }

    try {
        await sock.sendMessage(chat, {
            text:
                `🚫 *تم حذف الرابط*\n\n@${sender.split('@')[0]}\n` +
                `السبب: ${viaPoll ? 'نشر رابط مخبى داخل استطلاع (Poll) 🗳️' : 'نشر رابط جروب/قناة'}\n\n` +
                `📌 التحذير: ${count} / 3${count === 2 ? '\n⚠️ تحذير أخير! التكرار القادم يعني الطرد الفوري.' : ''}` +
                tauntLine +
                `\n\n> يرجى الالتزام بقوانين المجموعة`,
            mentions: [sender]
        });
    } catch (e) {
        console.log('[raw-antilink] warn-msg error:', e?.message || e);
    }
}

// 🔍 كيحاول يلقى السوكيت الخام تحت مجموعة أسماء محتملة كايستعملها الفريمووركات
function findRawSocket(client) {
    const candidates = [
        client?.sock,
        client?.socket,
        client?.conn,
        client?.client,
        client?._sock,
        client?.ev?.sock
    ];
    return candidates.find(c => c?.ev?.on && typeof c.sendMessage === 'function');
}

export function attachAntiLinkRaw(client, { retries = 15, intervalMs = 2000 } = {}) {
    let attempts = 0;

    const tryAttach = () => {
        attempts++;
        const sock = findRawSocket(client);

        if (!sock) {
            if (attempts >= retries) {
                console.log('[raw-antilink] ❌ ماقدرتش نلقى الـ raw socket بعد', retries, 'محاولات.');
                console.log('[raw-antilink] الخصائص المتوفرة فـ client:', Object.keys(client || {}));
                console.log('[raw-antilink] بعت هاد اللائحة ديال الخصائص باش نلقاو الاسم الصحيح.');
                return;
            }
            setTimeout(tryAttach, intervalMs);
            return;
        }

        sock.ev.on('messages.upsert', async ({ messages }) => {
            for (const m of messages) {
                try {
                    const chat = m.key?.remoteJid;
                    const sender = m.key?.participant || m.key?.remoteJid;
                    if (!chat?.endsWith('@g.us')) continue;
                    if (!sender || m.key?.fromMe) continue;

                    const g = global.db?.groups?.[chat];
                    if (!g?.antiLink) continue;

                    if (OWNERS.includes(sender)) continue;

                    let exempt = false;
                    try {
                        const metadata = await sock.groupMetadata(chat);
                        const p = metadata.participants.find(p => p.id === sender);
                        exempt = p?.admin === 'admin' || p?.admin === 'superadmin';
                    } catch (e) {
                        console.log('[raw-antilink] metadata fetch error:', e?.message || e);
                    }
                    if (exempt) continue;

                    const rawText = extractAllText(m.message);
                    if (!rawText) continue;

                    const normalized = normalize(rawText);
                    if (!linkRegex.test(normalized)) continue;

                    const wasPoll = !!(unwrapMessage(m.message)?.pollCreationMessage
                        || unwrapMessage(m.message)?.pollCreationMessageV2
                        || unwrapMessage(m.message)?.pollCreationMessageV3);

                    try {
                        await sock.sendMessage(chat, { delete: m.key });
                    } catch (e) {
                        console.log('[raw-antilink] delete error:', e?.message || e);
                    }

                    await handleWarning(sock, chat, sender, wasPoll);
                } catch (e) {
                    console.log('[raw-antilink] handler error:', e?.message || e);
                }
            }
        });

        console.log('[raw-antilink] ✅ تم تفعيل الحماية المباشرة (raw) — كتشمل روابط الـ polls زيادة على الروابط العادية.');
    };

    tryAttach();
}
