// ضع هاد الملف فـ ./system/blacklist.js

import fs from 'fs';
import path from 'path';

const DB_PATH = path.resolve('./system/blacklist.json');

// ⚠️ عدّل هذي الأرقام لأرقام المالكين الحقيقية (نفس اللي بملف index.js بالضبط)
const PROTECTED_OWNERS = [
    "212625654754@s.whatsapp.net",
    "212721125336@s.whatsapp.net"
];

const load = () => {
    try {
        if (!fs.existsSync(DB_PATH)) {
            fs.writeFileSync(DB_PATH, JSON.stringify([], null, 2));
        }
        const raw = fs.readFileSync(DB_PATH, 'utf-8');
        return JSON.parse(raw || '[]');
    } catch (e) {
        console.error('فشل قراءة قائمة الحظر:', e);
        return [];
    }
};

const save = (list) => {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(list, null, 2));
    } catch (e) {
        console.error('فشل حفظ قائمة الحظر:', e);
    }
};

// نقبل رقم عادي (بلا +) أو jid كامل، وكندايرو jid صحيح
const normalize = (input) => {
    if (!input) return null;
    const digits = String(input).replace(/[^0-9]/g, '');
    return digits ? `${digits}@s.whatsapp.net` : null;
};

export const isBlacklisted = (jid) => {
    const list = load();
    return list.includes(normalize(jid));
};

export const addToBlacklist = (jid) => {
    const n = normalize(jid);
    if (!n) return false;

    // 🛡️ حماية: ما نقدروش نزيدو مالك للقائمة السوداء (حتى لو غلط أو بنية سيئة)
    if (PROTECTED_OWNERS.includes(n)) return 'protected';

    const list = load();
    if (!list.includes(n)) {
        list.push(n);
        save(list);
    }
    return true;
};

export const removeFromBlacklist = (jid) => {
    const n = normalize(jid);
    if (!n) return false;
    let list = load();
    if (!list.includes(n)) return false;
    list = list.filter(x => x !== n);
    save(list);
    return true;
};

export const getBlacklist = () => load();
