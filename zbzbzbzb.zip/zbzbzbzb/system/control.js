import fs from "fs";
import path from "path";
import { isBlacklisted } from "./blacklist.js";

// ⚠️ عدّل هذا الرقم لرقم المالك الحقيقي (نفس اللي بملف index.js بالضبط)
const PROTECTED_OWNERS = ["212625654754@s.whatsapp.net", "212721125336@s.whatsapp.net", "105485084680233@lid"];

const group = async (ctx, event, eventType) => {
    try {
        if (!event?.participants) return null;

        let participants = event.participants.filter(p => p?.phoneNumber).map(p => p.phoneNumber);
        const author = event.author;
        let txt;

        // ============ 🛡️ حماية الأدمن ============
        // فقط صاحب البوت (PROTECTED_OWNERS) أو البوت نفسه يقدر يضيف/يشيل أدمن
        if ((eventType === 'promote' || eventType === 'demote') && author) {
            const botJid = ctx.sock?.user?.id?.split(':')[0] + '@s.whatsapp.net';
            const isBot = author === botJid;
            const isProtected = PROTECTED_OWNERS.includes(author);

            // استثناء: لو العملية كانت ترقية/تنزيل للبوت نفسه فقط (بلا حد آخر معاه)
            // نسمح بيها لأي حد، لأن البوت محتاج يكون أدمن باش يخدم بشكل طبيعي
            const nonBotTargets = participants.filter(p => p !== botJid);
            const targetsBotOnly = participants.includes(botJid) && nonBotTargets.length === 0;

            if (!isBot && !isProtected && !targetsBotOnly) {
                const revertAction = eventType === 'promote' ? 'demote' : 'promote';
                const actionAr = eventType === 'promote' ? 'ترقية' : 'تنزيل';

                // نرجع كل شخص تأثر لوضعه الأصلي المعاكس (نلغي الترقية/التنزيل)
                // نستثني البوت من هاد اللائحة حتى لو كان ضمن العملية (مختلطة مع أشخاص آخرين)
                // منفصلة عن العملية التانية باش لو وحدة فشلت، الثانية تكمل عادي
                let revertOk = true; // ما كاينش أشخاص لنرجعهم إلا كان فيهم حاجة
                if (nonBotTargets.length > 0) {
                    revertOk = false;
                    try {
                        await ctx.sock.groupParticipantsUpdate(event.chat, nonBotTargets, revertAction);
                        revertOk = true;
                    } catch (e) {
                        console.error('فشل إرجاع حالة الأعضاء المتأثرين:', e);
                    }
                }

                // نشيل الأدمنية من الشخص اللي سوى المخالفة (بدون طرد)
                let authorDemoteOk = false;
                try {
                    await ctx.sock.groupParticipantsUpdate(event.chat, [author], 'demote');
                    authorDemoteOk = true;
                } catch (e) {
                    console.error('فشل سحب الأدمنية من المخالف:', e);
                }

                // رسالة التحذير دايماً كتترسل، حتى لو فشلت العمليات فوق
                // نص عادي بلا صورة/كارد، مع تفاصيل دقيقة وتاغ للطرفين (المخالف + الشخص المتأثر)
                // نستثني البوت من التاغ فهاد الرسالة لأنه ماشي طرف فالمخالفة
                const targetsTag = nonBotTargets.map(p => '@' + p.split('@')[0]).join(', ');
                const authorTagW = '@' + author.split('@')[0];

                const warningText =
                    `🛡️ *تم رصد محاولة تلاعب بالإدارة*\n` +
                    `⊱⋅ ──────────── ⋅⊰\n\n` +
                    `👤 *المخالف:* ${authorTagW}\n` +
                    `🎯 *الشخص المستهدف:* ${targetsTag || 'غير محدد'}\n` +
                    `⚙️ *العملية المرفوضة:* ${actionAr} أدمن بدون صلاحية\n\n` +
                    `${revertOk ? '✅ تم إرجاع الشخص المستهدف لحالته الأصلية' : '⚠️ لم يتم إرجاع الشخص المستهدف لحالته (تحقق من صلاحيات البوت)'}\n` +
                    `${authorDemoteOk ? '🚫 تم سحب صلاحية الأدمن من المخالف' : '⚠️ لم يتم سحب صلاحية المخالف (تحقق من صلاحيات البوت)'}` +
                    `${(!revertOk || !authorDemoteOk) ? '\n\n📌 تأكد أن البوت أدمن بالجروب حتى تشتغل الحماية بشكل كامل.' : ''}`;

                try {
                    await ctx.sock.sendMessage(event.chat, {
                        text: warningText,
                        mentions: [author, ...nonBotTargets]
                    });
                } catch (e) {
                    console.error('فشل إرسال رسالة التحذير:', e);
                }

                return null; // نوقف هنا، ما نكمل رسالة الترحيب العادية
            }
        }
        // ============ نهاية الحماية ============

        // ============ 🚫 القائمة السوداء ============
        // لأي عضو داخل جديد (add)، إلا كان محظور كيتطرد مباشرة
        // ولا يوصل حتى لرسالة الترحيب العادية
        if (eventType === 'add') {
            const blacklisted = participants.filter(p => isBlacklisted(p));

            if (blacklisted.length) {
                try {
                    await ctx.sock.groupParticipantsUpdate(event.chat, blacklisted, 'remove');
                } catch (e) {
                    console.error('فشل طرد عضو من القائمة السوداء:', e);
                }

                try {
                    const tags = blacklisted.map(p => '@' + p.split('@')[0]).join(', ');
                    await ctx.sock.sendMessage(event.chat, {
                        text: `⛔ *تم رصد عضو من القائمة السوداء*\n⊱⋅ ──────────── ⋅⊰\n\n🚫 ${tags}\n👢 تم طرده مباشرة من الجروب`,
                        mentions: blacklisted
                    });
                } catch (e) {
                    console.error('فشل إرسال إشعار القائمة السوداء:', e);
                }

                // نشيل المحظورين من قائمة الترحيب العادية، ونكمل بالباقي إلا كان
                participants = participants.filter(p => !blacklisted.includes(p));
                if (!participants.length) return null;
            }
        }
        // ============ نهاية القائمة السوداء ============

        const users = participants.length 
            ? participants.map(p => '@' + p.split('@')[0]).join(' and ') 
            : 'No users';
        const authorTag = author ? '@' + author.split('@')[0] : 'Unknown';

        const messages = {
            add: `♡゙ مـنـور/ه ${users}${authorTag === users ? "" : `\n𝐛𝐲 ${authorTag}`}`,
            remove: `${users} تم إزالته من الجروب${authorTag === users ? "" : `\n𝐛𝐲 ${authorTag}`}`,
            promote: `♡゙ مـبـروك الادمـن ${users}\nby ${authorTag}`,
            demote: `♡゙ بـقـيـت عـضـو خـلاص ${users}\nby ${authorTag}`
        };

        txt = messages[eventType];
        if (!txt) return null;
        
        if (global.db.groups[event.chat].noWelcome === true) return 9999;

        const img = ["remove", "add"].includes(eventType) 
            ? (event.userUrl || "https://files.catbox.moe/hm9iq4.jpg") 
            : "https://files.catbox.moe/hm9iq4.jpg";

        await ctx.sock.msgUrl(event.chat, txt, {
            img,
            mentions: author ? [author, ...participants] : participants,
            big: ["remove", "add"].includes(eventType)
        });

    } catch (e) {
        console.error(e);
    }
    return null;
};

// ============ 🚫 مضاد جهات الاتصال (Anti-Contact) ============
// ملاحظة: هاد الدالة بقات هنا للتوافق، لكن التفعيل الفعلي دابا
// كيتم عبر ./plugins/anticontact.js (نظام الـ before hook)
const antiContact = async (ctx, msg) => {
    try {
        if (!msg?.isGroup || !msg?.chat || !msg?.sender) return null;

        const message = msg.message || {};
        const isContact =
            message.contactMessage ||
            message.contactsArrayMessage ||
            message.viewOnceMessage?.message?.contactMessage ||
            message.viewOnceMessageV2?.message?.contactMessage ||
            message.viewOnceMessageV2Extension?.message?.contactMessage;

        if (!isContact) return null;

        const sender = msg.sender;
        const chat = msg.chat;

        const botJid = ctx.sock?.user?.id?.split(':')[0] + '@s.whatsapp.net';
        const isBot = sender === botJid;
        const isProtected = PROTECTED_OWNERS.includes(sender);

        // نتأكد وا المرسل أدمن فالجروب (عشان الأدمنات معفيين من هاد الأمر)
        let isAdmin = false;
        try {
            const metadata = await ctx.sock.groupMetadata(chat);
            const participant = metadata?.participants?.find(p => p.id === sender);
            isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch (e) {
            console.error('فشل جلب بيانات الجروب للتحقق من الأدمنية:', e);
        }

        // الأونر (PROTECTED_OWNERS) والبوت نفسه والأدمنات معفيين، حتى ما تتقفلش عليهم
        if (isBot || isProtected || isAdmin) return null;

        // 1) حذف رسالة جهة الاتصال
        try {
            await ctx.sock.sendMessage(chat, { delete: msg.key });
        } catch (e) {
            console.error('فشل حذف رسالة جهة الاتصال:', e);
        }

        // 2) طرد المرسل
        let kicked = false;
        try {
            await ctx.sock.groupParticipantsUpdate(chat, [sender], 'remove');
            kicked = true;
        } catch (e) {
            console.error('فشل طرد مرسل جهة الاتصال:', e);
        }

        // 3) رسالة تنبيه فالجروب
        const senderTag = '@' + sender.split('@')[0];
        const warningText =
            `🚫 *تم رصد مشاركة جهة اتصال (فيكارد)*\n` +
            `⊱⋅ ──────────── ⋅⊰\n\n` +
            `👤 *المخالف:* ${senderTag}\n` +
            `🗑️ *تم حذف الرسالة مباشرة*\n` +
            `${kicked ? '👢 تم طرد المخالف من الجروب' : '⚠️ لم يتم طرد المخالف (تأكد أن البوت أدمن بالجروب)'}`;

        try {
            await ctx.sock.sendMessage(chat, {
                text: warningText,
                mentions: [sender]
            });
        } catch (e) {
            console.error('فشل إرسال رسالة تحذير جهة الاتصال:', e);
        }

        return true; // اتعامل مع الرسالة، وقف أي معالجة تانية ليها
    } catch (e) {
        console.error(e);
    }
    return null;
};
// ============ نهاية مضاد جهات الاتصال ============

const access = async (msg, checkType, time) => {
    const conn = await msg.client();
    
    const quoted = {
        key: {
            participant: `${msg.sender.split('@')[0]}@s.whatsapp.net`,
            remoteJid: 'status@broadcast',
            fromMe: false,
        },
        message: {
            contactMessage: {
                displayName: `${msg.pushName}`,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${msg.pushName}\nitem1.TEL;waid=${msg.sender.split('@')[0]}:${msg.sender.split('@')[0]}\nEND:VCARD`,
            },
        },
        participant: '0@s.whatsapp.net',
    };
    
    const messages = {
        cooldown: `*♡⏳ استنى ${time || 'بعض كام ثانيه'} ثانية وكمل الأمر ⏳♡*\n⊱⋅ ──────────── ⋅⊰\n> *_لازم تصبر شويه عشان الأمر ده مينفعش فيه الاسبام_*`,
        owner: `*♡ 🇩🇪 الأمر ده لـ المطورين فقط 🇩🇪♡*\n⊱⋅ ──────────── ⋅⊰\n> *_الامر ده لـ المطورين البوت لازم تكون مطور عشان تقدر تستخدمه_`,
        group: `*♡💠 الأمر ده بيشتغل بس ف الجروبات 💠♡*\n⊱⋅ ──────────── ⋅⊰\n> *_لازم الأمر ده تستخدمه ف جروب فقط ممنوع غير كده_*`,
        admin: `*♡📯 الأمر ده لـ الادمن فقط 📯♡*\n⊱⋅ ──────────── ⋅⊰\n> *_انت مجرد عضو لازم تبقي ادمن يا عضو يا عبد_*`,
        private: `*♡🏷️ الأمر ده في الخاص فقط 🏷️♡*\n⊱⋅ ──────────── ⋅⊰\n> *_الامر ف الخاص بس ياحبيبي_*`,
        botAdmin: `*♡📌 لازم اكون ادمن عشان انقذ الأمر 📌♡*\n⊱⋅ ──────────── ⋅⊰\n> *_حطني ادمن عشان تقدر تستعمل الأمر ده_*`,
        noSub: `*♡🫒 الأمر ده ف البوت الأساسي فقط 🫒♡*\n⊱⋅ ──────────── ⋅⊰\n> *_ادخل الجروب ده و جرب الأمر [ https://chat.whatsapp.com/Epfd9J7t8tR6nnpIDjtGQZ?mode=gi_t ] ياريت من غير سبام_*`,
        disabled: `*♡🗃️ الامر متوقف (تحت صيانة) 🗃️♡*\n⊱⋅ ──────────── ⋅⊰\n> *_الامر تحت صيانه قريباً بيشتغل تاني_*`,
        error: `*♡❌ الأمر فيه خطأ، كلم المطورين ❌♡*\n⊱⋅ ──────────── ⋅⊰\n*_اكتب " .المطور " عشان يبعتلك رقم المطور_*`
    };
    
    if (conn && messages[checkType]) {
        await conn.msgUrl(msg.chat, messages[checkType], {
            img: "https://i.pinimg.com/originals/02/c3/51/02c351dfd4eb72a62f225ce964dc510d.jpg",
            big: false
        }, quoted);
        return false;  
    }
    return null;  
};

export { access, group, antiContact };
